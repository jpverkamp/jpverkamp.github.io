﻿using System;
using System.Drawing;

using SdlDotNet.Core;
using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;

namespace Sandbox.Simulation
{
	/// <summary>
	/// A magnet.
	/// </summary>
	public class Magnet : Item
	{
		// Magnet parameters.
		int Radius;						// The radius of the field.
		bool Pull;						// True to pull particles, false to push them away.
		
		/// <summary>
		/// Create a new Magnet.
		/// </summary>
		/// <param name="world">The Magnet's world.</param>
		/// <param name="location">Where in the world to create the Magnet.</param>
		/// <param name="radius">The radius of the magnet.</param>
		/// <param name="pull">True to pull particles, false to push them away.</param>
		public Magnet(World world, Point location, int radius, bool pull)
			: base(world, location)
		{
			Radius = radius;
			Pull = pull;
		}
		
		/// <summary>
        /// Update the Magnet.
        /// </summary>
        internal override void Update()
        {
        	// Force a redraw on the magnet's previous location.
        	World.Set(Location.X, Location.Y, World.Type[Location.X, Location.Y]);
        	
        	// Move to the new location.
        	UpdateLocation();
        	
        	// Apply magnetic forces.
        	for(int dx = -Radius; dx <= Radius; dx++)
        	{
        		for(int dy = -Radius; dy <= Radius; dy++)
        		{
        			if (Math.Abs(dx) + Math.Abs(dy) < Radius && Location.X + dx >= 0 && Location.X + dx < World.Size.Width && Location.Y + dy >= 0 && Location.Y + dy < World.Size.Height)
        			{
        				World.dX[Location.X + dx, Location.Y + dy] += (short) Math.Sign((Pull ? -2 : 2) * dx);
        				World.dY[Location.X + dx, Location.Y + dy] += (short) Math.Sign((Pull ? -2 : 2) * dy);
        			}
        		}
        	}
        }
		
		/// <summary>
        /// Draw the Magnet.
        /// </summary>
        /// <param name="surface">The surface to draw to.</param>
        internal override void Draw(Surface surface)
        {
        	// HACK: Just draw a pink box for now.
        	surface.Draw(new Box(
        		(short) (World.DisplayRegion.X + ((Location.X - 2) * World.ScaleX)),
				(short) (World.DisplayRegion.Y + ((Location.Y - 2) * World.ScaleY)),
				(short) (World.DisplayRegion.X + ((Location.X - 2) * World.ScaleX) + 5 * World.ScaleX),
				(short) (World.DisplayRegion.Y + ((Location.Y - 2) * World.ScaleY) + 5 * World.ScaleY)
			), Color.Pink, false, true);   
        }
        
        /// <summary>
        /// Swap enabled state on button 1.
        /// </summary>
        internal override void Button1()
        {
        	Pull = !Pull;
        }
	}
}

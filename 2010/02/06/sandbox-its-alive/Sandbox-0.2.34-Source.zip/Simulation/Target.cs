﻿using System;
using System.Drawing;

using SdlDotNet.Core;
using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;

using Sandbox.Resources;

namespace Sandbox.Simulation
{
	/// <summary>
	/// A target that collects sand.
	/// </summary>
	public class Target : Item
	{
		// Source parameters.
		uint[] Scores;					// Store the current scores of the target.
		int Radius;						// The radius of the source.
		
		/// <summary>
		/// Create a new target.
		/// </summary>
		/// <param name="world">The world the target is in.</param>
		/// <param name="location">The current location of the target.</param>
		public Target(World world, Point location)
			: base(world, location)
		{
			// Store the location.
			Location = location;
			Radius = Math.Max(1, World.RADIUS);
			
			// Build the score array.
			// Only score particle types.
			Scores = new uint[world.Colors.Length - World.SOLIDS - 1];
		}
		
		/// <summary>
        /// Update the item.
        /// </summary>
        internal override void Update()
        {
        	// Update the location.
        	UpdateLocation();
        	
        	// Grab particles.
    		for(int xd = Location.X - Radius; xd <= Location.X + Radius; xd++)
    		{
	    		for(int yd = Location.Y - Radius; yd <= Location.Y + Radius; yd++)
	    		{
	    			if(World.Type[xd, yd] > World.SOLIDS)
	    			{
	    				Scores[World.Type[xd, yd] - World.SOLIDS - 1]++;
	    				World.Set(xd, yd, 0);
	    			}
	    		}
    		}
        }
		
		/// <summary>
        /// Draw the item.
        /// </summary>
        /// <param name="surface">The surface to draw to.</param>
        internal override void Draw(Surface surface)
        {
			// HACK: Just draw an outline in white for now.
			for(int i = 0; i < Radius; i += 2)
			{
				surface.Draw(new Ellipse(
	        		(short) (World.DisplayRegion.X + (Location.X * World.ScaleX)),
					(short) (World.DisplayRegion.Y + (Location.Y * World.ScaleY)),
					(short) (i * World.ScaleX),
					(short) (i * World.ScaleY)
				), Color.White, false, false);
			}
			
			// Sum the scores.
			uint score = 0;
			for(int i = 0; i < Scores.Length; i++)
				score += Scores[i];
		
			// Draw the string to the screen.
			FontManager.DisplayString(
				"JuraBook",
				12,
				"" + score,
				Color.Orange,
				surface,
				new Point(
					(int) ((Location.X) * World.ScaleX),
					(int) ((Location.Y - 10) * World.ScaleY)
				),
				true,
				true
			);
        }
	}
}

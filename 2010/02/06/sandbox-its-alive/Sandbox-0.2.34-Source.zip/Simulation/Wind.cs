﻿using System;
using System.Drawing;

using SdlDotNet.Core;
using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;

namespace Sandbox.Simulation
{
	/// <summary>
	/// Adds a global wind to the level.
	/// </summary>
	public class Wind : Item
	{
		// Wind parameters.
		short MinDX;					// Minimum wind.
		short MaxDX;					// Maximum wind.
		
		/// <summary>
		/// Create a new wind.
		/// </summary>
		/// <param name="world">World.</param>
		/// <param name="minDX">Minimum wind.</param>
		/// <param name="maxDX">Maximum wind.</param>
		public Wind(World world, short minDX, short maxDX)
			: base(world, Point.Empty)
		{
			// Sanity check.
			if (minDX > maxDX)
				throw new Exception("Minimum wind must be less than or equal to maximum wind.");
			
			// Store the variables.
			MinDX = minDX;
			MaxDX = maxDX;
		}
		
		/// <summary>
        /// Update the Wind.
        /// </summary>
        internal override void Update()
        {
        	// HACK: Hard-coded values.  :(
        	double windShift = 30.0;
        	
        	// Use a nice sine wave to generate the wind.
        	World.DefaultDX = (short) Math.Round(((Math.Sin((double) World.Frames / windShift) / 2 + 0.5) * (MaxDX - MinDX) + MinDX));
        }
		
		/// <summary>
        /// Draw the Wind.
        /// </summary>
        /// <param name="surface">The surface to draw to.</param>
        internal override void Draw(Surface surface)
        {
        }
	}
}

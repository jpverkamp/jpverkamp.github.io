﻿using System;
using System.Drawing;

using SdlDotNet.Core;
using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;

namespace Sandbox.Simulation
{
	/// <summary>
	/// A source of particles.
	/// </summary>
	public class Source : Item
	{
		// Source parameters.
		short Type;						// The type of particles to generate.
		bool Enabled = true;			// True draws, false erases.
		int Radius;						// The radius of the source.
		
		/// <summary>
		/// Create a new source.
		/// </summary>
		/// <param name="world">The Source's world.</param>
		
		/// <param name="type">The type of particles to create.</param>
		public Source(World world, Point location, short type)
			: base(world, location)
		{
			Location = location;
			Type = type;
			Radius = Math.Max(1, World.RADIUS);
		}
		
		/// <summary>
        /// Update the Source.
        /// </summary>
        internal override void Update()
        {
        	// Update the location.
        	UpdateLocation();
        	
        	// Release particles.
    		for(int xd = Location.X - Radius; xd <= Location.X + Radius; xd++)
	    		for(int yd = Location.Y - Radius; yd <= Location.Y + Radius; yd++)
    				World.Set(xd, yd, (Enabled ? Type : (short) 0));
        }
		
		/// <summary>
        /// Draw the item.
        /// </summary>
        /// <param name="surface">The surface to draw to.</param>
        internal override void Draw(Surface surface)
        {
			// HACK: Just draw an outline in white for now.
			if(Enabled)
				surface.Draw(new Ellipse(
	        		(short) (World.DisplayRegion.X + (Location.X * World.ScaleX)),
					(short) (World.DisplayRegion.Y + (Location.Y * World.ScaleY)),
					(short) (Radius * World.ScaleX),
					(short) (Radius * World.ScaleY)
				), Color.White, false, false);
			
			// HACK: When erasing, draw a border of the color.
			else
	        	surface.Draw(new Ellipse(
	        		(short) (World.DisplayRegion.X + (Location.X * World.ScaleX)),
					(short) (World.DisplayRegion.Y + (Location.Y * World.ScaleY)),
					(short) (Radius * World.ScaleX),
					(short) (Radius * World.ScaleY)
				), World.Colors[Type], false, false);
        }
        
        /// <summary>
        /// Swap enabled state on button 1.
        /// </summary>
        internal override void Button1()
        {
        	Enabled = !Enabled;
        }
        
        /// <summary>
        /// Swap enabled state on button 2.
        /// </summary>
        internal override void Button2()
        {
        	Enabled = !Enabled;
        }
	}
}

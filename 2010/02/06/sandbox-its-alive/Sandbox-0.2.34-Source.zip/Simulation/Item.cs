﻿using System;
using System.Drawing;

using SdlDotNet.Core;
using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;

namespace Sandbox.Simulation
{
	/// <summary>
	/// An item that can alter the simulation world.
	/// </summary>
	public abstract class Item
	{
		// Item parameters.
		internal World World;				// The world the item is in.
		internal Point Location;			// The source's current location.
		
		// Item constants.
		const int MAXIMUM_VELOCITY = 3;		// Should not go faster than this.
		
		// Movement modes.
		ItemMovementMode Mode = ItemMovementMode.None;
		
		// Keyboard movement.
		Key[] Keys = new Key[6];			// Bound keys (UP, RIGHT, DOWN, LEFT, BUTTON1, BUTTON2)
		
		// Wandering.
		double WanderingChanceTurn;			// Chance to randomly turn when wandering (per frame).
		double WanderingChanceReverse;		// Chance to double back when wandering (per frame).
		double WanderingChanceButton1;		// Chance to activate button 1 (per frame).
		double WanderingChanceButton2;		// Chance to activate button 2 (per frame).
		short WanderingDX = 0;
		short WanderingDY = 0;
		
		/// <summary>
		/// Create a new item.
		/// </summary>
		/// <param name="world">The world the item belongs in.</param>
		/// <param name="location">Where in the world to create the Source.</param>
		public Item(World world, Point location)
		{
			World = world;
			Location = location;
			
			// Process mouse events.
			Events.MouseButtonDown += delegate(object sender, MouseButtonEventArgs e) { 
				if(Mode == ItemMovementMode.Mouse)
				{
					if(e.Button == MouseButton.PrimaryButton) Button1(); // BUTTON1
					if(e.Button == MouseButton.SecondaryButton) Button2(); // BUTTON2
				}
			};
			
			// Process keyboard events.
			Events.KeyboardDown += delegate(object sender, KeyboardEventArgs e) { 
				if(Mode == ItemMovementMode.Keyboard)
				{
					if(Keyboard.IsKeyPressed(Keys[4])) Button1();
					if(Keyboard.IsKeyPressed(Keys[5])) Button2();
				}
			};
		}
		
		/// <summary>
        /// Update the item.
        /// </summary>
        internal abstract void Update();
		
		/// <summary>
        /// Draw the item.
        /// </summary>
        /// <param name="surface">The surface to draw to.</param>
        internal abstract void Draw(Surface surface);
        
        /// <summary>
        /// Update the current location of the item (should be called during update).
        /// </summary>
        internal void UpdateLocation()
        {
        	// Follow the mouse around.
        	if(Mode == ItemMovementMode.Mouse)
        	{
        		// Get the mouse position in world coordinates.
        		int x = (int) ((Mouse.MousePosition.X - World.DisplayRegion.X) / World.ScaleX);
        		int y = (int) ((Mouse.MousePosition.Y - World.DisplayRegion.Y) / World.ScaleY);
        		
        		// Update the location.
        		Location = new Point(
        			Math.Max(0, Math.Min(World.Size.Width - 1, x)),
        			Math.Max(0, Math.Min(World.Size.Height - 1, y))
        		);
        	}
        	
        	// Follow the keyboard around.
        	else if (Mode == ItemMovementMode.Keyboard)
        	{
        		int dx = 0;
        		int dy = 0;
        		
        		if(Keyboard.IsKeyPressed(Keys[0])) dy -= MAXIMUM_VELOCITY;
        		if(Keyboard.IsKeyPressed(Keys[1])) dx += MAXIMUM_VELOCITY;
        		if(Keyboard.IsKeyPressed(Keys[2])) dy += MAXIMUM_VELOCITY;
        		if(Keyboard.IsKeyPressed(Keys[3])) dx -= MAXIMUM_VELOCITY;
        		
				Location = new Point(
        			Math.Max(0, Math.Min(World.Size.Width - 1, Location.X + dx)),
        			Math.Max(0, Math.Min(World.Size.Height - 1, Location.Y + dy))
        		);
        	}
        	
        	// Wander about semi-randomly.
        	else if (Mode == ItemMovementMode.Wander)
        	{
        		// Make sure that we are moving.
        		do 
        		{
	        		// Should we turn?
	        		if(World.Random.NextDouble() < WanderingChanceTurn)
	        		{
	        			// Keep x constant?
	        			if (World.Random.NextDouble() < 0.5)
	        				WanderingDY = (short) (World.Random.Next(-1, 2) * MAXIMUM_VELOCITY);
	        			
	        			// Otherwise, keep y constant.
	        			else
	        				WanderingDX = (short) (World.Random.Next(-1, 2) * MAXIMUM_VELOCITY);
	        		}
	        		
	        		// Should we reverse?
	        		if (World.Random.NextDouble() < WanderingChanceReverse)
	        		{
	        			WanderingDX *= -1;
	        			WanderingDY *= -1;
	        		}
        		} while(WanderingDX == 0 && WanderingDY == 0);
        		
        		// Should we activate the buttons?
        		if (World.Random.NextDouble() < WanderingChanceButton1) Button1();
        		if (World.Random.NextDouble() < WanderingChanceButton2) Button2();
        		
        		// Apply the movement.
        		Location = new Point(
        			Math.Max(0, Math.Min(World.Size.Width - 1, Location.X + WanderingDX)),
        			Math.Max(0, Math.Min(World.Size.Height - 1, Location.Y + WanderingDY))
        		);
        		
        		// Bounce off of walls.
        		if (Location.X == 0 || Location.X == World.Size.Width - 1) WanderingDX *= -1;
        		if (Location.Y == 0 || Location.Y == World.Size.Height - 1) WanderingDY *= -1;
        	}
        }
        
       	/// <summary>
       	/// Set the item movement mode.
       	/// </summary>
        public void FollowNone()
        {
        	Mode = ItemMovementMode.None;
        }
        
        /// <summary>
        /// This item should follow the mouse around.
        /// </summary>
        public void FollowMouse()
        {
        	Mode = ItemMovementMode.Mouse;
        }
        
        /// <summary>
        /// This item should follow keyboard commands.
        /// </summary>
        public void FollowKeyboard(Key up, Key right, Key down, Key left, Key button1, Key button2)
        {
        	FollowKeyboard(new Key[]{up, right, down, left, button1, button2});
        }
        
		/// <summary>
        /// This item should follow keyboard commands.
        /// </summary>
        public void FollowKeyboard(Key[] keys)
        {
        	Mode = ItemMovementMode.Keyboard;
        	Keys = keys;
        }
        
		/// <summary>
        /// This item should wander about semi-randomly.
        /// </summary>
        /// <param name="turn">Chance to turn per frame.</param>
		/// <param name="reverse">Chance to reverse per frame.</param>
		/// <param name="button1">Chance to activate button 1 per frame.</param>
		/// <param name="button2">Chance to activate button 2 per frame.</param>
        public void FollowWander(double turn, double reverse, double button1, double button2)
        {
        	Mode = ItemMovementMode.Wander;
        	
        	WanderingChanceTurn = turn;
        	WanderingChanceReverse = reverse;
        	WanderingChanceButton1 = button1;
        	WanderingChanceButton2 = button2;
        }
        
        		/// <summary>
		/// Override this to do something on button 1 presses / left clicks.
		/// </summary>
		internal virtual void Button1()
		{			
		}
		
		/// <summary>
		/// Override this to do something on button 2 presses / right clicks.
		/// </summary>
		internal virtual void Button2()
		{
		}
	}
	
	public enum ItemMovementMode {
		None,
		Mouse,
		Keyboard,
		Wander
	}
}

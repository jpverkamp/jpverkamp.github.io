﻿using System;
using System.Collections.Generic;
using System.Drawing;

using SdlDotNet.Core;
using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;

namespace Sandbox.Simulation
{
    /// <summary>
    /// The screen that does all of the simulation of an actual world.
    /// </summary>
    public class World
    {   
    	// Simulation parameters.
    	internal Random Random;				// Used to make the simulation seem more realistic.
    	internal Rectangle DisplayRegion;	// Region of the screen to draw the world to.
    	internal Size Size;					// Size of the world.
    	internal int GridSize;				// Size of the grid regions.
    	internal short[,] Type;				// Type of particle.
    	internal short[,] dX;				// Force in the x direction.
    	internal short[,] dY;				// Force in the y direction.
    	internal bool[,] Active;			// Active subregions.
    	internal bool[,] ActiveBuffer;		// Buffer for active subregions.
    	internal uint ParticleCount = 0;	// The current particle count.
    	internal double ScaleX;				// X scaling factor for display.
    	internal double ScaleY;				// Y scaling factor for display.
    	internal bool ForceRefresh = true;	// Force a refresh.
    	internal short DefaultDX = 0;		// The default x force.
    	internal short DefaultDY = 2;		// The default y force.
    	internal int Frames = 0;			// The number of frames that have passed.
    	
    	// Store the items.
    	internal Dictionary<string, Item> Items;
    	
    	// Control the border.
    	BorderMode CurrentBorderType = BorderMode.None;
    	internal BorderMode Borders { get { return CurrentBorderType; } set { CurrentBorderType = value; ForceRefresh = true; } }
    	
    	// Constants.
    	internal const int SOLIDS = 7;		// Number of solids (in the front of the color array).
    	internal const int WIGGLE_X = 2;	// Maximum wiggle room to spread out.
    	internal const int WIGGLE_Y = 1;	// Maximum wiggle room to spread out.
    	internal const int RADIUS = 3;		// Size of regions to place.
    	
    	// Display colors.
    	internal Color[] Colors = new Color[]{
    		// Empty
    		Color.Black,
    		
    		// Solids
    		Color.Brown,
    		Color.Red,
    		Color.Green,
    		Color.Blue,
    		Color.Yellow,
    		Color.SeaGreen,
    		Color.PaleGreen,

    		// Particles.
    		Color.White,
			Color.Gray,
			Color.Tan,
			Color.Bisque,
    	};
    	int[] RandomMod;
    	
    	// Accessor for particle count.
    	public uint Count { get { return ParticleCount; } }
    	
    	/// <summary>
    	/// Create a new world.
    	/// </summary>
    	/// <param name="display">The display region for the world.</param>
    	/// <param name="size">The size of the simulation.</param>
    	/// <param name="gridSize">The size of the grid points (should evenly divide size).</param>
        public World(Rectangle display, Size size, int gridSize)
        {
        	// Sanity check.
        	if (size.Width % gridSize != 0 || size.Height % gridSize != 0) throw new Exception("Grid must evenly divide size.");
        	
        	// Initialize parameters.
        	Random = new Random();
        	Size = size;
        	GridSize = gridSize;
        	Items = new Dictionary<string, Item>();
        	
        	// Initialize.
        	Type = new short[size.Width, size.Height];
        	dX = new short[size.Width, size.Height];
        	dY = new short[size.Width, size.Height];
        	Active = new bool[size.Width / gridSize, size.Height / gridSize];
        	ActiveBuffer = new bool[size.Width / gridSize, size.Height / gridSize];

        	// Build the random mod array.
        	RandomMod = new int[Size.Width];
        	for(int i = 0; i < RandomMod.Length; i++)
        		RandomMod[i] = Random.Next(-32, 33);
        	
        	// Perform the initial resize.
        	Resize(display);
        	
        	// Set up gravity.
        	SetForce(new Rectangle(0, 0, Size.Width, Size.Height), DefaultDX, DefaultDY);
        }
        
        /// <summary>
        /// Set the force in a given region.
        /// </summary>
        /// <param name="zone">The area to set the force in.</param>
        /// <param name="dx">Force in the x direction.</param>
        /// <param name="dy">Force in the y direction.</param>
        internal void SetForce(Rectangle zone, short dx, short dy)
        {
        	for(int x = zone.Left; x < zone.Right; x++)
        	{
        		for(int y = zone.Top; y < zone.Bottom; y++)
        		{
        			dX[x, y] = dx;
        			dY[x, y] = dy;
        		}
        	}
        }
        
        /// <summary>
        /// Set the type at a given point.
        /// </summary>
        /// <param name="x">X coordinate.</param>
        /// <param name="y">Y coordinate.</param>
        /// <param name="type">The type to set.</param>
        internal void Set(int x, int y, short type)
        {
        	// Do not process particles that are out of bounds.
        	if (x < 0 || x >= Size.Width || y < 0 || y >= Size.Height) return;
        	
        	// Update particle count.
        	if (Type[x, y] == 0 && type != 0) ParticleCount++;
        	if (Type[x, y] != 0 && type == 0) ParticleCount--;
        	
        	// Update the actual particle.
        	Type[x, y] = type;

        	// Something happened, this region is still active.
        	// Also active neighbors (to avoid blocky reactivations).
        	for (int i = x / GridSize - 1; i <= x / GridSize + 1; i++)
        		for (int j = y / GridSize - 1; j <= y / GridSize + 1; j++)
        			if (Borders == BorderMode.Wrap) {
        				ActiveBuffer[
        					(i + ActiveBuffer.GetLength(0)) % ActiveBuffer.GetLength(0),
        					(j + ActiveBuffer.GetLength(1)) % ActiveBuffer.GetLength(1)
        				] = true;
        			} else if (Borders != BorderMode.Wrap && i >= 0 && i < ActiveBuffer.GetLength(0) && j >= 0 && j < ActiveBuffer.GetLength(1))
        				ActiveBuffer[i, j] = true;
        }
        
        /// <summary>
        /// Set the type in the given region.
        /// </summary>
        /// <param name="zone">The zone to set.</param>
        /// <param name="type">The type to set.</param>
        internal void Set(Rectangle zone, short type)
        {
        	for(int x = zone.Left; x < zone.Right; x++)
        		for(int y = zone.Top; y < zone.Bottom; y++)
        			Set(x, y, type);
        }
        
		/// <summary>
		/// Resize the world to use a different display region.
		/// </summary>
		/// <param name="display"></param>
		internal void Resize(Rectangle display)
		{
			// Reset the values.
			DisplayRegion = display;
			ScaleX = (double) display.Width / (double) Size.Width;
        	ScaleY = (double) display.Height / (double) Size.Height;
        	
        	// Force a refresh.
        	ForceRefresh = true;
		}
        
        /// <summary>
        /// Update the world.
        /// </summary>
        internal void Update()
        {
        	// Update the frame count.
        	Frames++;
        	
        	// Reset the buffer and empty flags.
        	for(int i = 0; i < Active.GetLength(0); i++)
        		for(int j = 0; j < Active.GetLength(1); j++)
        			ActiveBuffer[i, j] = false;
        	
        	// Process only active regions.
        	for(int i = 0; i < Active.GetLength(0); i++)
        	{
        		for(int j = 0; j < Active.GetLength(1); j++)
        		{
        			// Ignore inactive regions.
        			if(!ForceRefresh && !Active[i, j]) continue;
        			
        			// Loop through the region's particles.
        			for(int x = i * GridSize; x < (i + 1) * GridSize; x++)
        			{
        				for(int y = j * GridSize; y < (j + 1) * GridSize; y++)
        				{
        					// Ignore empty spots and ones that have already moved.
        					if (Type[x, y] <= SOLIDS) continue;
        					if (Type[x, y] < 0) continue;
        					
        					// Get the target location.
        					int newX = x + dX[x, y] + Random.Next(-WIGGLE_X, WIGGLE_X + 1);
        					int newY = y + dY[x, y] + Random.Next(-WIGGLE_Y, WIGGLE_Y + 1);
        					
        					// Wrap borders are interesting.
        					if (Borders == BorderMode.Wrap)
        					{
        						newX = (newX + Size.Width) % Size.Width;
        						newY = (newY + Size.Width) % Size.Width;
        					}
        					
        					// Can we actually set the particle?
        					// Also simulate border conditions.
        					if ((Borders == BorderMode.None && (newX < 0 || newX >= Size.Width || newY < 0 || newY >= Size.Height || Type[newX, newY] == 0)) ||
        					    (Borders == BorderMode.Wall && (newX >= 0 && newX < Size.Width && newY >= 0 && newY < Size.Height && Type[newX, newY] == 0)) ||
        					    (Borders == BorderMode.Wrap && (Type[newX, newY] == 0)))
        					{
        						Set(newX, newY, (short) -Type[x, y]);
        						Set(x, y, 0);
        					}
        					
        					// Maintain activity if there are any empty spaces at all.
        					else {
        						bool done = false;
        						for(int xd = x + dX[x, y] - WIGGLE_X; xd <= x + dX[x, y] + WIGGLE_X; xd++)
        						{
        							for(int yd = y + dY[x, y] - WIGGLE_Y; yd <= y + dY[x, y] + WIGGLE_Y; yd++)
        							{
        								if (xd >= 0 && xd < Size.Width && yd >= 0 && yd < Size.Height && Type[xd, yd] == 0)
        								{
        									Set(x, y, Type[x, y]);
        									done = true;
        									break;
        								}
        							}
        							if (done) break;
        						}
        					}
        						
        				}
        			}
        			
        			// Done with this region.  Nothing to see here, move along.
        		}
        	}
        	
        	// Reset the force array to apply default forces.
        	// Items that modify the gravity array will have to do so each round.
        	SetForce(new Rectangle(0, 0, Size.Width, Size.Height), DefaultDX, DefaultDY);
        	
        	// Update items.
        	foreach(Item item in Items.Values)
        		item.Update();

        	// Apply the buffer.
        	for(int i = 0; i < Active.GetLength(0); i++)
        		for(int j = 0; j < Active.GetLength(1); j++)
        			Active[i, j] = ActiveBuffer[i, j];
        }
        
        /// <summary>
        /// Draw the world.
        /// </summary>
        /// <param name="surface">The surface to draw to.</param>
        internal void Draw(Surface surface)
        {
        	// Anyone can refresh a global refresh.
        	if (Sandbox.RequestRefresh == true)
        		ForceRefresh = true;
        	
        	// Draw only active regions.
        	for(int i = 0; i < Active.GetLength(0); i++)
        	{
        		for(int j = 0; j < Active.GetLength(1); j++)
        		{
        			// Ignore inactive regions.
        			if(!ForceRefresh && !Active[i, j]) continue;
        			
        			// Clear the region.
        			surface.Draw(new Box(
        				(short) (DisplayRegion.X + (i * GridSize * ScaleX)),
						(short) (DisplayRegion.Y + (j * GridSize * ScaleY)),
						(short) (DisplayRegion.X + (i * GridSize * ScaleX) + GridSize * ScaleX),
						(short) (DisplayRegion.Y + (j * GridSize * ScaleY) + GridSize * ScaleY)
					), Colors[0], false, true);   
        			
        			// Loop through the region's particles.
        			for(int x = i * GridSize; x < (i + 1) * GridSize; x++)
        			{
        				for(int y = j * GridSize; y < (j + 1) * GridSize; y++)
        				{
        					// Don't (re)drawn empty space.
        					if (Type[x, y] == 0) continue;
        					
        					// Fix ones that moved.
        					Type[x, y] = Math.Abs(Type[x, y]);
        					
        					// Draw particles.
        					int d = (int) ((x * y + DateTime.Now.Ticks) % RandomMod.Length);
        					Color c = Colors[Type[x, y]];
        					c = Color.FromArgb(
        						c.A,
        						Math.Min(255, Math.Max(0, c.R + RandomMod[(x * y) % RandomMod.Length])),
        						Math.Min(255, Math.Max(0, c.G + RandomMod[(x * y) % RandomMod.Length])),
        						Math.Min(255, Math.Max(0, c.B + RandomMod[(x * y) % RandomMod.Length]))
        					);
        					surface.Draw(new Box(
		        				(short) (DisplayRegion.X + (x * ScaleX)),
								(short) (DisplayRegion.Y + (y * ScaleY)),
								(short) (DisplayRegion.X + (x * ScaleX) + ScaleX),
								(short) (DisplayRegion.Y + (y * ScaleY) + ScaleY)
							), c, false, true);    					
        				}
        			}
        			
        			// Done with this region.  Nothing to see here, move along.
        		}
        	}
        	
        	// Draw items.
        	foreach(Item item in Items.Values)
        		item.Draw(surface);
        	
        	// Can only force a refresh for one frame at a time.
        	ForceRefresh = false;
        }
    }
    
    /// <summary>
    /// Different possible types of borders.
    /// </summary>
    enum BorderMode : byte {
    	None = 0,
    	Wall = 1,
    	Wrap = 2
    }
}

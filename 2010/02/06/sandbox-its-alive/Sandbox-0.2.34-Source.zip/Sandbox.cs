using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;
using SdlDotNet.Core;

using Sandbox.Screens;
using Sandbox.Simulation;
using Sandbox.Menus;

namespace Sandbox
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Sandbox
    {
    	// The screen manager to use for this Sandbox.
    	public static ScreenManager ScreenManager;
    	
    	// The surface that we should draw everything to.
    	Surface Surface;
    	
    	// Are we quitting?
    	public static bool Quitting = false;
    	public static bool RequestRefresh = false;
    	
        /// <summary>
        /// Entry point for the programm.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
        	// TODO: Process command line parameters.
        	
        	// Create a new Sandbox.
        	new Sandbox(args);
        }
        
        /// <summary>
        /// Create a new Sandbox simulation.
        /// </summary>
        /// <param name="args">Command line parameters.</param>
        public Sandbox(string[] args)
        {
        	// Program constants.
        	int fps = 30;
        	
        	// Display constants.
        	int border_width = 5;
        	int simulation_size = 256;
        	int simulation_scale = 2;
        	int matter_selector_size = 75;
        	bool allow_resize = true;
        	
        	// Load the game icon as a resource.
        	System.Resources.ResourceManager Manager = new System.Resources.ResourceManager(
        		"Sandbox.Resources", 
        		System.Reflection.Assembly.GetExecutingAssembly()
        	);
        	Icon gameIcon = (Icon) Manager.GetObject("GameIcon");
        	
        	// Initialize the display.
        	Video.WindowIcon(gameIcon);
			Video.WindowCaption = "Sandbox";
			Surface = Video.SetVideoMode(
				border_width * 3 + simulation_size * simulation_scale + matter_selector_size,
				border_width * 2 + simulation_size * simulation_scale,
				allow_resize
			);

			// Initialize the screen manager and add the main menu.
			ScreenManager = new ScreenManager();
			ScreenManager["Demo World"] = new DemoWorldScreen();
			ScreenManager["Main Menu"] = new MenuScreen(new MainMenu().GetDefinition(), true);
			
			// Bind to the event listeners.
			Events.VideoResize += new EventHandler<VideoResizeEventArgs>(Resize);
			Events.Quit += new EventHandler<QuitEventArgs>(Quit);
   			Events.Tick += new EventHandler<TickEventArgs>(Tick);
   			Events.Fps = fps;
   			Events.Run();
        }

		/// <summary>
		/// Resize the screen.
		/// </summary>
		/// <param name="sender">Where the event came from.</param>
		/// <param name="e">Resize event details.</param>
		private void Resize(object sender, VideoResizeEventArgs e)
		{
			Surface = Video.SetVideoMode(e.Width, e.Height, true);
			Video.Screen.Fill(Color.Black);
			ScreenManager.Resize(new Size(e.Width, e.Height));
		}
		
		/// <summary>
		/// Quit the program.
		/// </summary>
		/// <param name="sender">Where the event came from.</param>
		/// <param name="e">Quit event details.</param>
        private void Quit(object sender, QuitEventArgs e)
	    {
        	Quitting = true;
    	}

        /// <summary>
        /// Main loop, should be called based on the frameaate.
        /// </summary>
        /// <param name="sender">Where the event came from.</param>
        /// <param name="e">Tick event details.</param>
    	private void Tick(object sender, TickEventArgs e)
    	{
    		#region DEBUG: Display fps.
        	// Update the window title.
			Video.WindowCaption = "Sandbox - " + e.Fps + " FPS";
 			#endregion

    		// Update everything (if not paused).
    		ScreenManager.Update();
    		
        	// Then draw.
        	ScreenManager.Draw(Surface);
        	Surface.Update();
        	
        	// Should we quit?
        	if(Quitting)
        		Events.QuitApplication();
        	
        	// Only request refresh for one frame.
        	RequestRefresh = false;
		}
    }
}

﻿using System;

namespace Sandbox.Menus
{
	/// <summary>
	/// Menu definitions should implement this interface.
	/// </summary>
	public abstract class MenuDefinition
	{
		/// <summary>
		/// Get the menu definition.
		/// </summary>
		public abstract MenuItem[] GetDefinition();
	}
	
	/// <summary>
	/// Does nothing.  (You probably should use these).
	/// </summary>
	public class MenuItem
	{
		public string Title;
		
		public MenuItem(string title)
		{
			Title = title;
		}
	}
	
	/// <summary>
	/// Adds space.
	/// </summary>
	public class SpacerMenuItem : MenuItem
	{
		public SpacerMenuItem()
			: base("")
		{
		}
	}
	
	/// <summary>
	/// Calls a delegate method when clicked.
	/// </summary>
	public class ActionMenuItem : MenuItem
	{
		public Action<MenuItem[]> Action;
		
		public ActionMenuItem(string title, Action<MenuItem[]> action)
			: base(title)
		{
			Action = action;
		}
	}
	
	/// <summary>
	/// Cycle through a list of options.
	/// </summary>
	public class SelectionMenuItem : MenuItem
	{
		public string[] Choices;
		public int CurrentItem = 0;
		
		public SelectionMenuItem(string title, string[] choices)
			: base(title)
		{
			Choices = choices;
		}
	}
}

﻿using System;

using SdlDotNet.Input;
using SdlDotNet.Core;

using Sandbox.Screens;

namespace Sandbox.Menus
{
	/// <summary>
	/// The definition of the pause menu.
	/// </summary>
	public class PauseMenu : MenuDefinition
	{
		/// <summary>
		/// Get the menu definition.
		/// </summary>
		public override MenuItem[] GetDefinition()
		{
			return new MenuItem[]
			{
				// Keep playing.
				new ActionMenuItem(
					"Keep Playing",
					delegate {
						Sandbox.ScreenManager.Remove();
						Sandbox.RequestRefresh = true;
					}
				),
				
				// Return to menu.
				new ActionMenuItem(
					"Return To Menu",
					delegate {
						Sandbox.ScreenManager.Remove();
						Sandbox.ScreenManager.Remove();
						Sandbox.RequestRefresh = true;
					}
				),
			};
		}
	}
}

﻿using System;

using SdlDotNet.Input;
using SdlDotNet.Core;

using Sandbox.Screens;

namespace Sandbox.Menus
{
	/// <summary>
	/// The definition of the main menu.
	/// </summary>
	public class MainMenu : MenuDefinition
	{
		/// <summary>
		/// Get the menu definition.
		/// </summary>
		public override MenuItem[] GetDefinition()
		{
			return new MenuItem[]
			{
				// Number of players.
				new SelectionMenuItem(
					"Players",
					new string[]{
						"1",
						"2",
						"3",
						"4",
					}
				),
				
				// Number of AI players.
				new SelectionMenuItem(
					"AI Players",
					new string[]{
						"0",
						"1",
						"2",
					}
				),
				
				// Items.
//				new SelectionMenuItem("Magnets", new string[]{"Yes", "No"}),
				new SelectionMenuItem("Wind", new string[]{"Yes", "No"}),
				
				// Spacer.
				new SpacerMenuItem(),
				
				// Versus.
				new ActionMenuItem(
					"Play!",
					delegate(MenuItem[] menu) {
						// Default options.
						int players = 1;
						int ais = 1;
						bool magnet = true;
						bool wind = true;
						
						// Get the actual options.
						for(int i = 0; i < menu.Length; i++)
						{
							if(menu[i] is SelectionMenuItem)
							{
								SelectionMenuItem mi = menu[i] as SelectionMenuItem;
								if (mi.Title == "Players") players = int.Parse(mi.Choices[mi.CurrentItem]);
								if (mi.Title == "AI Players") ais = int.Parse(mi.Choices[mi.CurrentItem]);
								if (mi.Title == "Magnets") magnet = (mi.Choices[mi.CurrentItem] == "Yes");
								if (mi.Title == "Wind") wind = (mi.Choices[mi.CurrentItem] == "Yes");
							}
						}
						
						// Add the level.
						Sandbox.ScreenManager["Game"] = new GameScreen(players, ais, magnet, wind);
					}
				),
				
				// Spacer.
				new SpacerMenuItem(),
				
				// Quit.
				new ActionMenuItem(
					"Quit",
					delegate {
						Sandbox.Quitting = true;
					}
				),
			};
		}
	}
}

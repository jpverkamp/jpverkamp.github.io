﻿using System;
using System.Drawing;

using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;
using SdlDotNet.Core;

using Sandbox.Simulation;
using Sandbox.Resources;
using Sandbox.Menus;

namespace Sandbox.Screens
{
	/// <summary>
	/// The main menu.  Used to launch pretty much everything
	/// </summary>
	public class MenuScreen : Screen
	{
		// Store the menu definition.
		MenuItem[] Definition;
		
		// Currently selected item.
		int SelectedItem = 0;
		
		// Menu constants.
		// HACK: These should probably be parameters.
		const int FONT_SIZE = 36;
		const int FONT_SPACING = 40;
		
		/// <summary>
		/// Create a new main menu screen.
		/// </summary>
		public MenuScreen(MenuItem[] definition, bool allowUpdate)
			: base(allowUpdate, true)
		{
			// Store the menu definition.
			Definition = definition;
			
			// Process keyboard events.
			Events.KeyboardDown += delegate(object sender, KeyboardEventArgs e) { 
				// Make sure we were the one clicked.
				if (Manager.Top() == this)
				{
					// Change menu items.
					if(e.Key == Key.DownArrow) 
					{
						do {
							SelectedItem = (SelectedItem + 1) % Definition.Length;
						} while(Definition[SelectedItem] is SpacerMenuItem);
						Sandbox.RequestRefresh = true;
					}
					if(e.Key == Key.UpArrow)
					{
						do {
							SelectedItem = (SelectedItem - 1 + Definition.Length) % Definition.Length;
						} while(Definition[SelectedItem] is SpacerMenuItem);
						Sandbox.RequestRefresh = true;
					}
					
					// Change the selected item.
					if (e.Key == Key.LeftArrow && Definition[SelectedItem] is SelectionMenuItem)
					{
						SelectionMenuItem me = Definition[SelectedItem] as SelectionMenuItem;
						me.CurrentItem = (me.CurrentItem - 1 + me.Choices.Length) % me.Choices.Length;
						Sandbox.RequestRefresh = true;
					}
					if (e.Key == Key.RightArrow && Definition[SelectedItem] is SelectionMenuItem)
					{
						SelectionMenuItem me = Definition[SelectedItem] as SelectionMenuItem;
						me.CurrentItem = (me.CurrentItem + 1) % me.Choices.Length;
						Sandbox.RequestRefresh = true;
					}
					
					// Activate the item.
					if (e.Key == Key.Return && Definition[SelectedItem] is ActionMenuItem)
						(Definition[SelectedItem] as ActionMenuItem).Action(Definition);
					
					// Exit the game.
					if(e.Key == Key.Escape) Sandbox.Quitting = true;
				}
			};
			
			// Process mouse events.
			Events.MouseButtonDown += delegate(object sender, MouseButtonEventArgs e) { 
				// Make sure we were the one clicked.
				if (Manager.Top() == this)
				{
					
				}
			};
		}
		
		/// <summary>
		/// Resize the display.
		/// </summary>
		internal override void Resize(Size size)
		{
		}
		
		/// <summary>
		/// Update the display.
		/// </summary>
		internal override void Update()
		{
		}
		
        /// <summary>
		/// Draw the display.
		/// </summary>
		internal override void Draw(Surface surface)
		{
			// Generate the menu items.
			for(int i = 0; i < Definition.Length; i++)
			{
				// Get the menu string.
				string menuString = Definition[i].Title;
				
				// Add current choice to selection menu items.
				if (Definition[i] is SelectionMenuItem)
					menuString += ": " + (Definition[i] as SelectionMenuItem).Choices[(Definition[i] as SelectionMenuItem).CurrentItem];
				
				// Draw the string to the screen.
				FontManager.DisplayString(
					"JuraBook",
					FONT_SIZE,
					menuString,
					(SelectedItem == i ? Color.White : Color.Orange),
					surface,
					new Point(
						Video.Screen.Width / 2,
						Video.Screen.Height / 2 - (FONT_SPACING / 2 * Definition.Length) + (FONT_SPACING * i)
					),
					true,
					true
				);
			}
		}
	}
}

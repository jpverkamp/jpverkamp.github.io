﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

using SdlDotNet.Graphics;

namespace Sandbox.Screens
{
    /// <summary>
    /// The base class from which all screen inherit.
    /// 
    /// TODO: Add a way to force screens to refresh.
    /// </summary>
    public abstract class Screen
    {
        // Properties of this screen.
        internal ScreenManager Manager;
        internal readonly bool UpdateThrough;
        internal readonly bool DrawThrough;

        /// <summary>
        /// Create a new screen, setting the update and draw pass through options.
        /// </summary>
        /// <param name="manager">The manager managing this screen.</param>
        /// <param name="updateThrough">Determine if the screen below this one should be updated.</param>
        /// <param name="drawThrough">Determine if the screen below this one should be drawn.</param>
        public Screen(bool updateThrough, bool drawThrough)
        {
            // Store the screen properties.
            UpdateThrough = updateThrough;
            DrawThrough = drawThrough;
        }
        
        /// <summary>
        /// Call whenever the screen should be resized.
        /// </summary>
        /// <param name="size">The size to set the screen to.</param>
        internal abstract void Resize(Size size);

        /// <summary>
        /// Update the screens contained in the screen manager.
        /// </summary>
        internal abstract void Update();

        /// <summary>
        /// Draw the screens contained in the screen manager.
        /// </summary>
        /// <param name="surface">The surface to draw to.</param>
        internal abstract void Draw(Surface surface);
    }
}

﻿using System;
using System.Drawing;

using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;
using SdlDotNet.Core;

using Sandbox.Simulation;
using Sandbox.Resources;

namespace Sandbox.Screens
{
	/// <summary>
	/// A demonstrative world.
	/// </summary>
	public class DemoWorldScreen : Screen
	{
		// The background display.
		World Background;
		
		/// <summary>
		/// Create a new main menu screen.
		/// </summary>
		public DemoWorldScreen()
			: base(false, false)
		{
			// Generate a background world.
			Background = new World(
				new Rectangle(0, 0, Video.Screen.Width, Video.Screen.Height),
				new Size(300, 300),
				10
			);
			
			// Add four particle sources along the top.
        	for(int i = 0; i < 4; i++)
        		Background.Items["Source " + (i + 1)] = new Source(Background, new Point((i + 1) * Background.Size.Width / 5, 10), (short) (i + World.SOLIDS + 1));
        	
        	// Add four targets along the bottom.
        	for(int i = 0; i < 4; i++)
        		Background.Items["Target " + (i + 1)] = new Target(Background, new Point((i + 1) * Background.Size.Width / 5, Background.Size.Height - 10));
        	
        	// Add a few items.
        	
        	// A wall generator.
        	Background.Items["Wall"] = new Source(Background, new Point(1 * Background.Size.Width / 4, Background.Size.Height / 2), 0);
        	Background.Items["Wall"].FollowWander(0.01, 0.001, 0, 0);
        	
        	// An eraser.
        	Background.Items["Eraser"] = new Source(Background, new Point(3 * Background.Size.Width / 4, Background.Size.Height / 2), 1);
			Background.Items["Eraser"].FollowWander(0.01, 0.001, 0, 0);
        	
        	// Some wind.
        	Background.Items["Wind"] = new Wind(Background, -2, 2);
		}
		
		/// <summary>
		/// Resize the display.
		/// </summary>
		internal override void Resize(Size size)
		{
			Background.Resize(new Rectangle(0, 0, Video.Screen.Width, Video.Screen.Height));
		}
		
		/// <summary>
		/// Update the display.
		/// </summary>
		internal override void Update()
		{
			// Update the world.
			Background.Update();
		}
		
        /// <summary>
		/// Draw the display.
		/// </summary>
		internal override void Draw(Surface surface)
		{
			// Draw the background world.
			Background.Draw(surface);
			
			// Clear the screen.
			if (Background.Frames % (60 * 10) == 0)
			{              
				Background.Set(new Rectangle(0, 0, Background.Size.Width, Background.Size.Height), 0);
				Background.ForceRefresh = true;
			}
		}
	}
}

﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Text;

using SdlDotNet.Core;
using SdlDotNet.Graphics;

namespace Sandbox.Screens
{
    /// <summary>
    /// Keeps track of screens for a given game.
    /// </summary>
    public class ScreenManager
    {
        // Maintain a list of screens.
        LinkedList<Screen> Screens = new LinkedList<Screen>();

        // Keep a list of screens to add/remove so that update cycles don't break.
        LinkedList<Screen> ToAdd = new LinkedList<Screen>();
        int ToRemove = 0;
        
        // Keep a list of screen stored by ID.
        Dictionary<string, Screen> IndexedScreens = new Dictionary<string, Screen>();

        // Access screens by ID if necessary.
        public Screen this[string key] {
        	get {
        		foreach (string k in IndexedScreens.Keys)
        			if (k.Equals(key))
        			    return IndexedScreens[k];
        		return null;
        	}
        	
        	set {
        		Add(key, value);
        	}
        }

        /// <summary>
        /// Initialize the screen manager.
        /// </summary>
        public ScreenManager()
        {
        }

        /// <summary>
        /// Add a new screen to the top of the manager.
        /// </summary>
        /// <param name="id">The ID to identify the screen by.</param>
        /// <param name="screen">The new screen to add.</param>
        public void Add(String id, Screen screen)
        {
            ToAdd.AddLast(screen);
            IndexedScreens[id] = screen;
        }

        /// <summary>
        /// Remove the top screen.
        /// </summary>
        public void Remove(){
            ToRemove++;
        }

        /// <summary>
        /// The top screen.
        /// </summary>
        /// <returns>The top screen.</returns>
        public Screen Top()
        {
            if (Screens.Last == null)
                return null;
            else
                return (Screen)Screens.Last.Value;
        }

        /// <summary>
        /// Resize the screen.
        /// </summary>
        /// <param name="size">The new size.</param>
        public void Resize(Size size)
        {
        	// Pass the message along to each screen.
        	foreach (Screen screen in Screens)
        		screen.Resize(size);
        }
        	
        /// <summary>
        /// Update the screens contained in the screen manager.
        /// </summary>
        public void Update()
        {
            // Find the lowest screen to update.
            LinkedListNode<Screen> current = Screens.Last;
            
            // Keep going until we have a null screen or the update pass is false.
            while (current != null && current.Previous != null && ((Screen)current.Value).UpdateThrough)
                current = current.Previous;

            // Now go the other way and update the screens.
            while (current != null)
            {
                ((Screen)current.Value).Update();
                current = current.Next;
            }

            // Remove screens that need to be removed.
            while (ToRemove > 0)
            {
        		foreach (string key in IndexedScreens.Keys)
        			if (IndexedScreens[key].Equals(Screens.Last))
        				IndexedScreens.Remove(key);
        		
                Screens.RemoveLast();
                ToRemove--;
            }

            // Add screens that need to be added.
            foreach (Screen screen in ToAdd)
            {
                screen.Manager = this;
                Screens.AddLast(screen);
            }
            ToAdd.Clear();

            // If there are no screens, exit.
            if (Screens.First == null)
            	Events.QuitApplication();
        }

        /// <summary>
        /// Draw the screens contained in the screen manager.
        /// </summary>
        /// 
        public void Draw(Surface surface)
        {
            // Find the lowest screen to update.
            LinkedListNode<Screen> current = Screens.Last;

            // Keep going until we have a null screen or the draw pass is false.
            while (current != null && current.Previous != null && ((Screen)current.Value).DrawThrough)
                current = current.Previous;

            // Now go the other way and update the screens.
            while (current != null)
            {
                ((Screen)current.Value).Draw(surface);
                current = current.Next;
            }
        }
    }
}

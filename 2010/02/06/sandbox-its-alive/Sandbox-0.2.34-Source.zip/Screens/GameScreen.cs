﻿using System;
using System.Drawing;

using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;
using SdlDotNet.Core;

using Sandbox.Simulation;
using Sandbox.Resources;
using Sandbox.Menus;

namespace Sandbox.Screens
{
	/// <summary>
	/// A game world.
	/// </summary>
	public class GameScreen : Screen
	{
		// The background display.
		World Background;
		
		// Key definitions.
		Key[][] PlayerKeys = new Key[][]{
			new Key[]{Key.UpArrow, Key.RightArrow, Key.DownArrow, Key.LeftArrow, Key.RightShift, Key.RightControl},
			new Key[]{Key.W, Key.D, Key.S, Key.A, Key.LeftShift, Key.LeftControl},
			new Key[]{Key.I, Key.L, Key.K, Key.J, Key.P, Key.Semicolon},
			new Key[]{Key.Keypad8, Key.Keypad6, Key.Keypad2, Key.Keypad4, Key.KeypadMinus, Key.KeypadPlus},
		};
		
		/// <summary>
		/// Create a new game screen.
		/// </summary>
		/// <param name="players">Number of players.</param>
		/// <param name="ais">Number of (additional) AI players.</param>
		/// <param name="magnets">Allow players to be magnets?</param>
		/// <param name="wind">Add wind.</param>
		public GameScreen(int players, int ais, bool magnets, bool wind)
			: base(false, false)
		{
			// Generate a background world.
			Background = new World(
				new Rectangle(0, 0, Video.Screen.Width, Video.Screen.Height),
				new Size(300, 300),
				10
			);
			
			// Add four particle sources along the top.
			// TODO: One per player or always four?
        	for(int i = 0; i < 4; i++)
        		Background.Items["Source " + (i + 1)] = new Source(Background, new Point((i + 1) * Background.Size.Width / 5, 10), (short) (i + World.SOLIDS + 1));
        	
        	// Add the players.
        	for(int i = 0; i < players; i++)
        	{
        		Background.Items["Player " + (i + 1)] = new Source(Background, new Point((i + 1) * Background.Size.Width / (players + 1), Background.Size.Height / 2), (short) (i + 2));
        		Background.Items["Player " + (i + 1)].FollowKeyboard(PlayerKeys[i]);
        	}
        	
        	// Add the targets along the bottom.
        	for(int i = 0; i < players; i++)
        		Background.Items["Target " + (i + 1)] = new Target(Background, new Point((i + 1) * Background.Size.Width / (players + 1), Background.Size.Height - 10));
        	
        	// Add the ai players.
        	for(int i = 0; i < ais; i++)
        	{
        		Background.Items["AI Player " + (i + 1)] = new Source(Background, new Point((i + 1) * Background.Size.Width / (ais + 1), 3 * Background.Size.Height / 5), (short) (i + 6));
        		Background.Items["AI Player " + (i + 1)].FollowWander(0.01, 0.001, 0.01, 0);
        	}
        	
        	// Some wind.
        	if(wind)
	        	Background.Items["Wind"] = new Wind(Background, -2, 2);
        	
        	// Listen for the escape key to back up a level.
        	Events.KeyboardDown += delegate(object sender, KeyboardEventArgs e) { 
        		if (Manager.Top() == this)
        		{
        			if (e.Key == Key.Escape)
        			{
        				Manager["Pause Menu"] = new MenuScreen(new PauseMenu().GetDefinition(), false);
        				Sandbox.RequestRefresh = true;
        			}
        		}
        	};
		}
		
		/// <summary>
		/// Resize the display.
		/// </summary>
		internal override void Resize(Size size)
		{
			Background.Resize(new Rectangle(0, 0, Video.Screen.Width, Video.Screen.Height));
		}
		
		/// <summary>
		/// Update the display.
		/// </summary>
		internal override void Update()
		{
			Background.Update();
		}
		
        /// <summary>
		/// Draw the display.
		/// </summary>
		internal override void Draw(Surface surface)
		{
			Background.Draw(surface);
		}
	}
}

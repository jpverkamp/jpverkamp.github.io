﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Resources;

using SdlDotNet.Graphics;

namespace Sandbox.Resources
{
	/// <summary>
	/// Static class used to manage resources.
	/// </summary>
	public class FontManager
	{
		// Resource file to use.
		const string RESOURCE_FILE = "Sandbox.Resources";
		
		// Internal resource manager we're using.
		static System.Resources.ResourceManager Manager;
		
		// Font data we've loaded.
		static Dictionary<string, Font> FontData = new Dictionary<string, Font>();
		
		// Menu constants.
		// HACK: These should probably be parameters.
		const int SHADOW_DEPTH = 2;
		
		// Strings we've rendered to the buffer.
		//static Dictionary<string, Dictionary<int, Dictionary<string, Surface>>> StringBuffer = new Dictionary<string, Dictionary<int, Dictionary<string, Surface>>>();
		
		// Initialize the (static) resource manager.	
		static FontManager()
		{
			Manager = new System.Resources.ResourceManager(RESOURCE_FILE, Assembly.GetExecutingAssembly());
		}
		
		/// <summary>
		/// Render a string.
		/// </summary>
		/// <param name="fontName">The font to use to render the string.</param>
		/// <param name="fontSize">The size of the string to render.</param>
		/// <param name="text">The text to render.</param>
		/// <param name="useBuffer">True to buffer strings (avoid rerendering).</param>
		/// <returns>The font rendered to a surface.</returns>
		public static Surface RenderString(string fontName, int fontSize, string text, System.Drawing.Color color)
		{
			// TODO: Add font buffering.
			// Is this really necessary?
			
			// Get the font for rendering.
			Font font = LoadFont(fontName, fontSize);
			
			// Render the string.
			return font.Render(text, color);
		}
		
		/// <summary>
		/// Load a font.
		/// </summary>
		/// <param name="fontName">The font to load.</param>
		private static Font LoadFont(string fontName, int fontSize)
		{
			// Load font data, if requested.
			if (!FontData.ContainsKey(fontName + fontSize))
			{
				byte[] fontData = (byte[]) Manager.GetObject(fontName);
				FontData[fontName + fontSize] = new Font(fontData, fontSize);
				FontData[fontName + fontSize].Bold = true;
			}
			
			// Return the result.
			return FontData[fontName + fontSize];
		}

		/// <summary>
		/// Draw a string to the screen.
		/// </summary>
		/// <param name="fontName">The font name.</param>
		/// <param name="fontSize">The font size.</param>
		/// <param name="text">The text to draw.</param>
		/// <param name="color">Color of main text.</param>
		/// <param name="surface">Surface to draw to.</param>
		/// <param name="location">Location to draw at.</param>
		/// <param name="centered">Center the text.</param>
		/// <param name="shadowed">Draw a drop shadow.</param>
		public static void DisplayString(string fontName, int fontSize, string text, System.Drawing.Color color, Surface surface, System.Drawing.Point location, bool centered, bool shadowed)
		{
			// Render the strings.
			Surface textSurface = FontManager.RenderString(fontName, fontSize, text, color);
			Surface shadowSurface = FontManager.RenderString(fontName, fontSize, text, System.Drawing.Color.Black);
			
			
			// Get the string position.
			int stringX = location.X - (centered ? textSurface.Width / 2 : 0);
			int stringY = location.Y - (centered ? textSurface.Height / 2 : 0);
			
			// Draw them to the screen.
			surface.Blit(shadowSurface, new System.Drawing.Point(stringX + SHADOW_DEPTH, stringY + SHADOW_DEPTH));
			if(shadowed)
				surface.Blit(textSurface, new System.Drawing.Point(stringX, stringY));
		}
	}
}

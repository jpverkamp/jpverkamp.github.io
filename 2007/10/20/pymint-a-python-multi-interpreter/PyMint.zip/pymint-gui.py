import wx
import os
import time
import wx.aui

from xml.etree import ElementTree as ET

from pymint import Pymint

# ----------------------------------------------------------------------------
class PymintGUI(wx.App):
    """The GUI frontend for Pymint."""
    
    # -------------------------------------
    def OnInit(self):
        """Initilize the GUI."""
        
        # initilize the frame
        self.frame = PymintGUIFrame()
        self.SetTopWindow(self.frame)
        
        # worked
        return True
    
# ----------------------------------------------------------------------------
class PymintGUIFrame(wx.Frame):
    """The main window for the Pymint GUI."""
        
    # file menu
    ID_MENU_FILE        = 1000
    ID_MENU_FILE_NEW    = 1001
    ID_MENU_FILE_OPEN   = 1002
    ID_MENU_FILE_SAVE   = 1003
    ID_MENU_FILE_CLOSE  = 1004
    ID_MENU_FILE_EXIT   = 1005
    
    # run menu (will be built dynamically)
    ID_MENU_RUN         = 2000
    
    # help menu
    ID_MENU_HELP        = 3000
    ID_MENU_HELP_ABOUT  = 3001
    
    # store the known run methods
    methods = {}
    
    # -------------------------------------
    def __init__(self):
        """Initilize the frame."""
        
        # build the frame
        wx.Frame.__init__(self, None, -1, "Pymint", wx.DefaultPosition, wx.Size(600, 500))
        
        # build the menus
        menubar = wx.MenuBar()
        
        # file menu
        menu = wx.Menu()
        menu.Append(self.ID_MENU_FILE_NEW,   "&New\tCtrl-N",  "Create a new text file")
        menu.Append(self.ID_MENU_FILE_OPEN,  "&Open\tCtrl-O", "Open a file stored on disk")
        menu.Append(self.ID_MENU_FILE_SAVE,  "&Save\tCtrl-S", "Save the current file to disk")
        menu.Append(self.ID_MENU_FILE_CLOSE, "&Close\tCtrl-W", "Close the current file")
        menu.AppendSeparator()
        menu.Append(self.ID_MENU_FILE_EXIT,  "E&xit", "Exit the program")
        menubar.Append(menu, "&File")
        
        # initilize a couple of things
        self.panels = []
        self.newID = 1
        
        # bind the file menu events
        self.Bind(wx.EVT_MENU, self.OnNew,   id = self.ID_MENU_FILE_NEW)
        self.Bind(wx.EVT_MENU, self.OnOpen,  id = self.ID_MENU_FILE_OPEN)
        self.Bind(wx.EVT_MENU, self.OnSave,  id = self.ID_MENU_FILE_SAVE)
        self.Bind(wx.EVT_MENU, self.OnClose, id = self.ID_MENU_FILE_CLOSE)
        self.Bind(wx.EVT_MENU, self.OnExit,  id = self.ID_MENU_FILE_EXIT)
        
        # run menu (dynamically generated)
        menu = wx.Menu()
        
        # get the xml files
        index = self.ID_MENU_RUN
        dirlist = os.listdir("data\\")
        for filename in dirlist:
            # increment the index
            index += 1
            
            # get the new filename
            filename = os.path.join("data", filename)
            self.methods[index] = filename
            
            # load the xml language definition
            tree = ET.parse(filename)
            root = tree.getroot()
        
            # get the language title
            try:
                title = root.attrib.get("title")
            except:
                title = filename
                
            # create the menu item
            menu.Append(index, title, "Runs '" + title + "'")
            
            # bind the event
            self.Bind(wx.EVT_MENU, self.OnRun, id = index)
            
        # add the menu
        menubar.Append(menu, "&Run")
        
        ## # help menu
        ## menu = wx.Menu()
        ## menu.Append(self.ID_MENU_HELP_ABOUT, "&About", "About Pymint")
        ## menubar.Append(menu, "&Help")
        
        ## # bind the help menu events
        ## self.Bind(wx.EVT_MENU, self.OnAbout, id = self.ID_MENU_HELP_ABOUT)
        
        # actually add the menu
        self.SetMenuBar(menubar)
        
        # create the Notebook
        self.notes = wx.aui.AuiNotebook(self)
        
        # add a first default panel
        self.OnNew(None)

        # add everything
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.notes, 1, wx.EXPAND)
        self.SetSizer(sizer)
        self.SetAutoLayout(True)
        
        # bind the keyboard events
        # TODO: fix this
        
        # show the frame
        self.Show(True)

    # -------------------------------------
    def OnKeyDown(self, event):
        """The user pressed some keys."""

        # figure out what's going on
        key = event.KeyCode()
        ctrl = event.ControlDown()
        alt = event.AltDown()

        # keyboard alias for menu items
        if ctrl and key == wx.WXK_N:  self.OnNew()
        if ctrl and key == wx.WXK_O:  self.OnOpen()
        if ctrl and key == wx.WXK_S:  self.OnSave()        
        if ctrl and key == wx.WXK_W:  self.OnClose()
        if alt  and key == wx.WXK_F4: self.onExit()
        
        # get the current page
        curr = self.notes.GetSelection()
        page = self.notes.GetPage(curr)
        
        print page
        
        # keyboard alias for edit items
        if ctrl and key == wx.WXK_A:  page.SelectAll()
        if ctrl and key == wx.WXK_X:  page.Cut()
        if ctrl and key == wx.WXK_C:  page.Copy()
        if ctrl and key == wx.WXK_V:  page.Paste()
        if ctrl and key == wx.WXK_Z:  page.Undo()
        if ctrl and key == wx.WXK_Y:  page.Redo()
    
    # -------------------------------------
    def OnNew(self, event):
        """Creates a new document."""
        
        # create a new scrolled text thing
        page = wx.TextCtrl(self.notes, -1, '', style=wx.TE_MULTILINE)
        
        # add it to the panel listing
        self.panels.append(page)
        
        # show it on the notebook
        self.notes.AddPage(page, 'New Document ' + str(self.newID))
        self.newID += 1

    # -------------------------------------
    def OnOpen(self, event):
        """Opens a saved document."""
        
        # create the dialog
        dlg = wx.FileDialog(
            self, message = "Open file",
            defaultDir = os.getcwd(), 
            defaultFile = "",
            wildcard = "All files (*.*)|*.*",
            style = wx.OPEN | wx.CHANGE_DIR
        )

        # show the response
        if dlg.ShowModal() == wx.ID_OK:
            # grab the filename
            filename = dlg.GetPaths()[0]
            
            # open it
            f = open(filename, "r")
            text = ""

            # read each line
            try:
                for line in f:
                    text += line
            finally:
                f.close()
            
            # create a new scrolled text thing
            page = wx.TextCtrl(self.notes, -1, text, style=wx.TE_MULTILINE)
        
            # add it to the panel listing
            self.panels.append(page)
        
            # show it on the notebook
            self.notes.AddPage(page, os.path.basename(filename))
            
            # select the new page
            self.notes.SetSelection(self.notes.GetPageCount() - 1)

    # -------------------------------------
    def OnSave(self, event):
        """Saves the current document."""
        
        # create the dialog
        dlg = wx.FileDialog(
            self, message = "Save file",
            defaultDir = os.getcwd(), 
            defaultFile = "",
            wildcard = "All files (*.*)|*.*",
            style = wx.SAVE | wx.CHANGE_DIR
        )

        # show the response
        if dlg.ShowModal() == wx.ID_OK:
            # get the current notebook page
            curr = self.notes.GetSelection()

            # get the results
            filename = dlg.GetPaths()[0]

            # open it
            f = open(filename, "w")
            
            # get the text
            page = self.notes.GetPage(curr)
            selfrom, seltrue = page.GetSelection()
            page.SelectAll()
            text = page.GetStringSelection()
            page.SetSelection(selfrom, seltrue)
            
            # write the file
            try:
                f.write(text)
            finally:
                f.close()

            # set to the new filename
            self.notes.SetPageText(curr, os.path.basename(filename))
 
    # -------------------------------------
    def OnClose(self, event):
        """Closes the current document."""
        
        # get the current notebook page
        curr = self.notes.GetSelection()
        
        # remove it from the notes
        self.notes.RemovePage(curr)
        
        # if there are no pages, make one
        if self.notes.GetPageCount() == 0:
            self.OnNew(None)
            
        # now change to the last page
        self.notes.SetSelection(self.notes.GetPageCount() - 1)
               
    # -------------------------------------
    def OnExit(self, event):
        """The user wants to exit."""
        
        # close
        self.Close()
        
    # -------------------------------------
    def OnRun(self, event):
        """Saves the current document."""
        
        # get the current notebook
        curr = self.notes.GetSelection()
        title = self.notes.GetPageText(curr)
        
        # get the text
        page = self.notes.GetPage(curr)
        selfrom, seltrue = page.GetSelection()
        page.SelectAll()
        text = page.GetStringSelection()
        page.SetSelection(selfrom, seltrue)
        
        # build the conversion object
        p = Pymint(self.methods[event.GetId()])
        
        # run it
        text = p.run(text)
        
        # add a new scrolled text thing
        page = wx.TextCtrl(self.notes, -1, text, style=wx.TE_MULTILINE)
        self.panels.append(page)
        self.notes.AddPage(page, title + " (" + p.title + ")")
        
        # select the new page
        self.notes.SetSelection(self.notes.GetPageCount() - 1)

    # -------------------------------------
    def OnAbout(self, event):
        """Shows the about dialog."""
        
        print "OnAbout"

# ----------------------------------------------------------------------------
if __name__ == "__main__":
        gui = PymintGUI(0)
        gui.MainLoop()
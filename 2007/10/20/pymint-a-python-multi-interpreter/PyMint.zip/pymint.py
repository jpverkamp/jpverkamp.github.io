import cbase
import re
from xml.etree import ElementTree as ET

# ----------------------------------------------------------------------------
class Pymint:
    """A Python Multi-Interpreter for a variety of xml language files."""

    # no known title
    title = ""

    # store prerun and postrun code
    precode = ""
    postcode = ""
    
    # store all known patterns
    patterns = []

    # ---------------------------------
    def __init__(self, filename):
        """Load a language definition from an xml file."""
        
        # load the xml language definition
        tree = ET.parse(filename)
        root = tree.getroot()
        
        # get the language title
        try:
            self.title = root.attrib.get("title")
        except:
            self.title = filename
        
        # start parsing it
        for section in root.getchildren():
            # code blocks
            if section.tag == "code":
                # go through the different code block
                for subsection in section.getchildren():
                    # pre code
                    if subsection.tag == "pre":
                        self.precode = subsection.text.strip()

                    # post code
                    if subsection.tag == "post":
                        self.postcode = subsection.text.strip()

            # known commands
            if section.tag == "commands":
                # loop through the commands
                for subsection in section.getchildren():
                    # get the pattern and code
                    regex = subsection.attrib.get("regex")
                    code = subsection.text.strip()
                    
                    # store the pattern
                    self.patterns.append((regex, code))

    # ---------------------------------
    def run(self, input):
        """Runs the currently loaded xml file on a given piece of code."""
        
        # initilize the result
        output = ""
        
        # first run the prerun code
        exec(self.precode)
        
        # now run through the lines, executing as we go
        lines = input.split("\n")
        index = 0
        count = 0
        while True:
            # get the current line
            # if we don't have that line, break away
            try:
                line = lines[index]
            except:
                break
            
            # check each pattern
            for regex, code in self.patterns:
                # try to match the pattern
                match = re.match(regex, line)
                
                # if there were any results, run the associated code
                # the matched groups will be assigned to arg[i]
                if match:
                    # set the args
                    arg = match.groups()
                    # print regex, "\t", " ".join(arg)#, "\t", stack, "\t", depth, "\n"#, code, "\n"
                    exec(code)
                    
                    # only one command can match, they will be exectued in the
                    # order of the xml file
                    break
                
                # break if error has been set
                if error:
                    break
            
            # break if error has been set
            if error:
                break
            
            # otherwise, keep going
            index += 1
            count += 1
            
            # if we keep going for 100,000 lines, something probably broke
            # infinite loop?
            # TODO: add a better lest for infinite loops
            if count % 1000 == 999:
                print count + 1
            if count >= 100000:
                error = 1
                output = "Possible infinite loop detected.  Aborting execution."
                break
        
        # finally run the postrun code
        exec(self.postcode)
        
        # return the result
        return output

# ----------------------------------------------------------------------------
if __name__ == "__main__":
    # get the object
    # p = Pymint("data/rhij-run.xml")
    p = Pymint("data/rhij-assemble.xml")
    
    # run some sample code
    print p.run("\n".join(open("mike.rhij", "r").readlines()).strip())
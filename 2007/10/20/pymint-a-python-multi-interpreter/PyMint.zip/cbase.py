# ----------------------------------------------------------------------------
def dec2hex(dec, bytes = 4, signed = True):
    """Convert a decimal value to hex."""
    
    # calculate the value
    bin = dec2bin(dec, bytes, signed)
    hex = bin2hex(bin)
    
    # return it
    return hex

# ----------------------------------------------------------------------------
def dec2bin(dec, bytes = 4, signed = True):
    """Converts a decimal value to binary."""
    
    # make sure we have an integer
    dec = int(dec)
    
    # determine the minimum and maximum values
    if signed:
        min = -1 * (2 ** (bytes * 7))
        max = 2 ** (bytes * 7) - 1
        mod = 2 ** (bytes * 8)
    else:
        min = 0
        max = 2 ** (bytes * 8)
        mod = 2 ** (bytes * 8)
        
    # do we need to invert it?
    flip = False
    if dec < 0:
        flip = True
        dec = -dec
        
    # fix the value in the correct range
    while dec < min: dec += mod
    while dec > max: dec -= mod
    
    # initilize the result
    res = ""
    
    # build the string
    while dec > 0:
        res = str(dec % 2) + res
        dec /= 2
        
    # expand to the proper length
    while len(res) < bytes * 8:
        res = "0" + res
        
    # if we don't have to flip, we're done
    if not flip:
        return res
    
    # otherwise, it's inversion time
    newres = ""
    c = True
    for i in range(len(res)):
        if  res[-i] == "0" and      c: # 1 & 1
            newres = "0" + newres
            c = True
        elif res[-i] == "0" and not c: # 1 & 0
            newres = "1" + newres
            c = False
        elif res[-i] == "1" and     c: # 0 & 1
            newres = "1" + newres 
            c = False
        elif res[-i] == "1" and not c: # 0 & 0
            newres = "0" + newres
            c = False
    
    # return the result
    return "1" + newres[:-1]

# ----------------------------------------------------------------------------
def bin2hex(bin):
    """Convert a binary number to hex."""
    
    # store the hex values
    hexvals = ['0', '1', '2', '3', '4', '5', '6', '7',
               '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'] 
    
    # initilize the result
    res = []
    
    # loop
    for i in range(len(bin) / 8):
        h0 = hex(int(bin[i * 8 + 0 : i * 8 + 4], 2))[-1]
        h1 = hex(int(bin[i * 8 + 4 : i * 8 + 8], 2))[-1]
        res.append("0x" + h0 + h1)
        
    # return the result
    return " ".join(res)

# ----------------------------------------------------------------------------
def hex2dec(hex, signed = False):
    """Convert a hex value to decimal."""
    
    # convert
    bin = hex2bin(hex)
    dec = bin2dec(bin, signed)
    
    # return the decimal value
    return dec
    
# ----------------------------------------------------------------------------
def bin2dec(bin, signed = False):
    """Convert a binary value to decimal."""
    
    # are we inverting?
    if not signed or not bin[0] == "1":
        return int(bin, 2)
    
    # otherwise, it's inversion time
    
    # invert it
    res = "".join([x == "1" and "0" or "1" for x in bin])
    
    # return the result
    return -int(res[1:], 2) - 1
    
# ----------------------------------------------------------------------------
def hex2bin(hex):
    """Convert a hex value to decimal."""
    
    # result
    result = ""
    
    # bin values
    binvals = ['0000', '0001', '0010', '0011', '0100', '0101', '0110', '0111',
               '1000', '1001', '1010', '1011', '1100', '1101', '1110', '1111']
    
    # break it apart
    for byte in hex.split(" "):
        for halfbyte in byte[-2:]:
            result += binvals[int(halfbyte, 16)]
        
    # return result
    return result
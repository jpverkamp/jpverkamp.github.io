from OpenGL.GL   import *
from OpenGL.GLUT import *
from OpenGL.GLU  import *

import math
import random

from Ball import Ball

# ----------------------------------------------------------------------------
class MovingBall(Ball):
    """A Ball that moves about the screen."""
    
    # name
    name = "MovingBall"
    
    # the MovingBall is Blue
    color = (  0,   0, 255, 255)
    
    # ---------------------------------
    def __init__(self):
        """Create a new MovingBall."""
        
        # use the Ball's method
        Ball.__init__(self)
        
        # generate a random velocity
        mod = 0.01
        self.vel = (random.random() * mod * 2.0 - mod,
                    random.random() * mod * 2.0 - mod,
                    random.random() * mod * 2.0 - mod)
        
    # ---------------------------------
    def Act(self):
        """Update the ball."""
        
        # use the Ball's method
        Ball.Act(self)
        
        # update self.position
        self.pos = (self.pos[0] + self.vel[0],
                    self.pos[1] + self.vel[1],
                    self.pos[2] + self.vel[2])
         
        # check wall intersections
        self.CheckWall()
                    
    # ---------------------------------
    def CheckWall(self):
        """Check for wall intersections."""
        
        # hit a wall
        for i in range(3):
            # new velocity and position
            newpos = list(self.pos)
            newvel = list(self.vel)
            
            # hit negative
            if newpos[i] - self.radius <= -1:
                newvel[i] = math.fabs(newvel[i])
                newpos[i] = -1.0 + self.radius
                
            # hit positive
            elif newpos[i] + self.radius >= 1:
                newvel[i] = -1.0 * math.fabs(newvel[i])
                newpos[i] = 1.0 - self.radius
                
            # store the new values
            self.vel = tuple(newvel)
            self.pos = tuple(newpos)
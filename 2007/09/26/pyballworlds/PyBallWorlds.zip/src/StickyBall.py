from OpenGL.GL   import *
from OpenGL.GLUT import *
from OpenGL.GLU  import *

import math
import random

from BouncingBall import BouncingBall

# ----------------------------------------------------------------------------
class StickyBall(BouncingBall):
    """A ball that sticks to other balls when they hit each other."""
    
    # name
    name = "StickyBall"
    
    # a StickyBall is Red
    color = (255,   0,   0, 255)
    
    # ---------------------------------
    def __init__(self):
        """Create a new ball."""
        
        # use the parent class
        BouncingBall.__init__(self)
                
    # ---------------------------------
    def Act(self):
        """Update the ball."""
        
        # use the parent class
        BouncingBall.Act(self)

    # ---------------------------------
    def Impact(self, other):
        """The ball just hit another one."""
        
        # use parent class
        BouncingBall.Impact(self, other)
        
        # stick to pretty much aything
        self.vel = other.vel = (0.0, 0.0, 0.0)
        self.acc = other.acc = (0.0, 0.0, 0.0)
                    
    # ---------------------------------
    def SetPos(self, i, pos):
        """Set a position value."""
        
        # position as a set
        newpos = [self.pos[0], self.pos[1], self.pos[2]]
        newpos[i] = pos
        
        # store the value
        self.pos = tuple(newpos)
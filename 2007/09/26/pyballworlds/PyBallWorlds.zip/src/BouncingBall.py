from OpenGL.GL   import *
from OpenGL.GLUT import *
from OpenGL.GLU  import *

import math
import random

from MovingBall import MovingBall

# ----------------------------------------------------------------------------
class BouncingBall(MovingBall):
    """A Ball that moves about the screen, bouncing off of others."""
    
    # name
    name = "BouncingBall"
    
    # the BouncingBall is Pink
    color = (255,  20, 147, 255)
    
    # ---------------------------------
    def __init__(self):
        """Create a new BouncingBall."""
        
        # use the Ball's method
        MovingBall.__init__(self)
        
    # ---------------------------------
    def Act(self):
        """Update the ball."""
        
        # use the Ball's method
        MovingBall.Act(self)

    # ---------------------------------
    def Impact(self, other):
        """The ball just hit another one."""
        
        # flip the velocity
        self.vel = (-self.vel[0], -self.vel[1], -self.vel[2])
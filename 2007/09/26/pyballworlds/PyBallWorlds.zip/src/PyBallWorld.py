from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

import random
import time
import sys
import math

from Ball         import Ball
from MovingBall   import MovingBall
from StickyBall   import StickyBall
from BouncingBall import BouncingBall

# ----------------------------------------------------------------------------
class PyBallWorld:
    """Represents the World in a PyBallWorld simulation."""

    # Number of the glut window.
    window = 0

    # keep track of the frame counter
    frames = 0

    # keep track of my position and angle
    pos = (0.0, 0.0, 6.0)
    hAng = 0.0
    vAng = 0.0

    # keep track of the balls
    balls = []

    # ---------------------------------
    def InitGL(self, Width, Height):
        """Initilizes the OpenGL engine."""
        
        # do a bunch of GL init stuff
        glClearColor(0.0, 0.0, 0.0, 0.0)
        glClearDepth(1.0)
        glDepthFunc(GL_LESS)
        glEnable(GL_DEPTH_TEST)
        glShadeModel(GL_SMOOTH)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45.0, float(Width) / float(Height), 0.1, 100.0)
        glMatrixMode(GL_MODELVIEW)
        
        # enable blending
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    # ---------------------------------
    def ResizeGLScene(self, Width, Height):
        """Correctly resize the OpenGL scene when we need to."""
        
        # prevent a divide by zero error
        if Height == 0:
            Height = 1

        # resize the windows
        glViewport(0, 0, Width, Height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(45.0, float(Width) / float(Height), 0.1, 100.0)
        glMatrixMode(GL_MODELVIEW)

    # ---------------------------------
    def DrawGLScene(self):
        """Draw the World."""
    
        # increment the frame counter
        self.frames += 1
    
        # clear the screen
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        glLoadIdentity()
    
        # translate and rotate as needed
        glTranslate(0.0, 0.0, -5.0)
        glRotatef(-self.hAng, 0.0, 1.0, 0.0)
        glRotatef(-self.vAng, 1.0, 0.0, 0.0)
        
        # define the walls
        points = [
            # bottom of the box
            (-1, -1, -1), (-1,  1, -1), 
            (-1,  1, -1), (-1,  1,  1), 
            (-1,  1,  1), (-1, -1,  1),
            (-1, -1,  1), (-1, -1, -1),
            
            # top of the box
            ( 1, -1, -1), ( 1,  1, -1), 
            ( 1,  1, -1), ( 1,  1,  1), 
            ( 1,  1,  1), ( 1, -1,  1),
            ( 1, -1,  1), ( 1, -1, -1),
                  
            # vertical bars
            (-1, -1, -1), ( 1, -1, -1),
            (-1,  1, -1), ( 1,  1, -1),
            (-1,  1,  1), ( 1,  1,  1),
            (-1, -1,  1), ( 1, -1,  1)
        ]

        # draw the box
        glColor4f(1.0, 1.0, 1.0, 1.0)
        glBegin(GL_LINES)
        for point in points:
            glVertex3f(*point)
        glEnd()

        # draw the balls
        for ball in self.balls:
            # draw the ball
            ball.Draw()
            
            # make the ball act
            ball.Act()
            
            # check for impacts with other balls
            for other in self.balls:
                # calculate the distance between center points
                dist = math.sqrt((ball.pos[0] - other.pos[0]) * (ball.pos[0] - other.pos[0]) + 
                                 (ball.pos[1] - other.pos[1]) * (ball.pos[1] - other.pos[1]) + 
                                 (ball.pos[2] - other.pos[2]) * (ball.pos[2] - other.pos[2]))
                                 
                # what's the margin of error
                rads = ball.radius + other.radius
                
                # the hit each other
                if dist <= rads and dist != 0:
                    ball.Impact(other)
                    other.Impact(ball)
        
        # yay, easy double buffering
        glutSwapBuffers()

    # ---------------------------------
    def KeyPressed(self, key, mouseX, mouseY):
        """A key was pressed."""
        
        # find the modifiers
        mod = glutGetModifiers()
        ctrl  = mod & GLUT_ACTIVE_CTRL
        shift = mod & GLUT_ACTIVE_SHIFT
        alt   = mod & GLUT_ACTIVE_ALT
        
        # escape exist
        if key == '\033' or (alt and key == GLUT_KEY_F4):
            print str(int(self.frames / (time.time() - self.now))) + " fps"
            sys.exit()
        
        # move forward
        if key == GLUT_KEY_UP:
            self.vAng -= 1.0
            while self.vAng < 0: self.vAng += 360
        
        # move backwards
        if key == GLUT_KEY_DOWN:
            self.vAng += 1.0
            while self.vAng > 360: self.vAng -= 360
        
        # rotate left
        if key == GLUT_KEY_LEFT:
            self.hAng -= 1.0
            while self.hAng < 0: self.hAng += 360
        
        # rotate right
        if key == GLUT_KEY_RIGHT:
            self.hAng += 1.0
            while self.hAng > 360: self.hAng -= 360
        
        # print the frame rate
        if key == 'f':
            print str(int(self.frames / (time.time() - self.now))) + " fps"
        
        # speed factor
        mult = 2
        
        # speed up
        if key == '+' or key == '=':
            for ball in self.balls:
                ball.vel = (ball.vel[0] * mult, ball.vel[1] * mult, ball.vel[2] * mult)
                ball.acc = (ball.acc[0] * mult, ball.acc[1] * mult, ball.acc[2] * mult)

        # slow down
        if key == '_' or key == '-':
            for ball in self.balls:
                ball.vel = (ball.vel[0] * 1.0 / mult, ball.vel[1] * 1.0 / mult, ball.vel[2] * 1.0 / mult)
                ball.acc = (ball.acc[0] * 1.0 / mult, ball.acc[1] * 1.0 / mult, ball.acc[2] * 1.0 / mult)
            
        # clear the ball list
        if key == 'c':
            self.balls = []
            
        # add some balls
        if key == '1': self.balls.append(Ball())
        if key == '2': self.balls.append(MovingBall())
        if key == '3': self.balls.append(BouncingBall())
        if key == '4': self.balls.append(StickyBall())

    # ---------------------------------
    def Run(self):
        """Run the main program."""
    
        # initilize
        glutInit(sys.argv)

        # set the display mode
        glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH)

        # create the window
        glutInitWindowSize(640, 480)
        glutInitWindowPosition(100, 100)
        window = glutCreateWindow("PyBallWorld")

        # glutFullScreen()

        # define a bunch of cool GLUT functions
        glutDisplayFunc(self.DrawGLScene)
        glutIdleFunc(self.DrawGLScene)
        glutReshapeFunc(self.ResizeGLScene)
        glutKeyboardFunc(self.KeyPressed)
        glutSpecialFunc(self.KeyPressed)

        # initilize the window
        self.InitGL(640, 480)

        # start the timer, start running
        self.now = time.time()
        glutMainLoop()

# ----------------------------------------------------------------------------
if __name__ == "__main__": PyBallWorld().Run()
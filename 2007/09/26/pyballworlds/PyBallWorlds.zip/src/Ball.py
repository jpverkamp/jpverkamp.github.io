from OpenGL.GL   import *
from OpenGL.GLUT import *
from OpenGL.GLU  import *

import math
import random

# ----------------------------------------------------------------------------
class Ball:
    """The default Ball off of which all other's are based."""
    
    # name
    name = "Ball"
    
    # the ball's self.position
    pos = (0.0, 0.0, 0.0)
    
    # the ball's current self.velocity
    vel = (0.0, 0.0, 0.0)
    
    # the ball's current acceleration
    acc = (0.0, 0.0, 0.0)
    
    # the ball's radius
    radius = 0.1
    
    # the default Ball is White
    color = (255, 255, 255, 255)
    
    
    
    # ---------------------------------
    def __init__(self):
        """Create a new Ball."""
        
        # generate a random position
        mod = 1.0
        self.pos = (random.random() * mod * 2.0 - mod,
                    random.random() * mod * 2.0 - mod,
                    random.random() * mod * 2.0 - mod)
    
    # ---------------------------------
    def Draw(self):
        # unpack the values
        x, y, z = self.pos
        r, g, b, a = self.color
            
        # draw the ball
        glColor4ub(r, g, b, a)
        glTranslatef(x, y, z)
        glutSolidSphere(self.radius, 25, 25)
        glTranslatef(-x, -y, -z)
        
    # ---------------------------------
    def Act(self):
        """Update the ball."""
                    
    # ---------------------------------
    def CheckWall(self):
        """Check for wall intersections."""
               
    # ---------------------------------
    def Impact(self, other):
        """The ball just hit another ball."""
                    
    # ---------------------------------
    def SetPos(self, i, pos):
        """Set a position value."""
        
        # position as a set
        newpos = [self.pos[0], self.pos[1], self.pos[2]]
        newpos[i] = pos
        
        # store the value
        self.pos = tuple(newpos)
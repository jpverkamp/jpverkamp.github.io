﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;

namespace CaptureTheFlagServer
{
    /// <summary>
    /// Simulates the capture the flag game.
    /// </summary>
    class Game
    {
        // Constant random factors.
        const float AI_RANDOM_MOVE = 0.8f;

        // The game board as a grid.
        Tile[,] Grid;

        // Players involved in this game.
        internal String[] Players;
        internal Dictionary<String, int> Scores = new Dictionary<String, int>();
        internal int CurrentPlayer;

        // Let the server know if the game is over.
        internal String Winner = null;

        // The width and height of the game.
        internal int Width { get { return Grid.GetLength(0); } }
        internal int Height { get { return Grid.GetLength(1); } }

        // The solvability of the game.
        internal bool Solvable = true;

        // A flag set if the game mode includes bases or not.
        internal bool IncludesBases = false;

        // ----- >>> New options for the tournament. -----

        // You are only allowed to capture flags on the other side of the map.
        internal bool SidedFlags = false;

        // Captures occur when you tag a player on your side of the map.
        internal bool CapturesAllowed = false;

        // Set this flag if fog of war is enabled.
        // Also, store the fog of war radius.
        internal bool FogOfWar = false;
        internal int FogOfWarRadius = 4;

        // Timed games.
        internal bool TimedGame = false;
        internal long TimedGameMaxTime = 3 * 60 * 1000;
        internal int TimedGamePlayer = 0;
        internal long[] TimedGameTimes;
        internal Stopwatch TimedGameStopwatch = new Stopwatch();

        // List of flag spawn points.
        internal List<int[]> FlagSpawns = new List<int[]>();

        // ----- <<< New options for the tournament. -----

        // Random number generator.
        Random Random = new Random();

        // Store the list of moves that have taken place on the server.
        internal List<String> MoveRecord = new List<String>();

        // Count the number of flags in the game.
        internal int RemainingFlags
        {
            get
            {
                int count = 0;
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if (Grid[x, y].Type == Type.Flag)
                            count++;
                return count;
            }
        }

        // The board state (get used by RequestState, set used by Scenarios).
        internal String State
        {
            get
            {
                String result = "";
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if (Grid[x, y].Type == Type.Empty) 
                            result += "-";
                        else if (Grid[x, y].Type == Type.Wall) 
                            result += "W";
                        else if (Grid[x, y].Type == Type.Flag) 
                            result += "X";
                        else if (Grid[x, y].Type == Type.Base) 
                            result += (char)('0' + Grid[x, y].Player);
                        else if (Grid[x, y].Type == Type.Player) 
                            result += (char)('a' + Grid[x, y].Player);
                        else if (Grid[x, y].Type == Type.PlayerFlag) 
                            result += (char)('A' + Grid[x, y].Player);
                return result;
            }

            set
            {
                if (Width * Height != value.Length)
                    throw new Exception("Error setting map data: mismatched sizes (probably a problem with the scenario file).");

                for (int x = 0; x < Width; x++)
                {
                    for (int y = 0; y < Height; y++)
                    {
                        Grid[x, y].Player = -1;
                        if (value[x + y * Width] == '-')
                            Grid[x, y].Type = Type.Empty;
                        else if (value[x + y * Width] == 'X')
                            Grid[x, y].Type = Type.Flag;
                        else if (value[x + y * Width] == 'W')
                            Grid[x, y].Type = Type.Wall;
                        else if (value[x + y * Width] >= '0' && value[x + y * Width] <= '9')
                        {
                            Grid[x, y].Type = Type.Base;
                            Grid[x, y].Player = (byte)(value[x + y * Width] - '0');
                            IncludesBases = true;
                        }
                        else if (value[x + y * Width] >= 'a' && value[x + y * Width] <= 'j')
                        {
                            Grid[x, y].Type = Type.Player;
                            Grid[x, y].Player = (byte)(value[x + y * Width] - 'a');
                        }
                        else if (value[x + y * Width] >= 'A' && value[x + y * Width] <= 'J')
                        {
                            Grid[x, y].Type = Type.PlayerFlag;
                            Grid[x, y].Player = (byte)(value[x + y * Width] - 'A');
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Alter the player array to return the first player as A.
        /// (Their spot will take the place of A).
        /// </summary>
        /// <param name="firstPlayer">The player requesting the move..</param>
        /// <param name="constantPlayer">The player wants to be player A.</param>
        /// <returns>The game state (see above).</returns>
        internal String GetState(int firstPlayer, bool constantPlayer)
        {
            // Get the current state.
            String state = State;

            // Do we have to reflect?
            bool reflect = (constantPlayer && firstPlayer != 0);

            // Do not do this if the first player is already correct.
            if (reflect)
            {
                // Replace the bases.
                state = state.Replace('0', '~');
                state = state.Replace((char)('0' + firstPlayer), '0');
                state = state.Replace('~', (char)('0' + firstPlayer));

                // Replace the players without flags.
                state = state.Replace('a', '~');
                state = state.Replace((char)('a' + firstPlayer), 'a');
                state = state.Replace('~', (char)('a' + firstPlayer));

                // Replace the players with flags.
                state = state.Replace('A', '~');
                state = state.Replace((char)('A' + firstPlayer), 'A');
                state = state.Replace('~', (char)('A' + firstPlayer));

                // Reflect the board.
                char[] charState = state.ToCharArray();
                char b;
                for (int x = 0; x < Width; x++)
                {
                    for (int y = 0; y < Height / 2; y++)
                    {
                        b = charState[x + y * Width];
                        charState[x + y * Width] = charState[x + (Width - y - 1) * Width];
                        charState[x + (Width - y - 1) * Width] = b;
                    }
                }
                state = new String(charState);
            }

            // Apply fog of war (if set).
            if (FogOfWar)
            {
                // Work with a character array instead.
                char[] charState = state.ToCharArray();

                // Find the points that can see (0, a, A).
                List<int[]> Bases = new List<int[]>();
                List<int[]> Players = new List<int[]>();
                foreach (int[] p in FlagSpawns)
                    if (p[2] == firstPlayer)
                        if(reflect)
                            Bases.Add(new int[] { p[1], Width - p[0] - 1 });
                        else
                            Bases.Add(new int[] { p[1], p[0] });
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if (state[x + y * Width] == (reflect ? '0' : (char)('0' + firstPlayer)))
                            Bases.Add(new int[] { x, y });
                        else if (state[x + y * Width] == (reflect ? 'a' : (char)('a' + firstPlayer)) || state[x + y * Width] == (reflect ? 'A' : (char)('A' + firstPlayer)))
                            Players.Add(new int[] { x, y });

                // Scan through and set points that aren't visible to '*'
                for (int x = 0; x < Width; x++)
                {
                    for (int y = 0; y < Height; y++)
                    {
                        // Walls are always visible.
                        if (charState[x + y * Width] == 'W')
                            continue;

                        // Loop through the points until we (possibly) find one that can see the point).
                        bool found = false;
                        foreach (int[] b in Bases)
                        {
                            if (Math.Abs(b[0] - x) <= 1 &&
                                Math.Abs(b[1] - y) <= 1)
                            {
                                found = true;
                                break;
                            }
                        }
                        foreach (int[] p in Players)
                        {
                            if (Math.Abs(p[0] - x) + Math.Abs(p[1] - y) <= FogOfWarRadius)
                            {
                                found = true;
                                break;
                            }
                        }


                        // Points not found are hidden.
                        if (!found)
                            charState[x + y * Width] = '*';
                    }
                }

                // Go back to a string.
                state = new String(charState);
            }

            // Return the calculated state.
            return state;
        }

        /// <summary>
        /// Create a new game with the following parameters.
        /// 
        /// All arguments must be non-zero.
        /// </summary>
        /// <param name="width">The width of the new game board.</param>
        /// <param name="height">The height of the new game board.</param>
        /// <param name="teams">The number of teams playing.</param>
        public Game(byte width, byte height, byte teams)
        {
            // Check for invalid values.
            if (width <= 0) throw new Exception("Width must have a positive value.");
            if (height <= 0) throw new Exception("Height must have a positive value.");
            if (teams <= 0) throw new Exception("There must be at least one team.");

            // Initialize game board.
            Grid = new Tile[width, height];
            Players = new String[teams];
            for (int x = 0; x < width; x++)
                for (int y = 0; y < height; y++)
                    Grid[x, y] = new Tile(Type.Empty, 0);
        }

        /// <summary>
        /// Create a new game with the following parameters.
        /// 
        /// All arguments must be non-zero.
        /// </summary>
        /// <param name="width">The width of the new game board.</param>
        /// <param name="height">The height of the new game board.</param>
        /// <param name="teams">The number of teams playing.</param>
        /// <param name="players">The number of players one each team.</param>
        /// <param name="flags">The number of flags.</param>
        /// <param name="seed">The random seed (0 will use system time).</param>
        public Game(byte width, byte height, byte teams, byte players, byte flags, int seed)
            : this(width, height, teams)
        {
            // Create the randomizer that will generate the game board.
            if (seed != 0)
                Random = new Random(seed);
            else
                Random = new Random();

            // There currently has to be exactly two teams and no more than 8 players.
            if (teams != 2) throw new Exception("There must be exactly two teams.");
            if (players > 8) throw new Exception("There cannot be more than 8 players.");

            // Check for invalid values.
            if (players <= 0) throw new Exception("There must be at least one player per team.");
            if (flags <= 0) throw new Exception("There must be at least one flag.");

            // Generate a random board.
            // The board will be symmetric, so generate half and then flip it.

            // Add several random walls.

            // Aim for a 30% fill rate.
            // TODO: Remove hard-coded values.
            int fillRate = 30;
            int currentFill = 0;
            int maxFill = (width / 2) * height;

            // Generate no more than this many walls.
            int count = Math.Min(width, height);

            // Add a few random walls.
            while (currentFill * 100 / maxFill < fillRate && count-- > 0)
            {
                // Choose orientation.
                bool orientation = (Random.Next(2) == 0);

                // Generate walls on rows.
                if (orientation)
                {
                    int row = Random.Next(height);
                    int minCol = Random.Next(width / 2 - 1);
                    int maxCol = Random.Next(minCol, width / 2);

                    for (int col = minCol; col <= maxCol; col++)
                    {
                        if (Grid[col, row].Type == Type.Empty)
                        {
                            Grid[col, row].Type = Type.Wall;
                            currentFill++;
                        }
                    }
                }

                // Generate walls on columns.
                else
                {
                    int col = Random.Next(height);
                    int minRow = Random.Next(height - 1);
                    int maxRow = Random.Next(minRow, height);

                    for (int row = minRow; row <= maxRow; row++)
                    {
                        if (Grid[col, row].Type == Type.Empty)
                        {
                            Grid[col, row].Type = Type.Wall;
                            currentFill++;
                        }
                    }
                }
            }

            // Add the player bases.
            // Player bases will be in the back half of their section.
            // Bail out after so many tried.
            {
                int row = Random.Next(1, Height - 1);
                int col = Random.Next(1, Width / 4);

                for (int x = -1; x <= 1; x++)
                    for (int y = -1; y <= 1; y++)
                        Grid[col + x, row + y].Type = Type.Empty;

                Grid[col, row].Type = Type.Base;
                Grid[col, row].Player = 0;

                // Add the players around the base.
                int playerCount = 0;
                while (playerCount < players)
                {
                    int dcol = Random.Next(-1, 2);
                    int drow = Random.Next(-1, 2);

                    if (Grid[col + dcol, row + drow].Type == Type.Empty)
                    {
                        Grid[col + dcol, row + drow].Type = Type.Player;
                        playerCount++;
                    }
                }
            }

            // Add the initial flags.
            // Flags will also go in the back half of their section.
            count = (Width / 4) * Height;
            for (int i = 0; i < flags; i++, count--)
            {
                int row = Random.Next(1, Height - 1);
                int col = Random.Next(1, Width / 4);

                if (Grid[col, row].Type == Type.Empty)
                {
                    for (int x = -1; x <= 1; x++)
                    {
                        for (int y = -1; y <= 1; y++)
                        {
                            if (Grid[col + x, row + y].Type == Type.Base ||
                                Grid[col + x, row + y].Type == Type.Player ||
                                Grid[col + x, row + y].Type == Type.Flag)
                                continue;

                            Grid[col + x, row + y].Type = Type.Empty;
                        }
                    }

                    Grid[col, row].Type = Type.Flag;
                    Grid[col, row].Player = 0;

                    FlagSpawns.Add(new int[] { col, row, 0 });
                    FlagSpawns.Add(new int[] { Width - col - 1, row, 1 });

                    if (count <= 0)
                        throw new Exception("Unable to generate map: Could not place flags.");
                }
                else
                    i--;
            }

            // Mirror the board.
            for (int x = 0; x < Width / 2; x++)
            {
                for (int y = 0; y < Height; y++)
                {
                    Grid[Width - x - 1, y].Type = Grid[x, y].Type;
                    Grid[Width - x - 1, y].Player = 1;
                }
            }
        }

        /// <summary>
        /// Start the timers.
        /// </summary>
        public void StartTimers()
        {
            TimedGamePlayer = 0;
            TimedGameStopwatch.Reset();
            TimedGameStopwatch.Start();
        }

        /// <summary>
        /// Request the time for a given player.
        /// </summary>
        /// <param name="player">The player to request.</param>
        /// <returns>The time for that player.</returns>
        public long RequestTime(string player)
        {
            for (int i = 0; i < Players.Length; i++)
                if (player.Equals(Players[i]))
                    return TimedGameTimes[i];
            return -1;
        }

        /// <summary>
        /// Generate a tournament map.
        /// </summary>
        /// <returns>The new map.</returns>
        /// <param name="seed">The random seed to use for game generation. (0 means random random seed.)</param>
        public static Game Tournament(int seed)
        {
            Game g = new Game(30, 30, 2, 3, 5, seed);
            g.FogOfWar = true;
            g.SidedFlags = true;
            g.CapturesAllowed = true;
            g.TimedGame = true;
            g.IncludesBases = true;
            g.TimedGameMaxTime = 3 * 60 * 1000;
            g.TimedGameTimes = new long[]
            {
                0,
                0
            };
            return g;
        }

        /// <summary>
        /// Add a player to a game.
        /// </summary>
        /// <param name="player">The player to add to a game.</param>
        public void AddPlayer(String player)
        {
            for (int i = 0; i < Players.Length; i++)
            {
                if (Players[i] == null)
                {
                    Players[i] = player;
                    Scores[player] = 0;
                    return;
                }
            }

            throw new Exception("Cannot add another player, the game is already full.");
        }

        /// <summary>
        /// Add a new player with the given index.
        /// </summary>
        /// <param name="index">The player index to use.</param>
        /// <param name="player">The player to add to a game.</param>
        public void AddPlayer(int index, String player)
        {
            if (Players[index] == null)
            {
                Players[index] = player;
                Scores[player] = 0;
            }
            else
                throw new Exception("Cannot add a player at index '" + index + "' (already in use).");
        }

        /// <summary>
        /// Check if a given player ID is in a game.
        /// </summary>
        /// <param name="player">The player ID to check.</param>
        /// <returns>True if the player is in this game, false otherwise.</returns>
        public bool HasPlayer(String player)
        {
            foreach (String p in Players)
                if (player.Equals(p))
                    return true;
            return false;
        }

        /// <summary>
        /// The given player would like to make a move on the game board.
        /// Will throw an exception detailing the problem if the move is invalid.
        /// 
        /// A move string is a list of moves formatted like this:
        /// - {Source row}x{Source column}-{Destination row}x{Destination column};...
        /// </summary>
        /// <param name="player">The player that will be making the move.</param>
        /// <param name="moveString">The formatted move string.</param>
        /// <param name="mirror">Mirror the player.</param>
        public bool Move(String player, String moveString, bool mirror)
        {
            return Move(player, moveString, false, mirror);
        }

        /// <summary>
        /// The given player would like to make a move on the game board.
        /// Will throw an exception detailing the problem if the move is invalid.
        /// 
        /// A move string is a list of moves formatted like this:
        /// - {Source row}x{Source column}-{Destination row}x{Destination column};...
        /// </summary>
        /// <param name="player">The player that will be making the move.</param>
        /// <param name="moveString">The formatted move string.</param>
        /// <param name="overrideExceptions">Just return rather than throwning exceptions.</param>
        /// <param name="mirror">Mirror the board.</param>
        public bool Move(String player, String moveString, bool overrideExceptions, bool mirror)
        {
            // Buffer the grid incase it needs to be reset.
            Tile[,] GridBuffer = (Tile[,])Grid.Clone();

            // Only player one actually needs to mirror.
            try
            {
                if (player.Equals(Players[0]))
                    mirror = false;
            }
            catch
            {
            }

            // Potentially override exceptions.
            try
            {
                // Count the time that the player has taken.
                TimedGameStopwatch.Stop();
                TimedGameTimes[CurrentPlayer] += TimedGameStopwatch.ElapsedMilliseconds;

                // Bail out if too much time has passed (in a timed game).
                if (TimedGame && TimedGameTimes[CurrentPlayer] > TimedGameMaxTime)
                    throw new Exception("You have already used your entire allowed time (" + TimedGameTimes[CurrentPlayer] + " of " + TimedGameMaxTime + " ms.)");

                // Make sure the game is actually full.
                for (int i = 0; i < Players.Length; i++)
                    if (Players[i] == null)
                        throw new Exception("Cannot process move.  Not all players have joined the game.");

                // Check first if the given player actually is in the game, then if they are the current player.
                if (!Players.Contains(player)) throw new Exception("You are not playing in this game.");
                if (!Players[CurrentPlayer].Equals(player)) throw new Exception("It is currently " + Players[CurrentPlayer] + "'s turn.");

                // If the game is over, no more moves are possible.
                if (Winner != null) throw new Exception("The game is over.  '" + Winner + "' won.");

                // Check the format of the move.
                if (!(moveString.Equals("") || Regex.IsMatch(moveString, "([0-9]+x[0-9]+;)*[0-9]+x[0-9]+", RegexOptions.Compiled)))
                    throw new Exception("'" + moveString + "' is not a validly formatted move.");

                // Parse moves into arrays.
                List<int[]> parsedMoves = new List<int[]>();
                try
                {
                    // Parse the moves.
                    // Reflect moves if need be.
                    foreach (String move in moveString.Split(new String[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        String[] points = move.Split(new String[] { "-", "x" }, StringSplitOptions.RemoveEmptyEntries);
                        parsedMoves.Add(new int[] {
                            (mirror ? (Width - int.Parse(points[0]) - 1) : int.Parse(points[0])),
                            int.Parse(points[1]),
                            (mirror ? (Width - int.Parse(points[2]) - 1) : int.Parse(points[2])),
                            int.Parse(points[3])
                        });
                    }
                    
                }
                catch
                {
                    throw new Exception("'" + moveString + "' is not a validly formatted move.");
                }

                // Count the number of current players (to verify that players do not collide).
                int currentPlayerCount = 0;
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if ((Grid[x, y].Type == Type.Player || Grid[x, y].Type == Type.PlayerFlag) && Grid[x, y].Player == CurrentPlayer)
                            currentPlayerCount++;

                // Verify moves.
                // For a move to be valid, there must be a player at the origin and the destination must be either a flag or empty.
                // Two or more players cannot be in the same square at the end of a move.
                foreach (int[] move in parsedMoves)
                {
                    // Watch for any parsing problems that I didn't otherwise check for.
                    try
                    {
                        // Check that the player is only moving one square in any direction.
                        if (Math.Abs(move[0] - move[2]) + Math.Abs(move[1] - move[3]) > 1)
                            throw new Exception("Cannot move from (" + move[0] + " x " + move[1] + ") to (" + move[2] + " x " + move[3] + ").  Can only move one square at a time.");

                        // Verify that a player of the correct type is in the given location.
                        if (!(Grid[move[0], move[1]].Type == Type.Player || Grid[move[0], move[1]].Type == Type.PlayerFlag))
                            throw new Exception("(" + move[0] + " x " + move[1] + ") does not contain a player that belongs to you.");
                        if (Grid[move[0], move[1]].Player != CurrentPlayer)
                            throw new Exception("(" + move[0] + " x " + move[1] + ") does not contain a player that belongs to you.");

                        // A player already holding a flag cannot move onto another.
                        if (Grid[move[0], move[1]].Type == Type.PlayerFlag)
                            if (Grid[move[2], move[3]].Type == Type.Flag)
                                throw new Exception("Cannot move player at (" + move[0] + " x " + move[1] + ") already holding a flag.");

                        // If the game is sided, make sure the flag is of the proper type.
                        if (SidedFlags)
                        {
                            if (Grid[move[2], move[3]].Type == Type.Flag &&
                                ((CurrentPlayer == 0 && move[2] < Width / 2) ||
                                 (CurrentPlayer == 1 && move[2] >= Width / 2)))
                                throw new Exception("Cannot capture your own flags.");
                        }

                        // Verify that the target location is not a wall or base.
                        if (Grid[move[2], move[3]].Type == Type.Wall)
                            throw new Exception("(" + move[2] + " x " + move[3] + ") contains a wall.");
                        if (Grid[move[2], move[3]].Type == Type.Base)
                            throw new Exception("(" + move[2] + " x " + move[3] + ") contains a base.");
                        
                        // With sided games, we have to deal with spawn point.
                        if (SidedFlags)
                        {
                            // Players cannot move onto their own spawn points.
                            foreach (int[] flag in FlagSpawns)
                                if (CurrentPlayer == flag[2] && flag[0] == move[2] && flag[1] == move[3])
                                    throw new Exception("Cannot move onto your own flag spawn point.");

                            // Players carrying flags cannot move onto spawn points at all.
                            foreach (int[] flag in FlagSpawns)
                                if (Grid[move[0], move[1]].Type == Type.PlayerFlag && flag[0] == move[2] && flag[1] == move[3])
                                    throw new Exception("When carrying a flag you cannot move onto spawn points.");
                        }


                        // If capturing is allowed, we can run into opposing players.
                        if (CapturesAllowed &&
                            ((CurrentPlayer == 0 && move[2] >= Width / 2) ||
                             (CurrentPlayer == 1 && move[2] < Width / 2)) && 
                            (Grid[move[2], move[3]].Type == Type.Player || Grid[move[2], move[3]].Type == Type.PlayerFlag) && Grid[move[2], move[3]].Player != CurrentPlayer)
                            throw new Exception("(" + move[2] + " x " + move[3] + ") contains another player and you cannot capture on their side.");
                        else if (!CapturesAllowed && (Grid[move[2], move[3]].Type == Type.Player || Grid[move[2], move[3]].Type == Type.PlayerFlag))
                            throw new Exception("(" + move[2] + " x " + move[3] + ") contains another player and captures are not enabled.");

                        // Make sure two players are not moving to the same location.
                        foreach (int[] other in parsedMoves)
                        {
                            // Don't check against yourself.
                            if (move == other) continue;

                            // If they have the same destination, we have a problem
                            if (move[2] == other[2] && move[3] == other[3]) throw new Exception("Two players cannot move to the same tile: (" + move[2] + " x " + move[3] + ").");
                        }
                    }
                    // An index was tried out of the map bounds.
                    catch (IndexOutOfRangeException)
                    {
                        throw new Exception("(" + move[0] + " x " + move[1] + ") to (" + move[2] + " x " + move[3] + ") is not a valid move.  Cannot move past the edges.");
                    }
                }

                // The potential change to the score.
                int scoreChange = 0;

                // If it made it this far, the move is valid.
                // Go ahead and perform the moves.

                // Store the original types.
                Type[] originalTypes = new Type[parsedMoves.Count];

                // First, remove the original players.
                int j = 0;
                foreach (int[] move in parsedMoves)
                {
                    // Remove from previous tile.
                    originalTypes[j] = Grid[move[0], move[1]].Type;
                    Grid[move[0], move[1]].Type = Type.Empty;
                    Grid[move[0], move[1]].Player = -1;
                    j++;
                }

                // Now, add them to their new locations
                j = 0;
                foreach (int[] move in parsedMoves)
                {
                    // Depends on game type.
                    // If the board includes bases, players have to carry flags back to bases.
                    if (IncludesBases)
                    {
                        // Move to empty squares.
                        if (Grid[move[2], move[3]].Type == Type.Empty)
                        {
                            Grid[move[2], move[3]].Type = originalTypes[j];
                            Grid[move[2], move[3]].Player = CurrentPlayer;
                        }

                        // Capture players.
                        else if (CapturesAllowed && // Have to even have captures.
                              Grid[move[0], move[1]].Player != Grid[move[2], move[3]].Player &&  // Have to be on opposite teams.
                             (Grid[move[2], move[3]].Type == Type.Player || Grid[move[2], move[3]].Type == Type.PlayerFlag) && // Have to have someone to capture.
                            ((CurrentPlayer == 0 && move[2] < Width / 2) || // Has to be on the correct side of the board.
                             (CurrentPlayer == 1 && move[2] >= Width / 2))) // ^ Ditto ^
                        {
                            // If the old player had a flag, it respawns at it's spawn point.
                            if (Grid[move[2], move[3]].Type == Type.PlayerFlag)
                            {
                                // Find an empty spawn point.
                                bool validSpawn = false;
                                int x = -1;
                                int y = -1;

                                // Error out if the original location doesn't make sense.
                                foreach (int[] p in FlagSpawns)
                                {
                                    if (p[2] != Grid[move[2], move[3]].Player && Grid[p[0], p[1]].Type == Type.Empty)
                                    {
                                        x = p[0];
                                        y = p[1];
                                        validSpawn = true;
                                        break;
                                    }
                                }
                                if (!validSpawn)
                                {
                                    Console.WriteLine();
                                    Console.WriteLine("Error report:");
                                    Console.WriteLine(">>> Trying to respawn at: (" + x + ", " + y + ")");
                                    foreach (int[] p in FlagSpawns)
                                        Console.WriteLine(">>> List (" + p[2] + "): (" + p[0] + ", " + p[1] + ")");
                                    Console.WriteLine();

                                    throw new Exception("Error respawning on capture because original location was invalid.");
                                }

                                // If there is a player there, the player picks it up.
                                if (Grid[x, y].Type == Type.Player && Grid[move[2], move[3]].Player == Grid[x, y].Player)
                                {
                                    Grid[x, y].Type = Type.PlayerFlag;
                                }

                                // If it's empty, drop the flag.
                                else if (Grid[x, y].Type == Type.Empty)
                                    Grid[x, y].Type = Type.Flag;

                                // If it's not a player or empty, we have a problem.
                                else
                                    throw new Exception("Error respawning on capture because spawn point was occupied.");
                            }

                            // Now the player respawns.
                            {
                                // First, find a base.
                                int baseX = -1;
                                int baseY = -1;
                                for (int x = 0; x < Width; x++)
                                    for (int y = 0; y < Height; y++)
                                        if (Grid[x, y].Type == Type.Base && Grid[x, y].Player == Grid[move[2], move[3]].Player)
                                        {
                                            baseX = x;
                                            baseY = y;
                                        }
                                if (baseX < 0 && baseY < 0)
                                    throw new Exception("Error returning captured player to base.");

                                // Now add the player adjacent to it.
                                bool done = false;
                                int modX = (Random.Next(2) == 0 ? -1 : 1);
                                int modY = (Random.Next(2) == 0 ? -1 : 1);
                                for (int delta = 1; ; delta++)
                                {
                                    for (int xd = modX * -delta; xd != modX * delta; xd += modX)
                                    {
                                        for (int yd = modY * -delta; yd != modY * delta; yd += modY)
                                        {
                                            if (Grid[baseX + xd, baseY + yd].Type == Type.Empty)
                                            {
                                                try
                                                {
                                                    Grid[baseX + xd, baseY + yd].Type = Type.Player;
                                                    Grid[baseX + xd, baseY + yd].Player = Grid[move[2], move[3]].Player;
                                                    done = true;
                                                    break;
                                                }
                                                catch
                                                { 
                                                }
                                            }
                                        }
                                        if (done)
                                            break;
                                    }
                                    if (done)
                                        break;
                                }

                            }

                            // Add the new player..
                            Grid[move[2], move[3]].Type = originalTypes[j];
                            Grid[move[2], move[3]].Player = CurrentPlayer;
                        }

                        // Pick up flags.
                        else if (originalTypes[j] == Type.Player && Grid[move[2], move[3]].Type == Type.Flag)
                        {
                            Grid[move[2], move[3]].Type = Type.PlayerFlag;
                            Grid[move[2], move[3]].Player = CurrentPlayer;
                        }

                        // Check for bases to drop off flags.
                        if (Grid[move[2], move[3]].Type == Type.PlayerFlag)
                        {
                            for (int dx = -1; dx <= 1; dx++)
                            {
                                for (int dy = -1; dy <= 1; dy++)
                                {
                                    if (move[2] + dx >= 0 && move[2] + dx < Width && move[3] + dy >= 0 && move[3] + dy < Height)
                                    {
                                        if (Grid[move[2] + dx, move[3] + dy].Type == Type.Base && Grid[move[2] + dx, move[3] + dy].Player == CurrentPlayer)
                                        {
                                            // Score the new flag.
                                            Grid[move[2], move[3]].Type = Type.Player;
                                            Grid[move[2], move[3]].Player = CurrentPlayer;
                                            scoreChange++;

                                            // Respawn flags if necessary.
                                            if (TimedGame)
                                            {
                                                // Get the original point.
                                                bool validSpawn = false;
                                                int x = -1;
                                                int y = -1;

                                                // Error out if the original location doesn't make sense.
                                                foreach (int[] p in FlagSpawns)
                                                {
                                                    if (p[2] != Grid[move[2], move[3]].Player && Grid[p[0], p[1]].Type == Type.Empty)
                                                    {
                                                        x = p[0];
                                                        y = p[1];
                                                        validSpawn = true;
                                                        break;
                                                    }
                                                }
                                                if (!validSpawn)
                                                {
                                                    Console.WriteLine();
                                                    Console.WriteLine("Error report:");
                                                    Console.WriteLine(">>> Trying to respawn at: (" + x + ", " + y + ")");
                                                    foreach (int[] p in FlagSpawns)
                                                        Console.WriteLine(">>> List (" + p[2] + "): (" + p[0] + ", " + p[1] + ")");
                                                    Console.WriteLine();

                                                    throw new Exception("Error respawning on score because original location was invalid.");
                                                }

                                                // If there is a player there, the player picks it up.
                                                if (Grid[x, y].Type == Type.Player && Grid[move[2], move[3]].Player == Grid[x, y].Player)
                                                    Grid[x, y].Type = Type.PlayerFlag;

                                                // If it's empty, drop the flag.
                                                else if (Grid[x, y].Type == Type.Empty)
                                                    Grid[x, y].Type = Type.Flag;

                                                // If it's not a player or empty, we have a problem.
                                                else
                                                    throw new Exception("Error respawning on score because spawn point was occupied.");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // If players do not have bases, they just have to get to the flags.
                    else
                    {
                        // Move to empty squares.
                        if (Grid[move[2], move[3]].Type == Type.Empty)
                        {
                            Grid[move[2], move[3]].Type = originalTypes[j];
                            Grid[move[2], move[3]].Player = CurrentPlayer;
                        }

                        // Pick up flags and score.
                        else if (Grid[move[2], move[3]].Type == Type.Flag)
                        {
                            Grid[move[2], move[3]].Type = originalTypes[j];
                            Grid[move[2], move[3]].Player = CurrentPlayer;
                            scoreChange++;
                        }
                    }
                    j++;
                }

                // Verify that the players are not colliding.
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if ((Grid[x, y].Type == Type.Player || Grid[x, y].Type == Type.PlayerFlag) && Grid[x, y].Player == CurrentPlayer)
                            currentPlayerCount--;

                // Revert the buffer if we lost any players.
                if (currentPlayerCount != 0)
                    throw new Exception("A player was lost.  Most likely two players moved to the same location.");

                // Made it past the final check, add the score.
                Scores[Players[CurrentPlayer]] += scoreChange;

                // Made it past the final check.  Add the move to the list.
                MoveRecord.Add(CurrentPlayer + ":" + moveString);

                // Check for a winner.
                bool flags = false;
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if (Grid[x, y].Type == Type.Flag || Grid[x, y].Type == Type.PlayerFlag)
                            flags = true;

                // Special case for timed games.
                if (TimedGame)
                {
                    flags = false;
                    for (int i = 0; i < TimedGameTimes.Length; i++)
                        if (TimedGameTimes[i] < TimedGameMaxTime)
                            flags = true;
                }

                // No more flags?  We have a winner!
                if (!flags)
                {
                    Winner = Players[0];
                    int winningScore = 0;
                    foreach (String key in Scores.Keys)
                    {
                        if (Scores[key] > winningScore)
                        {
                            winningScore = Scores[key];
                            Winner = key;
                        }
                    }
                }

                // Advance the current player counter.
                else
                {
                    // Advance normally.
                    CurrentPlayer = (CurrentPlayer + 1) % Players.Length;

                    // Skip players that have already used their entire time.
                    while (TimedGameTimes[CurrentPlayer] > TimedGameMaxTime)
                        CurrentPlayer = (CurrentPlayer + 1) % Players.Length;
                }

                // Start the timer for the next player.
                TimedGameStopwatch.Reset();
                TimedGameStopwatch.Start();
            }

            // If any exceptions are caught, throw them unless we are overriding them.
            catch (Exception e)
            {
                // Reset the grid buffer.
                Grid = (Tile[,])GridBuffer.Clone();
                
                // Override exceptions if requested.
                if (overrideExceptions)
                    return false;
                else
                    throw e;
            }

            // If it made it past all of the checks, return true.
            return true;
        }

        /// <summary>
        /// Writes the current game record to disk.
        /// </summary>
        public void WriteGame()
        {
            // Write the score to the console.
            Console.WriteLine();
            Console.WriteLine("Scores:");
            foreach (String key in Scores.Keys)
                Console.WriteLine(key + ": " + Scores[key]);
            Console.WriteLine();

            // Generate the filename.
            String filename = "" + DateTime.Now.Ticks;
            foreach (String player in Players)
                filename += "-" + player;
            filename += ".txt";

            // Write the move record to the filename.
            try
            {
                StreamWriter writer = new StreamWriter(filename);
                
                writer.WriteLine("Moves:\n");
                foreach (String move in MoveRecord)
                    writer.WriteLine(move);

                writer.WriteLine("\nScores:\n");
                foreach (String player in Scores.Keys)
                    writer.WriteLine(player + ":" + Scores[player]);

                writer.Close();
            }
            catch
            {
                Console.WriteLine("Error: Could not write game log to file.");
            }
        }

        /// <summary>
        /// Process the next player as an AI player.
        /// </summary>
        public String AIPlayer()
        {
            // Make sure that the current player is actually an AI player.
            if (!Players[CurrentPlayer].StartsWith("AI", StringComparison.OrdinalIgnoreCase))
                throw new Exception("Cannot process an AI player for a non-AI player, no matter how much you might want to.");

            // Go about the whole AI thing (Isn't this what you are in the class for?  Why am I doing it?).

            // Start with no moves.
            String moves = "";

            // Find each of my players, flag carrying players, flags, and bases.
            List<int[]> players = new List<int[]>();
            List<int[]> playerFlags = new List<int[]>();
            List<int[]> bases = new List<int[]>();
            List<int[]> flags = new List<int[]>();
            List<int[]> occupied = new List<int[]>();
            for (int x = 0; x < Width; x++)
                for (int y = 0; y < Height; y++)
                    if (Grid[x, y].Type == Type.Player && Grid[x, y].Player == CurrentPlayer)
                        players.Add(new int[] { x, y });
                    else if (Grid[x, y].Type == Type.PlayerFlag && Grid[x, y].Player == CurrentPlayer)
                        playerFlags.Add(new int[] { x, y });
                    else if (Grid[x, y].Type == Type.Base && Grid[x, y].Player == CurrentPlayer)
                        bases.Add(new int[] { x, y });
                    else if (Grid[x, y].Type == Type.Flag)
                        flags.Add(new int[] { x, y });

            // Try to move each player towards the nearest flag (Manhattan distance).
            if (players.Count > 0 && flags.Count > 0)
            {
                foreach (int[] player in players)
                {
                    int[] moveTo = MoveTowards(player, flags);
                    if (moveTo != null && !occupied.Contains(moveTo))
                    {
                        if (!moves.Equals(""))
                            moves += ";";
                        moves += player[0] + "x" + player[1] + "-" + moveTo[0] + "x" + moveTo[1];
                        occupied.Add(moveTo);
                    }
                    else
                    {
                        occupied.Add(player);
                    }
                }
            }

            // Try to move each player already carrying a flag to the nearest base (Manhattan distance again).
            if (playerFlags.Count > 0 && bases.Count > 0)
            {
                foreach (int[] player in playerFlags)
                {
                    int[] moveTo = MoveTowards(player, bases);
                    if (moveTo != null && !occupied.Contains(moveTo) && Grid[moveTo[0], moveTo[1]].Type == Type.Empty)
                    {
                        if (!moves.Equals(""))
                            moves += ";";
                        moves += player[0] + "x" + player[1] + "-" + moveTo[0] + "x" + moveTo[1];
                        occupied.Add(moveTo);
                    }
                    else
                    {
                        occupied.Add(player);
                    }
                }
            }

            // Try to make the move.
            // If it doesn't work, just stay still.
            if (Move(Players[CurrentPlayer], moves, true))
                return moves;
            else
                return "";
        }

        /// <summary>
        /// Move the given player to the given point.
        /// </summary>
        /// <param name="moving">The player to move.</param>
        /// <param name="targets">The possible points to move towards.</param>
        /// <returns>The direction to move.</returns>
        private int[] MoveTowards(int[] moving, List<int[]> targets)
        {
            // Simple error checking.
            if (moving == null || targets == null || targets.Count == 0)
                return null;

            // Initialize to the first point.
            int[] moveTo = targets[0];
            int distance = Math.Abs(targets[0][0] - moving[0]) + Math.Abs(targets[0][1] - moving[1]);

            // Two possibilities: Move randomly or seek a flag.
            if (Random.NextDouble() > AI_RANDOM_MOVE)
            {
                // Generate the move.
                if (Random.NextDouble() > 0.5)
                    if (Random.NextDouble() > 0.5)
                        moveTo = new int[] { moving[0] + 1, moving[1] };
                    else
                        moveTo = new int[] { moving[0] - 1, moving[1] };
                else
                    if (Random.NextDouble() > 0.5)
                        moveTo = new int[] { moving[0], moving[1] + 1 };
                    else
                        moveTo = new int[] { moving[0], moving[1] - 1 };

                // Push it back into the bounds.
                if (moveTo[0] < 0 || moveTo[0] >= Width || moveTo[1] < 0 || moveTo[1] >= Height)
                {
                    moveTo[0] = moving[0];
                    moveTo[1] = moving[1];
                }

                // Return the result.
                return moveTo;
            }
            

            // Loop through finding the nearest one.
            foreach (int[] target in targets)
            {
                if (Math.Abs(target[0] - moving[0]) + Math.Abs(target[1] - moving[1]) < distance)
                {
                    moveTo = target;
                    distance = (Math.Abs(target[0] - moving[0]) + Math.Abs(target[1] - moving[1]));
                }
            }

            // Calculate the actual move.
            if (Math.Abs(moveTo[0] - moving[0]) > Math.Abs(moveTo[1] - moving[1]))
            {
                moveTo[0] = moving[0] + Math.Sign(moveTo[0] - moving[0]);
                moveTo[1] = moving[1];
            }
            else
            {
                moveTo[0] = moving[0];
                moveTo[1] = moving[1] + Math.Sign(moveTo[1] - moving[1]);
            }

            // Push it back into the bounds.
            if (moveTo[0] < 0) moveTo[0] = 0;
            if (moveTo[0] >= Width) moveTo[0] = Width - 1;
            if (moveTo[1] < 0) moveTo[1] = 0;
            if (moveTo[1] >= Height) moveTo[1] = Height - 1;

            // Return the result.
            return moveTo;
        }

        /// <summary>
        /// Check if a game is full.
        /// </summary>
        /// <returns>True if the game is full.</returns>
        public bool IsFull()
        {
            for (int i = 0; i < Players.Length; i++)
                if (Players[i] == null)
                    return false;
            return true;
        }
    }

    /// <summary>
    /// Different possible tile types.
    /// </summary>
    enum Type
    {
        Empty,
        Wall,
        Base, 
        Player,
        Flag,
        PlayerFlag,
    };

    /// <summary>
    /// Represents a sintle tile of the game board.
    /// </summary>
    class Tile
    {
        internal Type Type;
        internal int Player;
        public Tile(Type type, int player)
        {
            Type = type;
            Player = player;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Drawing;
using Sandbox.Screens;
using Sandbox.Simulation;

using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;
using SdlDotNet.Core;

namespace Sandbox
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Sandbox
    {
    	// The screen manager to use for this Sandbox.
    	ScreenManager ScreenManager;
    	
    	// The surface that we should draw everything to.
    	Surface Surface;
    	
    	// Global matter definitions.
    	public static Matter Matter = new Matter("Data/BurningBush.xml");
    	
        /// <summary>
        /// Entry point for the programm.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
        	// TODO: Process command line parameters.
        	
        	// Create a new Sandbox.
        	new Sandbox(args);
        }
        
        /// <summary>
        /// Create a new Sandbox simulation.
        /// </summary>
        /// <param name="args">Command line parameters.</param>
        public Sandbox(string[] args)
        {
        	// Program constants.
        	int fps = 30;
        	
        	// Simulation constants.
        	int simulation_width = 512;
        	int simulation_height = 512;
        	int simulation_scale = 2;
        	int simulation_subdivisions = 5;
        	
        	// Other display constants.
        	int border_width = 10;
        	int matter_selector_size = 50;
        	int matter_selector_columns = 2;
        	
        	// Initialize the display.
			Video.WindowIcon(); // TODO: Add an icon (an S made of sand?)
			Video.WindowCaption = "Sandbox";
			Surface = Video.SetVideoMode(
				border_width * 3 + simulation_width + matter_selector_size,
				border_width * 2 + simulation_height
			);

			// Initialize the screen manager.
			ScreenManager = new ScreenManager();
			
			// Add the simulation.
			ScreenManager["World Display"] = new WorldDisplay(
            	new Rectangle(border_width, border_width, simulation_width, simulation_height),
            	new Size(simulation_width / simulation_scale, simulation_height / simulation_scale),
            	simulation_subdivisions
            );
			
			// Add the (shared) matter selector.
			ScreenManager["Matter Selector"] = new MatterSelector(
				new Rectangle(border_width * 2 + simulation_width, border_width, matter_selector_size, simulation_height),
				matter_selector_columns,
				border_width
			);
			
			// Attach the displays to the matter selector.
			((MatterSelector) ScreenManager["Matter Selector"]).AddMatterSelector(((WorldDisplay) ScreenManager["World Display"]).SetPlaceableMatter);
			            
			// Bind to the event listeners.
			Events.KeyboardDown += new EventHandler<KeyboardEventArgs>(Events_KeyboardDown);
			Events.Quit += new EventHandler<QuitEventArgs>(Quit);
   			Events.Tick += new EventHandler<TickEventArgs>(Tick);
   			Events.Fps = fps;
   			Events.Run();
        }
    
        /// <summary>
        /// Input processing.
        /// </summary>
        /// <param name="sender">Where the event came from.</param>
        /// <param name="e">Event details.</param>
		private void Events_KeyboardDown(object sender, KeyboardEventArgs e)
    	{
        	// Display the help screen.
        	if (e.Key == Key.Escape)
        		Events.QuitApplication();
    	}

		/// <summary>
		/// Quit the program.
		/// </summary>
		/// <param name="sender">Where the event came from.</param>
		/// <param name="e">Quit event details.</param>
        private void Quit(object sender, QuitEventArgs e)
	    {
    	    Events.QuitApplication();
    	}

        /// <summary>
        /// Main loop, should be called based on the frameaate.
        /// </summary>
        /// <param name="sender">Where the event came from.</param>
        /// <param name="e">Tick event details.</param>
    	private void Tick(object sender, TickEventArgs e)
    	{
    		#region DEBUG: Display fps.
        	// Update the window title.
			Video.WindowCaption = "Sandbox - " + e.Fps + " FPS";
 			#endregion

    		// Update everything (if not paused).
    		ScreenManager.Update();
    		
        	// Then draw.
        	ScreenManager.Draw(Surface);
        	Surface.Update();
		}
    }
}

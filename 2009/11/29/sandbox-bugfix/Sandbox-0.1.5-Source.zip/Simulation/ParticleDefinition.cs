﻿using System;
using System.Drawing;

namespace Sandbox.Simulation
{
	/// <summary>
	/// Holds a definition of a particular type of matter.
	/// </summary>
	public struct ParticleDefinition
	{
		// The matter's properties.
		public readonly string ID;
		public readonly MatterType Type;
		public readonly Color Color;
		public readonly bool Placeable;
		public readonly bool Colorful;
		
		/// <summary>
		/// Create a new matter definition.
		/// </summary>
		/// <param name="id">The matter ID.</param>
		/// <param name="type">The type of matter.</param>
		/// <param name="color">The color to use for the matter.</param>
		/// <param name="placeable">If the user is allowed to place the given matter.</param>
		/// <param name="placeable">If the matter should have variable color.</param>
		public ParticleDefinition(string id, MatterType type, Color color, bool placeable, bool colorful)
		{
			ID = id;
			Type = type;
			Color = color;
			Placeable = placeable;
			Colorful = colorful;
		}
	}
	
	/// <summary>
	/// Possible types of matter.
	/// </summary>
	public enum MatterType {
		Solid,	// Stationary
		Liquid,	// Falls
		Gas,	// Rises
	};
}

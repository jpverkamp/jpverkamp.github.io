﻿using System;
using System.Drawing;
using System.Collections.Generic;

using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;
using SdlDotNet.Core;

namespace Sandbox.Screens
{
	/// <summary>
	/// Description of MatterSelector.
	/// </summary>
	public class MatterSelector : Screen
	{
		// Display parameters.
		Rectangle Region;
		int Columns;
		int Spacing;
		int BoxSize;
		
		// Keep a list of placeable matter.
		short[] Placeable;
		
		// The currently selected item.
		int _CurrentItem = 0;
		int CurrentItem {
			get {
				return _CurrentItem;
			}
			set {
				if (value != _CurrentItem)
					foreach(Action<short> f in MatterSelectorListeners)
							f(Placeable[value]);
				_CurrentItem = value;
			}
		}
		
		// Methods that need to be called when the selected matter type changes.
		List<Action<short>> MatterSelectorListeners = new List<Action<short>>();
		
		/// <summary>
		/// Create a new matter selector.
		/// </summary>
		/// <param name="region">The region of the matter selector.</param>
		/// <param name="columns">The number of columns to display.</param>
		/// <param name="spacing">The spacing between elements.</param>
		public MatterSelector(Rectangle region, int columns, int spacing)
			: base(true, true)
		{
			// Store the display parameters.
			Region = region;
			Columns = columns;
			Spacing = spacing;
			
			// Calculate the size of each box.
			BoxSize = (Region.Width - (Columns - 1) * Spacing) / Columns;
			
			// Use a list for the preprocessing.
			List<short> placeable = new List<short>();
			
			// Find the correct elements.
			for (short i = 0; i < Sandbox.Matter.Length; i++)
				if (Sandbox.Matter.IsPlaceable(i))
					placeable.Add(i);
			Placeable = placeable.ToArray();
			
			// Listen for mouse events.
			Events.MouseButtonDown += new EventHandler<MouseButtonEventArgs>(Events_MouseButtonDown);
			Events.KeyboardDown += new EventHandler<KeyboardEventArgs>(Events_KeyboardDown);
		}
		
		/// <summary>
        /// Input processing.
        /// </summary>
        /// <param name="sender">Where the event came from.</param>
        /// <param name="e">Event details.</param>
		internal void Events_MouseButtonDown(object sender, MouseButtonEventArgs e)
		{
			// Loop through the colors.
			for (int i = 0; i < Placeable.Length; i++)
			{
				// Calculate the bounding box.
				Rectangle box = new Rectangle(
					Region.X + (i % Columns) * (BoxSize + Spacing),
					Region.Y + (i / Columns) * (BoxSize + Spacing),
					BoxSize,
					BoxSize
				);
				if (box.Contains(e.Position))
				{
					if (CurrentItem != i)
						CurrentItem = i;
				}
			}
		}
		
		/// <summary>
        /// Input processing.
        /// </summary>
        /// <param name="sender">Where the event came from.</param>
        /// <param name="e">Event details.</param>
		internal void Events_KeyboardDown(object sender, KeyboardEventArgs e)
		{
			// Listen for the number keys.
			if (char.IsNumber(e.KeyboardCharacter[0]))
			{
				int n = int.Parse(e.KeyboardCharacter);
				
				if (n == 0 && Placeable.Length >= 10)
					CurrentItem = 10;
				
				else if (n > 0 && n < 10 && n - 1 < Placeable.Length)
					CurrentItem = n - 1;
			}
		}
		
		/// <summary>
		/// Add an action to do whenever the selected item changes.
		/// </summary>
		/// <param name="action">The action to do.</param>
		public void AddMatterSelector(Action<short> action)
		{
			MatterSelectorListeners.Add(action);
			action(Placeable[CurrentItem]);
		}
		
		/// <summary>
		/// Update the matter selector.
		/// </summary>
		internal override void Update()
		{

		}
		
        /// <summary>
		/// Draw the matter selector.
		/// </summary>
		internal override void Draw(Surface surface)
		{
			// Loop through the colors.
			for (int i = 0; i < Placeable.Length; i++)
			{
				// Calculate the bounding box.
				Box box = new Box(
					(short) (Region.X + (i % Columns) * (BoxSize + Spacing)),
					(short) (Region.Y + (i / Columns) * (BoxSize + Spacing)),
					(short) (Region.X + (i % Columns) * (BoxSize + Spacing) + BoxSize),
					(short) (Region.Y + (i / Columns) * (BoxSize + Spacing) + BoxSize)
				);
				
				// Draw the box and it's border.
				surface.Draw(box, Sandbox.Matter.GetColor(Placeable[i]), false, true);
				surface.Draw(box, Color.White, false, false);
				
				// Draw cross-hairs on the currently selected item.
				if (CurrentItem == i)
				{
					surface.Draw(new Line(box.XPosition1, box.YPosition1, box.XPosition2, box.YPosition2), Color.White);
					surface.Draw(new Line(box.XPosition2, box.YPosition1, box.XPosition1, box.YPosition2), Color.White);
				}
			}
		}
	}
}

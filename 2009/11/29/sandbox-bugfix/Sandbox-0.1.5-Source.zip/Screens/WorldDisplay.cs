﻿using System;
using System.Drawing;

using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;
using SdlDotNet.Input;
using SdlDotNet.Core;

using Sandbox.Simulation;

namespace Sandbox.Screens
{
	/// <summary>
	/// Description of MainDisplay.
	/// </summary>
	public class WorldDisplay : Screen
	{		
		// Store the world that we are using.
		World World;
		Rectangle DisplayRegion;
		Box DisplayBox;
		
		/// <summary>
		/// Create a new display.
		/// </summary>
		/// <param name="displayRegion">The region to display the simulation on.</param>
		/// <param name="simulationSize">The size fo the simulation.</param>
		/// <param name="regionDivisions">The number of regions to divide into.</param>
		public WorldDisplay(Rectangle displayRegion, Size simulationSize, int regionDivisions)
			: base(true, true)
		{
			// Store the display region.
			DisplayRegion = displayRegion;
			DisplayBox = new Box(
				(short) (DisplayRegion.X),
				(short) (DisplayRegion.Y),
				(short) (DisplayRegion.X + DisplayRegion.Width),
				(short) (DisplayRegion.Y + DisplayRegion.Height)
			);
			
			// Create a new world.
			World = new World(displayRegion, simulationSize, regionDivisions);
			
			// Listen for keyboard input.
			Events.KeyboardDown += new EventHandler<KeyboardEventArgs>(Events_KeyboardDown);
        }
		
		/// <summary>
        /// Input processing.
        /// </summary>
        /// <param name="sender">Where the event came from.</param>
        /// <param name="e">Event details.</param>
		private void Events_KeyboardDown(object sender, KeyboardEventArgs e)
    	{
			// Pause the simulation.
			if (e.Key == Key.P)
        		World.FlagPaused = !World.FlagPaused;
        	
        	// Toggle borders.
        	if (e.Key == Key.B)
        	{
        		World.Refresh(true);
        		World.FlagBorders = !World.FlagBorders;
        	}
        	
        	// The spacebar will advance the simulation one tick when paused.
        	if (World.FlagPaused && e.Key == Key.Space)
        		World.Update(true);
    	}
		
		/// <summary>
        /// Set the placeable matter type.
        /// </summary>
        /// <param name="s">The new matter type.</param>
        public void SetPlaceableMatter(short i)
        {
        	World.SetPlaceableMatter(i);
        }
		
		/// <summary>
		/// Update the display.
		/// </summary>
		internal override void Update()
		{
			// Update the world (if unpaused).
			World.Update();
		}
		
        /// <summary>
		/// Draw the display.
		/// </summary>
		internal override void Draw(Surface surface)
		{
			// Draw the world.
			World.Draw(surface);		
			
			// Draw a border around the entire world.
			surface.Draw(DisplayBox, Color.White, false, false);
		}
	}
}

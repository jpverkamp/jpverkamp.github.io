﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Xml;
using System.Xml.XPath;

namespace Sandbox.Simulation
{
	/// <summary>
	/// The code to handle matter interaction.
	/// </summary>
	public class Matter
	{
		// Store the matter definitions, each with a byte index.
		ParticleDefinition[] Definitions;
		
		// Store a lookup table associating each ID with its index.
		Dictionary<string, short> MatterIndex = new Dictionary<string, short>();

		// Store reactions by core.
		Dictionary<short, List<ReactionDefinition>> Reactions = new Dictionary<short, List<ReactionDefinition>>();
		
		// Used for randomization in reactions.
		Random Random = new Random();
		
		// Used for semi-randomized colors.
		int RandomColorsVariance = 64;
		int[,] RandomColors;
				
		/// <summary>
		/// Load a given matter definition.
		/// </summary>
		/// <param name="XMLFile">The XML file containing the matter definitions.</param>
		public Matter(string XMLFile)
		{
			// Load the XML document.
			XPathDocument document;
			XPathNavigator root;
			try {
				document = new XPathDocument(XMLFile);
				root = document.CreateNavigator();
			}
			catch(Exception e)
			{
				throw new Exception("Invalid matter definition file (xml is invalid)\n" + e.Message);
			}
			
			// Add any includes that should be processed before this file.
			// TODO: Parse pre-includes
			
			// Parse particle definitions.
			LoadParticles(root);
			
			// Loop through the particle definitions, parsing reactions.
			LoadReactions(root);
			
			// Add any includes that should be processed after this file.
			// TODO: Parse post-includes
			
			// Generate the randomized colors table.
			RandomColors = new int[RandomColorsVariance, RandomColorsVariance];
			for(int x = 0; x < RandomColorsVariance; x++)
				for(int y = 0; y < RandomColorsVariance; y++)
					RandomColors[x, y] = Random.Next(-RandomColorsVariance, RandomColorsVariance);
		}
		
		/// <summary>
		/// Load the particle definitions.
		/// </summary>
		/// <param name="root">The root of the matter definition document.</param>
		private void LoadParticles(XPathNavigator root)
		{
			// Build the index as a list, then convert it.
			List<ParticleDefinition> definitions = new List<ParticleDefinition>();
			definitions.Add(new ParticleDefinition("Empty", MatterType.Solid, Color.Black, false, true));
			MatterIndex["Empty"] = 0;
			
			// Also build the placeable index as a list.
			List<short> placeableIndex = new List<short>();
			placeableIndex.Add(0);
			
			// Loop through the particle definitions, populating the table.
			// Index 0 is reserved for non-reactive empty space.
			short index = 1;
			foreach(XPathNavigator item in root.Select("/Configuration/Particles/Particle"))
			{
				// The variables that we need to parse.
				string id;
				MatterType type;
				Color color;
				
				// Parse the element ID.
				XPathNavigator idNode = item.SelectSingleNode("@ID");
				if (idNode == null)				
					throw new Exception("Invalid matter definition file (missing 'ID' entry)\n" + item.OuterXml);
				id = idNode.InnerXml;
				
				// Parse the type string.
				XPathNavigator typeNode = item.SelectSingleNode("@Type");
				if(typeNode == null)
					throw new Exception("Invalid matter definition file (missing 'Type' entry)\n" + item.OuterXml);
				if (typeNode.InnerXml.Equals("Solid"))
					type = MatterType.Solid;
				else if (typeNode.InnerXml.Equals("Liquid"))
					type = MatterType.Liquid;
				else if (typeNode.InnerXml.Equals("Gas")) 
					type = MatterType.Gas;
				else
					throw new Exception("Invalid matter definition file (invalid 'Type' entry)\n" + item.OuterXml);
					                    
				// Parse the color string.
				XPathNavigator colorNode = item.SelectSingleNode("@Color");
				if (colorNode == null)
					throw new Exception("Invalid matter defintion file (missing 'Color' entry)\n" + item.OuterXml);
				color = Color.FromName(colorNode.InnerXml);
				if (color.Equals(Color.Black) && !colorNode.InnerXml.Equals("Black"))
					throw new Exception("Invalid matter definition file (invalid 'Color' entry)\n" + item.OuterXml);
				
				// Check if it is placeable.
				XPathNavigator placeableNode = item.SelectSingleNode("@Placeable");
				bool placeable = (placeableNode != null);
				
				// Check if it is colorful.
				XPathNavigator colorfulNode = item.SelectSingleNode("@Colorful");
				bool colorful = (colorfulNode  != null);
				
				// Add the matter definition to both tables.
				MatterIndex[id] = index;
				definitions.Add(new ParticleDefinition(id, type, color, placeable, colorful));
				if (placeable) placeableIndex.Add(index);
				index++;
				
				// If we have too many element types, throw an exception.
				if (index <= 0)
					throw new Exception("Invalid matter definition file (too many elements, " + (int.MaxValue) + " allowed)");
			}
			
			// Add the matter definitions to the array.
			Definitions = definitions.ToArray();
		}
		
		/// <summary>
		/// Load the reation. definitions.
		/// </summary>
		/// <param name="root">The root of the matter definition document.</param>
		private void LoadReactions(XPathNavigator root)
		{
			// Loop through reactions, encoding reactant / product names into matter types to speed things up.
			foreach(XPathNavigator item in root.Select("/Configuration/Reactions/Reaction"))
			{
				// Each reaction has a core, zero or more more reactants (each with a concentration), and (generally) a product.
				
				// Check for a valid core.
				XPathNavigator coreNode = item.SelectSingleNode("@Core");
				if (coreNode == null)
					throw new Exception("Invalid matter definition file (missing 'Core' entry)\n" + item.OuterXml);
				if (!MatterIndex.ContainsKey(coreNode.InnerXml))
					throw new Exception("Invalid matter definition file ('" + coreNode.InnerXml + "' is not a valid ID)\n" + item.OuterXml);
				short core = MatterIndex[coreNode.InnerXml];
				
				// Load any/all reactants.
				List<Reactant> reactants = new List<Reactant>();
				foreach(XPathNavigator reactantNode in item.Select("Reactant"))
		        {
					// Check for a valid ID.
					XPathNavigator reactantIDNode = reactantNode.SelectSingleNode("@ID");
					if (reactantIDNode == null)
						throw new Exception("Invalid matter definition file (reactant missing 'ID' entry)\n" + item.OuterXml);
					if (!MatterIndex.ContainsKey(reactantIDNode.InnerXml))
						throw new Exception("Invalid matter definition file ('" + coreNode.InnerXml + "' is not a valid ID)\n" + item.OuterXml);
					short id = MatterIndex[reactantIDNode.InnerXml];
					
					// Check for a valid concentration.
					byte concentration = 0;
					XPathNavigator reactantConcentrationNode = reactantNode.SelectSingleNode("@Concentration");
					if (reactantConcentrationNode == null)
						throw new Exception("Invalid matter definition file (reactant missing 'Concentration' entry)\n" + item.OuterXml);
					if (!byte.TryParse(reactantConcentrationNode.InnerXml, out concentration))
						throw new Exception("Invalid matter definition file ('" + coreNode.InnerXml + "' is not a valid concentration)\n" + item.OuterXml);
					if (concentration < 1 || concentration > 8)
						throw new Exception("Invalid matter definition file ('" + coreNode.InnerXml + "' is not a valid concentration, range is 1-8)\n" + item.OuterXml);
					
					// Add the reactant.
					reactants.Add(new Reactant(id, concentration));
		        }
				
				// Check a reaction chance, if present.
				double chance = 1.0;
				XPathNavigator chanceNode = item.SelectSingleNode("@Chance");
				if (chanceNode != null)
				{
					if (!double.TryParse(chanceNode.InnerXml, out chance))
						throw new Exception("Invalid matter definition file ('" + chanceNode.InnerXml + "' is not a valid 'Chance' entry)\n" + item.OuterXml);
					if (chance < 0.0 || chance > 1.0)
						throw new Exception("Invalid matter definition file ('" + chanceNode.InnerXml + "' is not a valid concentration, range is 0.0-1.0)\n" + item.OuterXml);
				}
				
				// Check for a valid product (default to empty if the node is missing).
				short product = 0;
				XPathNavigator productNode = item.SelectSingleNode("@Product");
				if (productNode != null)
				{
					if (!MatterIndex.ContainsKey(productNode.InnerXml))
						throw new Exception("Invalid matter definition file ('" + productNode.InnerXml + "' is not a valid ID)\n" + item.OuterXml);
					product = MatterIndex[productNode.InnerXml];
				}
				
				// If we made it this far, we have a valid reaction.  Add it.
				if (!Reactions.ContainsKey(core))
					Reactions[core] = new List<ReactionDefinition>();
				Reactions[core].Add(new ReactionDefinition(core, reactants.ToArray(), product, chance));
			}		
		}
		
		#region Accessors
		
		/// <summary>
		/// Turn a matter name into an index.
		/// </summary>
		/// <param name="name">The name to convert.</param>
		/// <returns>The associated value.</returns>
		public short GetIndex(string name)
		{
			if (MatterIndex.ContainsKey(name))
				return MatterIndex[name];
			else
				return 0;
		}
		
		/// <summary>
		/// Accessor for ID.
		/// </summary>
		/// <param name="i">The index of the matter to access.</param>
		/// <returns>The matter's ID.</returns>
		public string GetID(short i)
		{
			return Definitions[i].ID;
		}
		
		/// <summary>
		/// Accessor for colors.
		/// </summary>
		/// <param name="i">The index of the matter to access.</param>
		/// <returns>The requested matter color.</returns>
		public Color GetColor(short i)
		{
			return Definitions[i].Color;
		}
		
		/// <summary>
		/// Accessor for colors.
		/// </summary>
		/// <param name="i">The index of the matter to access.</param>
		/// <param name="x">The x-coordinate of the matter that needs a color.</param>
		/// <param name="y">The y-coordinate of the matter that needs a color.</param>
		/// <returns>The requested matter color.</returns>
		public Color GetColor(short i, int x, int y)
		{
			if (Definitions[i].Colorful)
			{
				int r1 = Math.Abs(x + y) % RandomColorsVariance;
				int r2 = Math.Abs(x * y) % RandomColorsVariance;
				
				return Color.FromArgb(
					Math.Min(255, Math.Max(0, ((int) Definitions[i].Color.R) + RandomColors[r1, r2])),
					Math.Min(255, Math.Max(0, ((int) Definitions[i].Color.G) + RandomColors[r2, r1])),
					Math.Min(255, Math.Max(0, ((int) Definitions[i].Color.B) + RandomColors[r2, r2]))
				);
			}
			else
				return Definitions[i].Color;
		}
		
		/// <summary>
		/// Accessor for matter types.
		/// </summary>
		/// <param name="i">The index of the matter to access.</param>
		/// <returns>The requested matter type.</returns>
		public MatterType GetType(short i)
		{
			return Definitions[i].Type;
		}
		
		/// <summary>
		/// Accessor for placeability.
		/// </summary>
		/// <param name="i">The index of the matter to access.</param>
		/// <returns>If the matter can be placed.</returns>
		public bool IsPlaceable(short i)
		{
			return Definitions[i].Placeable;
		}
		
		/// <summary>
		/// Accessor for the number of matter types.
		/// </summary>
		/// <returns>The number of matter types.</returns>
		public int Length
		{
			get {
				return Definitions.Length;
			}
		}
		
		#endregion
		
		/// <summary>
		/// Try to react.
		/// </summary>
		/// <param name="core">Core of the reaction.</param>
		/// <param name="reactants">Possible reactants.</param>
		/// <param name="chance">Random factor.</param>
		/// <returns></returns>
		public short React(short core, short[] reactants)
		{
			// Don't even try if there is no reaction.
			if (!Reactions.ContainsKey(core))
				return core;
			
			// Try each possible reaction.
			short concentration = 0;
			bool success = true;
			foreach(ReactionDefinition reaction in Reactions[core])
			{
				// Assume each time that it works.
				success = true;
				
				// Check each reactant.
				foreach(Reactant reactant in reaction.Reactants)
				{
					concentration = reactant.Concentration;
					foreach(short r in reactants)
					{
						if (r == reactant.ID)
							concentration--;
						if (concentration <= 0)
							break;
					}
					if (concentration > 0)
						success = false;
				}
				
				// Check for reaction chance.
				if (reaction.Chance < 1.0 && Random.NextDouble() > reaction.Chance)
					success = false;
					
				// We reacted!
				if (success)
					return reaction.Product;
				
				// Otherwise, try another one.
			}
			
			// No reaction found, return the original value.
			return core;
		}
	}
}
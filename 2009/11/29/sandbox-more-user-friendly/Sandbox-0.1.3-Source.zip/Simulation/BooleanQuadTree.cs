﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace Sandbox.Simulation
{
	/// <summary>
	/// A quad tree that can store a single property.
	/// 
	/// HACK: For now, all BooleanQuadTrees should be square with sides that are powers of 2.
	/// HACK: This code assumes (should be true though) that children are either some or all.
	/// </summary>
	public class BooleanQuadTree
	{
		// Each QuadTree has (up to) four children.
		BooleanQuadTree TopLeft;
		BooleanQuadTree TopRight;
		BooleanQuadTree BottomLeft;
		BooleanQuadTree BottomRight;

		// Store the boundries of this level.
		Rectangle Region;
		Point Center;
		
		// Each level of the quad tree stores some kind of value.
		BooleanQuadTreeType Type;
		bool Value;
		bool Buffer;
		
		/// <summary>
		/// Create a new quadtree of the given size, type, and value.
		/// </summary>
		/// <param name="source">The size of the quad tree to create.</param>
		/// <param name="minimum">The minimum resolution of a child rectangle.</param>
		/// <param name="type">The type of quadtree to create.</param>
		/// <param name="initialValue">The initial value to set each node to.</param>
		public BooleanQuadTree(Rectangle source, Size minimum, BooleanQuadTreeType type, bool initialValue)
		{
			// Store the parameters that we will need later.
			Region = source;
			Type = type;
			Value = initialValue;
			Center = new Point(source.X + source.Width / 2, source.Y + source.Height / 2);
			
			// If we are already small enough (in either dimension), do not divide further.
			if (source.Width <= minimum.Width || source.Height <= minimum.Height)
				return;
				
			// Divide into quarters, creating the four smaller quadtrees.
			TopLeft = new BooleanQuadTree(new Rectangle(source.X, source.Y, source.Width / 2, source.Height / 2), minimum, type, initialValue);
			TopRight = new BooleanQuadTree(new Rectangle(source.X + source.Width / 2, source.Y, source.Width / 2, source.Height / 2), minimum, type, initialValue);
			BottomLeft = new BooleanQuadTree(new Rectangle(source.X, source.Y + source.Height / 2, source.Width / 2, source.Height / 2), minimum, type, initialValue);
			BottomRight = new BooleanQuadTree(new Rectangle(source.X + source.Width / 2, source.Y + source.Height / 2, source.Width / 2, source.Height / 2), minimum, type, initialValue);
		}
		
		/// <summary>
		/// Get the value of a node at a specific point.
		/// </summary>
		/// <param name="p">The point to search for.</param>
		/// <returns>The value at the given point.</returns>
		public bool Get(Point p)
		{
			// AND trees can stop looking at the first true (all children must be true).
			if (Type == BooleanQuadTreeType.And && Value) return true;
			
			// OR trees can stop looking at the first false (all children must be false).
			if (Type == BooleanQuadTreeType.Or && !Value) return false;
		
			// Stop at the root.
			if (TopLeft == null)
				return Value;
			
			// Check the correct child.
			if (p.X < Center.X)
				if (p.Y < Center.Y)
					return TopLeft.Get(p);
				else 
					return BottomLeft.Get(p);
			else
				if (p.Y < Center.Y)
					return TopRight.Get(p);
				else 
					return BottomRight.Get(p);
		}
		
		/// <summary>
		/// Set a value at the specified point.
		/// </summary>
		/// <param name="value">The new value.</param>
		/// <param name="buffer">Set buffer to wait to apply changes.</param>
		public void Set(Point p, bool value, bool buffer)
		{
			// Logic for AND trees.
			if (Type == BooleanQuadTreeType.And)
			{
				// All children of true nodes are true.
				if (value && Buffer) return;
				
				// False values will cascade up the tree.
				if (!value)
					if (buffer)
						Buffer = false;
					else
						Value = false;
			}
			
			// Logic for OR trees.
			if (Type == BooleanQuadTreeType.Or)
			{
				// All children of false nodes are false.
				if (!value && !Buffer) return;
				
				// True values will cascade up the tree.
				if (value)
					if (buffer)
						Buffer = true;
					else
						Value = true;
			}
			
			// If we are at the bottom level, set me and finish.
			if (TopLeft == null)
			{
				if (buffer)
					Buffer = value;
				else
					Value = value;
				
				return;
			}
				
			// Otherwise, set the correct child (if we haven't taken a shortcut).
			if (p.X < Center.X)
				if (p.Y < Center.Y)
					TopLeft.Set(p, value, buffer);
				else 
					BottomLeft.Set(p, value, buffer);
			else
				if (p.Y < Center.Y)
					TopRight.Set(p, value, buffer);
				else 
					BottomRight.Set(p, value, buffer);
			
			// If something was set, check for updates.
			
			// AND trees that changed to true need to check for updates.
			if (Type == BooleanQuadTreeType.And && value)
				if (buffer)
					Buffer = TopLeft.Buffer && TopRight.Buffer && BottomLeft.Buffer && BottomRight.Buffer;
				else
					Value = TopLeft.Value && TopRight.Value && BottomLeft.Value && BottomRight.Value;

			// OR trees that changed to false need to check for updates.
			if (Type == BooleanQuadTreeType.Or && !value)
				if (buffer)
					Buffer = TopLeft.Buffer || TopRight.Buffer || BottomLeft.Buffer || BottomRight.Buffer;
				else
					Value = TopLeft.Value || TopRight.Value || BottomLeft.Value || BottomRight.Value;
		}
		
		/// <summary>
		/// Set all values in the tree to the given value.
		/// </summary>
		/// <param name="value">The new overriding value.</param>
		public void SetAll(bool value, bool buffer)
		{
			if (buffer)
				Buffer = value;
			else
				Value = value;
			
			if (TopLeft != null)
			{
				TopLeft.SetAll(value, buffer);
				TopRight.SetAll(value, buffer);
				BottomLeft.SetAll(value, buffer);
				BottomRight.SetAll(value, buffer);
			}
		}
		
		/// <summary>
		/// Set all values in the true to the given value.
		/// </summary>
		/// <param name="value">The new overriding value.</param>
		public void Apply()
		{
			Value = Buffer;
			
			if (TopLeft != null)
			{
				TopLeft.Apply();
				TopRight.Apply();
				BottomLeft.Apply();
				BottomRight.Apply();
			}
		}
		
		/// <summary>
		/// Iterate over all regions with the given value.
		/// </summary>
		/// <param name="value">The value to check.</param>
		/// <returns>An enumeration of regions that have the specified value.</returns>
		public IEnumerable<Rectangle> Regions(bool target)
		{
			// If we have no children, directly check the value.
			if (TopLeft == null && target == Value)
				yield return Region;

			// An AND tree that is true will only contain true children.
			if (Type == BooleanQuadTreeType.And && Value)
			{
				if (target)
					yield return Region;
				yield break;
			}
				
			// An OR tree that is false will only contain false children.
			if (Type == BooleanQuadTreeType.Or && !Value)
			{
				if (!target)
					yield return Region;
				yield break;
			}
			
			// Otherwise, at least one of the children has the wrong value.  Try the rest.
			if (TopLeft != null)
			{
				foreach(Rectangle r in BottomRight.Regions(target)) yield return r;
				foreach(Rectangle r in BottomLeft.Regions(target)) yield return r;
				foreach(Rectangle r in TopRight.Regions(target)) yield return r;
				foreach(Rectangle r in TopLeft.Regions(target)) yield return r;
			}
		}
	}
	
	/// <summary>
	/// Enumeration of possible quadtree logic types.
	/// </summary>
	public enum BooleanQuadTreeType
	{
		And,	// True if all children are true.
		Or		// True if any child is true.
	}
}

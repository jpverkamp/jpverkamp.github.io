﻿using System;
using System.Collections.Generic;
using System.Text;

using SdlDotNet.Core;
using SdlDotNet.Graphics;

namespace Sandbox.Screens
{
    /// <summary>
    /// Keeps track of screens for a given game.
    /// </summary>
    class ScreenManager
    {
        // Maintain a list of screens.
        LinkedList<Screen> Screens = new LinkedList<Screen>();

        // Keep a list of screens to add/remove so that update cycles don't break.
        LinkedList<Screen> ToAdd = new LinkedList<Screen>();
        int ToRemove = 0;

        /// <summary>
        /// Initialize the screen manager with it's basic screen.
        /// 
        /// A screen manager must have at least one screen.  As soon as the last screen is removed, the game will exit.
        /// </summary>
        public ScreenManager(Screen screen)
        {
            ToAdd.AddLast(screen);
        }

        /// <summary>
        /// Add a new screen to the top of the manager.
        /// </summary>
        /// <param name="screen">The new screen to add.</param>
        public void Add(Screen screen)
        {
            ToAdd.AddLast(screen);
        }

        /// <summary>
        /// Remove the top screen.
        /// </summary>
        public void Remove(){
            ToRemove++;
        }

        /// <summary>
        /// The top screen.
        /// </summary>
        /// <returns>The top screen.</returns>
        public Screen Top()
        {
            if (Screens.Last == null)
                return null;
            else
                return (Screen)Screens.Last.Value;
        }

        /// <summary>
        /// Update the screens contained in the screen manager.
        /// </summary>
        public void Update()
        {
            // Find the lowest screen to update.
            LinkedListNode<Screen> current = Screens.Last;
            
            // Keep going until we have a null screen or the update pass is false.
            while (current != null && current.Previous != null && ((Screen)current.Value).UpdateThrough)
                current = current.Previous;

            // Now go the other way and update the screens.
            while (current != null)
            {
                ((Screen)current.Value).Update();
                current = current.Next;
            }

            // Remove screens that need to be removed.
            while (ToRemove > 0)
            {
                Screens.RemoveLast();
                ToRemove--;
            }

            // Add screens that need to be added.
            foreach (Screen screen in ToAdd)
            {
                screen.Manager = this;
                Screens.AddLast(screen);
            }
            ToAdd.Clear();

            // If there are no screens, exit.
            if (Screens.First == null)
            	Events.QuitApplication();
        }

        /// <summary>
        /// Draw the screens contained in the screen manager.
        /// </summary>
        /// 
        public void Draw(Surface surface)
        {
            // Find the lowest screen to update.
            LinkedListNode<Screen> current = Screens.Last;

            // Keep going until we have a null screen or the draw pass is false.
            while (current != null && current.Previous != null && ((Screen)current.Value).DrawThrough)
                current = current.Previous;

            // Now go the other way and update the screens.
            while (current != null)
            {
                ((Screen)current.Value).Draw(surface);
                current = current.Next;
            }
        }
    }
}

using System;
using System.Collections.Generic;
using System.Drawing;
using Sandbox.Screens;
using Sandbox.Simulation;

using SdlDotNet.Graphics;
using SdlDotNet.Input;
using SdlDotNet.Core;

namespace Sandbox
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Sandbox
    {
    	// Constant settings.
    	public static bool DEBUG_DISPLAY_REGIONS = false;
    	public static bool DEBUG_PAUSED = false;
    	public static bool DEBUG_SOURCES = true;
    	public static bool DEBUG_BORDERS = false;
    	public const int DEBUG_SCALE_FACTOR = 5;
    	
    	// The screen manager to use for this Sandbox.
    	ScreenManager ScreenManager;
    	
    	// The surface that we should draw everything to.
    	Surface Surface;
    	
        /// <summary>
        /// Entry point for the programm.
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
        	// TODO: Process command line parameters.
        	
        	// Create a new Sandbox.
        	new Sandbox(
        		30,			// FPS
        		512,		// Width
        		512,		// Height
        		1			// Scale
        	);
        }
        
        /// <summary>
        /// Create a new Sandbox simulation.
        /// </summary>
        /// <param name="fps">FPS to aim for.</param>
        /// <param name="width">Width of the simulation window.</param>
        /// <param name="height">Height of the simulation window.</param>
        /// <param name="scale">Simulation scaling factor.</param>
        public Sandbox(int fps, int width, int height, int scale)
        {
        	// Initialize the display.
        	//Video.WindowIcon(); // TODO: Design and add program icon.
			Video.WindowCaption = "Sandbox";
			Surface = Video.SetVideoMode(width, height);

			// Create the main display window.
            ScreenManager = new ScreenManager(new WorldDisplay(
            	new Rectangle(0, 0, width, height),
            	new Size(width / scale, height / scale)
            ));
			            
			// Bind to the event listeners.
			Events.KeyboardDown += new EventHandler<KeyboardEventArgs>(KeyDown);
   			Events.Quit += new EventHandler<QuitEventArgs>(Quit);
   			Events.Tick += new EventHandler<TickEventArgs>(Tick);
   			Events.Fps = 30;
   			Events.Run();
        }
    
        /// <summary>
        /// Input processing.
        /// </summary>
        /// <param name="sender">Where the event came from.</param>
        /// <param name="e">Keyboard event details.</param>
		private void KeyDown(object sender, KeyboardEventArgs e)
    	{
			// Allow the user to exit the program.
        	if (e.Key == Key.Escape || e.Key == Key.Q)
            	Events.QuitApplication();
        	
        	// Toggle the region display.
        	if (e.Key == Key.F1)
        	{
        		// Clear the screen.
        		Surface.Fill(Color.Black);

        		// Toggle the flag.
        		DEBUG_DISPLAY_REGIONS = !DEBUG_DISPLAY_REGIONS;
        		
        		// Refresh the world.
        		if (ScreenManager.Top() != null && ScreenManager.Top() is WorldDisplay)
        		{
        			((WorldDisplay) ScreenManager.Top()).Refresh();
        			((WorldDisplay) ScreenManager.Top()).Draw(Surface);
        			((WorldDisplay) ScreenManager.Top()).Update();
        			((WorldDisplay) ScreenManager.Top()).Draw(Surface);
        		}
        	}
        	
        	// Pause the simulation.
        	if (e.Key == Key.P)
        		DEBUG_PAUSED = !DEBUG_PAUSED;
        	
        	// Toggle sources.
        	if (e.Key == Key.S)
        		DEBUG_SOURCES = !DEBUG_SOURCES;
        	
        	// Toggle borders.
        	if (e.Key == Key.B)
        	{
        		if (ScreenManager.Top() != null && ScreenManager.Top() is WorldDisplay)
        			((WorldDisplay) ScreenManager.Top()).Refresh();
        		DEBUG_BORDERS = !DEBUG_BORDERS;
        	}
        	
        	// The spacebar will advance the simulation one tick when paused.
        	if (DEBUG_PAUSED && e.Key == Key.Space)
        		if (ScreenManager.Top() != null && ScreenManager.Top() is WorldDisplay)
        			((WorldDisplay) ScreenManager.Top()).Update();
    	}

		/// <summary>
		/// Quit the program.
		/// </summary>
		/// <param name="sender">Where the event came from.</param>
		/// <param name="e">Quit event details.</param>
        private void Quit(object sender, QuitEventArgs e)
	    {
    	    Events.QuitApplication();
    	}

        /// <summary>
        /// Main loop, should be called based on the frameaate.
        /// </summary>
        /// <param name="sender">Where the event came from.</param>
        /// <param name="e">Tick event details.</param>
    	private void Tick(object sender, TickEventArgs e)
    	{
    		#region DEBUG: Display fps and particle count.
        	// Update the window title.
        	if (ScreenManager.Top() != null && ScreenManager.Top() is WorldDisplay)
        		Video.WindowCaption = "Sandbox - " + e.Fps + " FPS - " + ((WorldDisplay) ScreenManager.Top()).Count + " particles";
 			else
        		Video.WindowCaption = "Sandbox - " + e.Fps + " FPS - ??? particles";
 			#endregion

    		// Update everything (if not paused).
    		if (!DEBUG_PAUSED)
        		ScreenManager.Update();
    		
        	// Then draw.
        	ScreenManager.Draw(Surface);
        	Surface.Update();
		}
    }
}

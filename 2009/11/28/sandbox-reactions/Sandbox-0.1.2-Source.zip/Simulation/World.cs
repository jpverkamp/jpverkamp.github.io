﻿using System;
using System.Collections.Generic;
using System.Drawing;

using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;

namespace Sandbox.Simulation
{
    /// <summary>
    /// The screen that does all of the simulation of an actual world.
    /// </summary>
    public class World
    {   
    	// Used for twisty turny awesomeness.
    	Random Random;
    	
    	// The matter data and definitions.
    	internal int Width;
    	internal int Height;
    	short[,] Data;
    	Matter Matter;
    	
    	// Matter particle count (and accessor).
    	int ParticleCount = 0;
    	public int Count { get { return ParticleCount; } }
    	
    	// The display region and scaling factors.
    	Rectangle DisplayRegion;
    	int ScaleX;
		int ScaleY;

    	// Keep track of which regions are active.
    	BooleanQuadTree Active;
    	
    	#region DEBUG - Accessor for active regions.
    	public IEnumerable<Rectangle> ActiveRegions
    	{
    		get {
    			return Active.Regions(true);
    		}
    	}
    	
    	public IEnumerable<Rectangle> InactiveRegions
    	{
    		get {
    			return Active.Regions(false);
    		}
    	}
    	#endregion
    	
    	#region DEBUG - Accessor to force regions or inactive.
    	public void ForceActive(Point p, bool active)
    	{
    		Active.Set(p, active, false);
    	}
    	#endregion
    	
        /// <summary>
        /// Create a new world of the given size.
        /// </summary>
        /// <param name="display">The display region.</param>
        /// <param name="size">The size of the world</param>
        public World(Rectangle display, Size size)
        {
        	// Initialize the randomness.
        	Random = new Random();
        	
        	// Store the display and calculate scaling factors.
        	DisplayRegion = display;
        	ScaleX = display.Width / size.Width;
        	ScaleY = display.Height / size.Height;
        	
        	// Store the size.
        	Width = size.Width;
        	Height = size.Height;
        	
        	// Create the data array.
        	Data = new short[Width, Height];
        	
        	// Load the matter definitions.
        	Matter = new Matter("Data/Default.txt");
        	
        	// Calculate the size of each region.
        	int regionSize = Math.Max(1, (int) (Math.Pow(2, Math.Log(Math.Max(Width, Height), 2) - Sandbox.DEBUG_SCALE_FACTOR - 1)));
        	
        	// Initialize the quadtrees.
        	Active = new BooleanQuadTree(new Rectangle(0, 0, Width, Height), new Size(regionSize, regionSize), BooleanQuadTreeType.Or, false);
        	
        	#region DEBUG - Add some test walls.
        	for (int x = Width / 8; x < 7 * Width / 8; x++)
        		for (int yd = -1; yd <= 1; yd++)
	        		Set(x, 4 * Height / 5 + yd, 5);
        	Active.Apply();
        	#endregion
        }

        /// <summary>
        /// Set the matter at a given point to a given type.
        /// </summary>
        private void Set(int x, int y, short type)
        {
        	if (Data[x, y] == 0 && type != 0) ParticleCount++;
        	if (Data[x, y] != 0 && type == 0) ParticleCount--;
        	
        	Data[x, y] = type;
        	
        	Active.Set(new Point(x, y), true, true);
        	
        	#region EXPERIMENT - Try to make the regions settle in rougher edges
//        	Active.Set(new Point(x - 5, y), true, true);
//        	Active.Set(new Point(x + 5, y), true, true);
//        	Active.Set(new Point(y, y - 5), true, true);
//        	Active.Set(new Point(y, y + 5), true, true);
        	#endregion
        }
        
        /// <summary>
        /// Refresh the screen.
        /// </summary>
        internal void Refresh()
        {
        	Active.SetAll(true, false);
        }
        
        /// <summary>
        /// Update the world.
        /// </summary>
        internal void Update()
        {
        	#region DEBUG - Add test particles.
        	if (Sandbox.DEBUG_SOURCES)
        	{
	        	for (int i = 0; i < 10; i++)
	        	{
	        		Set(Random.Next(2 * Width / 5, 3 * Width / 5), 0, Matter.GetIndex("Water"));
	        	}
	        	
//	        	for (int i = 0; i < 10; i++)
//	        	{
//	        		Set(Random.Next(8 * Width / 17, 9 * Width / 17), 17 * Height / 18, Matter.GetIndex("Fire"));
//	        	}
	        	
	        	for (int i = 0; i < 10; i++)
	        	{
	        		Set(Random.Next(Width / 2 - 2, Width / 2 + 2), Width / 2 + 1, Matter.GetIndex("Fire"));
	        	}

	        	Active.Apply();
        	}
        	#endregion
        	
        	// Clear the map.
        	Active.SetAll(false, true);

        	// Loop through active regions for reactions.
        	foreach(Rectangle region in Active.Regions(true))
        		for(int x = region.Left; x < region.Right; x++)
        			for(int y = region.Top; y < region.Bottom; y++)
        				if (!(x < 0 || x >= Width || y < 0 || y >= Height) && Data[x, y] > 0)
        					React(x, y);
        	
        	// Loop through active regions for movement.
        	foreach(Rectangle region in Active.Regions(true))
        		for(int x = region.Left; x < region.Right; x++)
        			for(int y = region.Top; y < region.Bottom; y++)
        				if (!(x < 0 || x >= Width || y < 0 || y >= Height) && Data[x, y] > 0)
        					Move(x, y);

        	// Apply the values in the buffer.
        	Active.Apply();
        }
        
        /// <summary>
        /// React the matter at the given location with its neighbors.
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        private void React(int x, int y)
        {
        	// Check for a reaction.
        	if (x > 0 && x < Width - 1 && y > 0 && y < Height - 1)
        	{
        		short product = Matter.React(Data[x, y], new short[]{
	             	Data[x - 1, y - 1], Data[x - 1, y + 0], Data[x - 1, y + 1],
	             	Data[x + 0, y - 1],                     Data[x + 0, y + 1],
	             	Data[x + 1, y - 1], Data[x + 1, y + 0], Data[x + 1, y + 1],
				});
        		if (Data[x, y] != product)
        			Set(x, y, product);
        	}
        }
        
        /// <summary>
        /// Move the matter particle at the given location.
        /// </summary>
        /// <param name="x">The x-location of the matter to move.</param>
        /// <param name="y">The y-location of the matter to move.</param>
        private void Move(int x, int y)
        {
        	// Solid matter doesn't move.
			if (Matter.GetType(Data[x, y]) == MatterType.Solid)
			{
				
			}
			
			// Otherwise, move it!
			else
			{
				// Start at the original location.
				int xd = x;
				int yd = y;
				
				// Liquids try to move down, gasses try to move up.
				if (Matter.GetType(Data[x, y]) == MatterType.Liquid) yd += 1;
				if (Matter.GetType(Data[x, y]) == MatterType.Gas) yd -= 1;
				
				// A bit of random variance.
				xd += Random.Next(-2, 3);
				yd += Random.Next(-2, 3) / 2;

				// Do not deactivate particles that choose not to move.
				if (xd == x && yd == y)
					Set(x, y, Data[x, y]);
				
				// Check for out of bounds matter.
				if (xd < 0 || xd >= Width || yd < 0 || yd >= Height)
				{
					// Stick
					if (Sandbox.DEBUG_BORDERS)
						return;
					
					// Remove
					else
						Set(x, y, 0);
				}
				
				// Check for empty squares.
				else if (Data[xd, yd] == 0)
				{
					Set(xd, yd, (short) -Data[x, y]);
					Set(x, y, 0);
				}
				
				// Check to see if we're stuck.
				else
				{
					bool stuck = true;
					for(int xdd = x - 2; xdd <= x + 2; xdd++)
						for(int ydd = y - 1; ydd <= y + 1; ydd++)
							if (xdd < 0 || xdd >= Width || ydd < 0 || ydd >= Height)
								stuck = false;
							else if (Data[xdd, ydd] == 0)
								stuck = false;
					if (!stuck)
						Set(x, y, Data[x, y]);
				}
			}
        }
        
        /// <summary>
        /// Draw the world.
        /// </summary>
        /// <param name="surface">The surface to draw to.</param>
        internal void Draw(Surface surface)
        {
        	// Loop through all active regions.
			foreach(Rectangle region in Active.Regions(true))
			{
				// Clear active regions.
				surface.Draw(new Box(
					(short) (DisplayRegion.X + (region.X * ScaleX)),
					(short) (DisplayRegion.Y + (region.Y * ScaleY)),
					(short) (DisplayRegion.X + (region.X * ScaleX) + region.Width * ScaleX),
					(short) (DisplayRegion.Y + (region.Y * ScaleY) + region.Height * ScaleY)
				), Color.Black, false, true);
								
				// Draw matter in those regions.
        		for(int x = region.Left; x < region.Right; x++)
        		{
        			for(int y = region.Top; y < region.Bottom; y++)
        			{
        				// Do not draw particles off of the edge of the map.
        				if (x < 0 || x >= Width || y < 0 || y >= Height)
        					continue;
        				else if (Data[x, y] != 0)
        				{
        					// Unbuffer elements.
        					Data[x, y] = Math.Abs(Data[x, y]);
        					
        					// Display them.
        					surface.Draw(new Box(
								(short) (DisplayRegion.X + (x * ScaleX)),
								(short) (DisplayRegion.Y + (y * ScaleY)),
								(short) (DisplayRegion.X + (x * ScaleX) + ScaleX),
								(short) (DisplayRegion.Y + (y * ScaleY) + ScaleY)
							), Matter.GetColor(Data[x, y]), false, true);
        				}
        			}
        		}
			}
        }
    }
}

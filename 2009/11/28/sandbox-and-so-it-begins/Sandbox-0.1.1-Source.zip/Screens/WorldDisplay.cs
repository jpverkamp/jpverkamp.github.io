﻿using System;
using System.Drawing;

using SdlDotNet.Graphics;
using SdlDotNet.Graphics.Primitives;

using Sandbox.Simulation;

namespace Sandbox.Screens
{
	/// <summary>
	/// Description of MainDisplay.
	/// </summary>
	public class WorldDisplay : Screen
	{		
		// Store the world that we are using.
		World World;
		Rectangle DisplayRegion;
		
		// Access the world's matter count.
		public int Count { get { return World.Count; } }
		
		/// <summary>
		/// Create a new display.
		/// </summary>
		/// <param name="displayRegion">The region to display the simulation on.</param>
		/// <param name="simulationSize">The size fo the simulation.</param>
		public WorldDisplay(Rectangle displayRegion, Size simulationSize)
			: base(true, true)
		{
			// Store the display region.
			DisplayRegion = displayRegion;
			
			// Create a new world.
			World = new World(displayRegion, simulationSize);
        }
		
		/// <summary>
		/// Refresh the contained world.
		/// </summary>
		internal void Refresh()
		{
			World.Refresh();
		}
		
		/// <summary>
		/// Update the display.
		/// </summary>
		internal override void Update()
		{
			// Update the world.
			World.Update();
		}
		
        /// <summary>
		/// Draw the display.
		/// </summary>
		internal override void Draw(Surface surface)
		{
			// Draw the world.
			World.Draw(surface);
			
			#region DEBUG - Draw the display regions.
			if (Sandbox.DEBUG_DISPLAY_REGIONS)
			{
				int ScaleX = DisplayRegion.Width / World.Width;
				int ScaleY = DisplayRegion.Height / World.Height;
				
				// Active
				foreach(Rectangle region in World.ActiveRegions)
				{
					surface.Draw(new Box(
						(short) (DisplayRegion.X + (region.X * ScaleX)),
						(short) (DisplayRegion.Y + (region.Y * ScaleY)),
						(short) (DisplayRegion.X + (region.X * ScaleX) + region.Width * ScaleX),
						(short) (DisplayRegion.Y + (region.Y * ScaleY) + region.Height * ScaleY)
					), Color.Red, false, true);
					surface.Draw(new Box(
						(short) (DisplayRegion.X + (region.X * ScaleX)),
						(short) (DisplayRegion.Y + (region.Y * ScaleY)),
						(short) (DisplayRegion.X + (region.X * ScaleX) + region.Width * ScaleX),
						(short) (DisplayRegion.Y + (region.Y * ScaleY) + region.Height * ScaleY)
					), Color.Black);
				}
				
				// Inactive
				foreach(Rectangle region in World.InactiveRegions)
				{
					surface.Draw(new Box(
						(short) (DisplayRegion.X + (region.X * ScaleX)),
						(short) (DisplayRegion.Y + (region.Y * ScaleY)),
						(short) (DisplayRegion.X + (region.X * ScaleX) + region.Width * ScaleX),
						(short) (DisplayRegion.Y + (region.Y * ScaleY) + region.Height * ScaleY)
					), Color.Blue, false, true);
					surface.Draw(new Box(
						(short) (DisplayRegion.X + (region.X * ScaleX)),
						(short) (DisplayRegion.Y + (region.Y * ScaleY)),
						(short) (DisplayRegion.X + (region.X * ScaleX) + region.Width * ScaleX),
						(short) (DisplayRegion.Y + (region.Y * ScaleY) + region.Height * ScaleY)
					), Color.Black);
				}
			}
			#endregion
		}
	}
}

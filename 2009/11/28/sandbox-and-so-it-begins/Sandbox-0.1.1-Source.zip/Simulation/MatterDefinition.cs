﻿using System;
using System.Drawing;

namespace Sandbox.Simulation
{
	/// <summary>
	/// Holds a definition of a particular type of matter.
	/// </summary>
	public struct MatterDefinition
	{
		// The matter's properties.
		public readonly string ID;
		public readonly MatterType Type;
		public readonly Color Color;
		
		/// <summary>
		/// Create a new matter definition.
		/// </summary>
		/// <param name="id">The matter ID.</param>
		/// <param name="type">The type of matter.</param>
		/// <param name="color">The color to use for the matter.</param>
		public MatterDefinition(string id, MatterType type, Color color)
		{
			ID = id;
			Type = type;
			Color = color;
		}
	}
	
	/// <summary>
	/// Possible types of matter.
	/// </summary>
	public enum MatterType {
		Solid,	// Stationary
		Liquid,	// Falls
		Gas,	// Rises
	};
}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Xml;
using System.Xml.XPath;

namespace Sandbox.Simulation
{
	/// <summary>
	/// The code to handle matter interaction.
	/// </summary>
	public class Matter
	{
		// Store the matter definitions, each with a byte index.
		Dictionary<int, MatterDefinition> Definitions = new Dictionary<int, MatterDefinition>();
				
		/// <summary>
		/// Load a given matter definition.
		/// </summary>
		/// <param name="XMLFile">The XML file containing the matter definitions.</param>
		public Matter(string XMLFile)
		{
			// Load the XML document.
			XPathDocument document;
			XPathNavigator root;
			try {
				document = new XPathDocument(XMLFile);
				root = document.CreateNavigator();
			}
			catch(Exception e)
			{
				throw new Exception("Invalid matter definition file (xml is invalid)\n" + e.Message);
			}
			
			// Add any includes that should be processed before this file.
			// TODO: Parse pre-includes
			
			// Parse particle definitions.
			LoadParticles(root);
			
			// Loop through the particle definitions, parsing reactions.
			LoadReactions(root);
			
			// Add any includes that should be processed after this file.
			// TODO: Parse post-includes
		}
		
		/// <summary>
		/// Load the particle definitions.
		/// </summary>
		/// <param name="root">The root of the matter definition document.</param>
		private void LoadParticles(XPathNavigator root)
		{
			// Loop through the particle definitions, populating the table.
			// Index 0 is reserved for non-reactive empty space.
			int index = 1;
			foreach(XPathNavigator item in root.Select("/Configuration/Particles/Particle"))
			{
				// The variables that we need to parse.
				string id;
				MatterType type;
				Color color;
				
				// Parse the element ID.
				XPathNavigator idNode = item.SelectSingleNode("@ID");
				if (idNode == null)				
					throw new Exception("Invalid matter definition file (missing 'ID' entry)\n" + item.OuterXml);
				id = idNode.InnerXml;
				
				// Parse the type string.
				XPathNavigator typeNode = item.SelectSingleNode("@Type");
				if(typeNode == null)
					throw new Exception("Invalid matter definition file (missing 'Type' entry)\n" + item.OuterXml);
				if (typeNode.InnerXml.Equals("Solid"))
					type = MatterType.Solid;
				else if (typeNode.InnerXml.Equals("Liquid"))
					type = MatterType.Liquid;
				else if (typeNode.InnerXml.Equals("Gas")) 
					type = MatterType.Gas;
				else
					throw new Exception("Invalid matter definition file (invalid 'Type' entry)\n" + item.OuterXml);
					                    
				// Parse the color string.
				XPathNavigator colorNode = item.SelectSingleNode("@Color");
				if (colorNode == null)
					throw new Exception("Invalid matter defintion file (missing 'Color' entry)\n" + item.OuterXml);
				color = Color.FromName(colorNode.InnerXml);
				if (color.Equals(Color.Black) && !colorNode.InnerXml.Equals("Black"))
					throw new Exception("Invalid matter definition file (invalid 'Color' entry)\n" + item.OuterXml);
				
				// Add the matter definition.
				Definitions[index++] = new MatterDefinition(id, type, color);
				
				// If we have too many element types, throw an exception.
				if (index <= 0)
					throw new Exception("Invalid matter definition file (too many elements, " + (int.MaxValue) + " allowed)");
			}
		}
		
		/// <summary>
		/// Load the reation. definitions.
		/// </summary>
		/// <param name="root">The root of the matter definition document.</param>
		private void LoadReactions(XPathNavigator root)
		{
			// Loop through reactions, encoding reactant / product names into matter types to speed things up.
			foreach(XPathNavigator item in root.Select("/Configuration/Reactions/Reaction"))
			{
				// TODO: Implement the ability to load reactions.
			}
		
		}
		
		/// <summary>
		/// Accessor for colors.
		/// </summary>
		/// <param name="i">The index of the matter to access.</param>
		/// <returns>The requested matter color.</returns>
		public Color GetColor(int i)
		{
			return Definitions[i].Color;
		}
		
		/// <summary>
		/// Accessor for matter types.
		/// </summary>
		/// <param name="i">The index of the matter to access.</param>
		/// <returns>The requested matter type.</returns>
		public MatterType GetType(int i)
		{
			return Definitions[i].Type;
		}
	}
}

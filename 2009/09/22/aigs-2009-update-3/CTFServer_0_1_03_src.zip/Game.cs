﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CaptureTheFlagServer
{
    /// <summary>
    /// Simulates the capture the flag game.
    /// </summary>
    class Game
    {
        // The game board as a grid.
        Tile[,] Grid;

        // Players involved in this game.
        internal String[] Players;
        internal Dictionary<String, int> Scores = new Dictionary<String, int>();
        internal int CurrentPlayer;

        // Let the server know if the game is over.
        internal String Winner = null;

        // The width and height of the game.
        internal int Width { get { return Grid.GetLength(0); } }
        internal int Height { get { return Grid.GetLength(1); } }

        // The solvability of the game.
        internal bool Solvable = true;

        // A flag set if the game mode includes bases or not.
        internal bool IncludesBases = false;

        // Random number generator.
        Random Random = new Random();

        // The board state (get used by RequestState, set used by Scenarios).
        internal String State
        {
            get
            {
                String result = "";
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if (Grid[x, y].Type == Type.Empty) 
                            result += "-";
                        else if (Grid[x, y].Type == Type.Wall) 
                            result += "W";
                        else if (Grid[x, y].Type == Type.Flag) 
                            result += "X";
                        else if (Grid[x, y].Type == Type.Base) 
                            result += (char)('0' + Grid[x, y].Player);
                        else if (Grid[x, y].Type == Type.Player) 
                            result += (char)('a' + Grid[x, y].Player);
                        else if (Grid[x, y].Type == Type.PlayerFlag) 
                            result += (char)('A' + Grid[x, y].Player);
                return result;
            }

            set
            {
                if (Width * Height != value.Length)
                    throw new Exception("Error setting map data: mismatched sizes (probably a problem with the scenario file).");

                for (int x = 0; x < Width; x++)
                {
                    for (int y = 0; y < Height; y++)
                    {
                        Grid[x, y].Player = -1;
                        if (value[x + y * Width] == '-')
                            Grid[x, y].Type = Type.Empty;
                        else if (value[x + y * Width] == 'X')
                            Grid[x, y].Type = Type.Flag;
                        else if (value[x + y * Width] == 'W')
                            Grid[x, y].Type = Type.Wall;
                        else if (value[x + y * Width] >= '0' && value[x + y * Width] <= '9')
                        {
                            Grid[x, y].Type = Type.Base;
                            Grid[x, y].Player = (byte)(value[x + y * Width] - '0');
                            IncludesBases = true;
                        }
                        else if (value[x + y * Width] >= 'a' && value[x + y * Width] <= 'j')
                        {
                            Grid[x, y].Type = Type.Player;
                            Grid[x, y].Player = (byte)(value[x + y * Width] - 'a');
                        }
                        else if (value[x + y * Width] >= 'A' && value[x + y * Width] <= 'J')
                        {
                            Grid[x, y].Type = Type.PlayerFlag;
                            Grid[x, y].Player = (byte)(value[x + y * Width] - 'A');
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Create a new game with the following parameters.
        /// 
        /// All arguments must be non-zero.
        /// </summary>
        /// <param name="width">The width of the new game board.</param>
        /// <param name="height">The height of the new game board.</param>
        /// <param name="teams">The number of teams playing.</param>
        public Game(byte width, byte height, byte teams)
        {
            // Check for invalid values.
            if (width <= 0) throw new Exception("Width must have a positive value.");
            if (height <= 0) throw new Exception("Height must have a positive value.");
            if (teams <= 0) throw new Exception("There must be at least one team.");

            // Initialize game board.
            Grid = new Tile[width, height];
            Players = new String[teams];
            for (int x = 0; x < width; x++)
                for (int y = 0; y < height; y++)
                    Grid[x, y] = new Tile(Type.Empty, 0);
        }

        /// <summary>
        /// Create a new game with the following parameters.
        /// 
        /// All arguments must be non-zero.
        /// </summary>
        /// <param name="width">The width of the new game board.</param>
        /// <param name="height">The height of the new game board.</param>
        /// <param name="teams">The number of teams playing.</param>
        /// <param name="players">The number of players one each team.</param>
        /// <param name="flags">The number of flags.</param>
        /// <param name="seed">The random seed (0 will use system time).</param>
        public Game(byte width, byte height, byte teams, byte players, byte flags, byte seed)
        {
            // Create the randomizer that will generate the game board.
            if(seed != 0)
                Random = new Random(seed);

            // Check for invalid values.
            if (width <= 0) throw new Exception("Width must have a positive value.");
            if (height <= 0) throw new Exception("Height must have a positive value.");
            if (teams <= 0) throw new Exception("There must be at least one team.");
            if (players <= 0) throw new Exception("There must be at least one player per team.");
            if (flags <= 0) throw new Exception("There must be at least one flag.");

            // Initialize game board.
            Grid = new Tile[width, height];
            Players = new String[teams];
            for (int x = 0; x < width; x++)
                for (int y = 0; y < height; y++)
                    Grid[x, y] = new Tile(Type.Empty, 0);

            // TODO: Generate random boards.
        }

        /// <summary>
        /// Add a player to a game.
        /// </summary>
        /// <param name="player">The player to add to a game.</param>
        public void AddPlayer(String player)
        {
            for (int i = 0; i < Players.Length; i++)
            {
                if (Players[i] == null)
                {
                    Players[i] = player;
                    Scores[player] = 0;
                    return;
                }
            }

            throw new Exception("Cannot add another player, the game is already full.");
        }

        /// <summary>
        /// Add a new player with the given index.
        /// </summary>
        /// <param name="index">The player index to use.</param>
        /// <param name="player">The player to add to a game.</param>
        public void AddPlayer(int index, String player)
        {
            if (Players[index] == null)
            {
                Players[index] = player;
                Scores[player] = 0;
            }
            else
                throw new Exception("Cannot add a player at index '" + index + "' (already in use).");
        }

        /// <summary>
        /// Check if a given player ID is in a game.
        /// </summary>
        /// <param name="player">The player ID to check.</param>
        /// <returns>True if the player is in this game, false otherwise.</returns>
        public bool HasPlayer(String player)
        {
            foreach (String p in Players)
                if (player.Equals(p))
                    return true;
            return false;
        }

        /// <summary>
        /// The given player would like to make a move on the game board.
        /// Will throw an exception detailing the problem if the move is invalid.
        /// 
        /// A move string is a list of moves formatted like this:
        /// - {Source row}x{Source column}-{Destination row}x{Destination column};...
        /// </summary>
        /// <param name="player">The player that will be making the move.</param>
        /// <param name="moveString">The formatted move string.</param>
        public void Move(String player, String moveString)
        {
            Move(player, moveString, false);
        }

        /// <summary>
        /// The given player would like to make a move on the game board.
        /// Will throw an exception detailing the problem if the move is invalid.
        /// 
        /// A move string is a list of moves formatted like this:
        /// - {Source row}x{Source column}-{Destination row}x{Destination column};...
        /// </summary>
        /// <param name="player">The player that will be making the move.</param>
        /// <param name="moveString">The formatted move string.</param>
        /// <param name="overrideExceptions">Just return rather than throwning exceptions.</param>
        public void Move(String player, String moveString, bool overrideExceptions)
        {
            // Potentially override exceptions.
            try
            {
                // Make sure the game is actually full.
                for (int i = 0; i < Players.Length; i++)
                    if (Players[i] == null)
                        throw new Exception("Cannot process move.  Not all players have joined the game.");

                // Check first if the given player actually is in the game, then if they are the current player.
                if (!Players.Contains(player)) throw new Exception("You are not playing in this game.");
                if (!Players[CurrentPlayer].Equals(player)) throw new Exception("It is currently " + Players[CurrentPlayer] + "'s turn.");

                // If the game is over, no more moves are possible.
                if (Winner != null) throw new Exception("The game is over.  '" + Winner + "' won.");

                // Check the format of the move.
                if (!(moveString.Equals("") || Regex.IsMatch(moveString, "([0-9]+x[0-9]+;)*[0-9]+x[0-9]+", RegexOptions.Compiled)))
                    throw new Exception("'" + moveString + "' is not a validly formatted move.");

                // Parse moves into arrays.
                List<int[]> parsedMoves = new List<int[]>();
                try
                {
                    foreach (String move in moveString.Split(new String[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        String[] points = move.Split(new String[] { "-", "x" }, StringSplitOptions.RemoveEmptyEntries);
                        parsedMoves.Add(new int[] { int.Parse(points[0]), int.Parse(points[1]), int.Parse(points[2]), int.Parse(points[3]) });
                    }
                }
                catch
                {
                    throw new Exception("'" + moveString + "' is not a validly formatted move.");
                }

                // Count the number of current players (to verify that players do not collide).
                int currentPlayerCount = 0;
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if ((Grid[x, y].Type == Type.Player || Grid[x, y].Type == Type.PlayerFlag) && Grid[x, y].Player == CurrentPlayer)
                            currentPlayerCount++;

                // Buffer the grid incase it needs to be reset.
                Tile[,] GridBuffer = (Tile[,])Grid.Clone();

                // Verify moves.
                // For a move to be valid, there must be a player at the origin and the destination must be either a flag or empty.
                // Two or more players cannot be in the same square at the end of a move.
                foreach (int[] move in parsedMoves)
                {
                    // Watch for any parsing problems that I didn't otherwise check for.
                    try
                    {
                        // Check that the player is only moving one square in any direction.
                        if (Math.Abs(move[0] - move[2]) + Math.Abs(move[1] - move[3]) > 1)
                            throw new Exception("Cannot move from (" + move[0] + " x " + move[1] + ") to (" + move[2] + " x " + move[3] + ").  Can only move one square at a time.");

                        // Verify that a player of the correct type is in the given location.
                        if (Grid[move[0], move[1]].Type != Type.Player && Grid[move[0], move[1]].Type != Type.PlayerFlag)
                            throw new Exception("(" + move[0] + " x " + move[1] + ") does not contain a player.");
                        if (Grid[move[0], move[1]].Player != CurrentPlayer)
                            throw new Exception("(" + move[0] + " x " + move[1] + ") does not belong to you.");

                        // A player already holding a flag cannot move onto another.
                        if (Grid[move[0], move[1]].Type == Type.PlayerFlag)
                            if (Grid[move[2], move[3]].Type == Type.Flag)
                                throw new Exception("Cannot move player at (" + move[0] + " x " + move[1] + "), already holding a flag.");

                        // Verify that the target location is not a wall, base, or opposing player.
                        if (Grid[move[2], move[3]].Type == Type.Wall)
                            throw new Exception("(" + move[2] + " x " + move[3] + ") contains a wall.");
                        if (Grid[move[2], move[3]].Type == Type.Base)
                            throw new Exception("(" + move[2] + " x " + move[3] + ") contains a base.");
                        if ((Grid[move[2], move[3]].Type == Type.Player || Grid[move[2], move[3]].Type == Type.PlayerFlag) && Grid[move[2], move[3]].Player != CurrentPlayer)
                            throw new Exception("(" + move[2] + " x " + move[3] + ") contains another player.");

                        // Make sure two players are not moving to the same location.
                        foreach (int[] other in parsedMoves)
                        {
                            // Don't check against yourself.
                            if (move == other) continue;

                            // If they have the same destination, we have a problem
                            if (move[2] == other[2] && move[3] == other[3]) throw new Exception("Two players cannot move to the same tile: (" + move[2] + " x " + move[3] + ").");
                        }
                    }
                    // An index was tried out of the map bounds.
                    catch (IndexOutOfRangeException)
                    {
                        throw new Exception("(" + move[0] + " x " + move[1] + ") to (" + move[2] + " x " + move[3] + ") is not a valid move.  Cannot move past the edges.");
                    }
                }

                // The potential change to the score.
                int scoreChange = 0;

                // If it made it this far, the move is valid.
                // Go ahead and perform the moves.
                foreach (int[] move in parsedMoves)
                {
                    // Remove from previous tile.
                    Type originalType = Grid[move[0], move[1]].Type;
                    Grid[move[0], move[1]].Type = Type.Empty;
                    Grid[move[0], move[1]].Player = -1;

                    // Depends on game type.
                    // If the board includes bases, players have to carry them back to bases.
                    if (IncludesBases)
                    {
                        // Move to empty squares.
                        if (Grid[move[2], move[3]].Type == Type.Empty)
                        {
                            Grid[move[2], move[3]].Type = originalType;
                            Grid[move[2], move[3]].Player = CurrentPlayer;
                        }

                        // Pick up flags.
                        else if (originalType == Type.Player && Grid[move[2], move[3]].Type == Type.Flag)
                        {
                            Grid[move[2], move[3]].Type = Type.PlayerFlag;
                            Grid[move[2], move[3]].Player = CurrentPlayer;
                        }

                        // Check for bases to drop off flags.
                        if (Grid[move[2], move[3]].Type == Type.PlayerFlag)
                        {
                            for (int dx = -1; dx <= 1; dx++)
                            {
                                for (int dy = -1; dy <= 1; dy++)
                                {
                                    if (move[2] + dx >= 0 && move[2] + dx < Width && move[3] + dy >= 0 && move[3] + dy < Height)
                                    {
                                        if (Grid[move[2] + dx, move[3] + dy].Type == Type.Base && Grid[move[2] + dx, move[3] + dy].Player == CurrentPlayer)
                                        {
                                            Grid[move[2], move[3]].Type = Type.Player;
                                            Grid[move[2], move[3]].Player = CurrentPlayer;
                                            scoreChange++;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // If players do not have bases, they just have to get to the flags.
                    else
                    {
                        // Move to empty squares.
                        if (Grid[move[2], move[3]].Type == Type.Empty)
                        {
                            Grid[move[2], move[3]].Type = originalType;
                            Grid[move[2], move[3]].Player = CurrentPlayer;
                        }

                        // Pick up flags and score.
                        else if (Grid[move[2], move[3]].Type == Type.Flag)
                        {
                            Grid[move[2], move[3]].Type = originalType;
                            Grid[move[2], move[3]].Player = CurrentPlayer;
                            scoreChange++;
                        }
                    }
                }

                // Verify that the players are not colliding.
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if ((Grid[x, y].Type == Type.Player || Grid[x, y].Type == Type.PlayerFlag) && Grid[x, y].Player == CurrentPlayer)
                            currentPlayerCount--;

                // Buffer the grid incase it needs to be reset.
                if (currentPlayerCount != 0)
                {
                    Grid = (Tile[,])GridBuffer.Clone();
                    throw new Exception("A player was lost.  Most likely two players moved to the same location.");
                }

                // Made it past the final check, add the score.
                Scores[Players[CurrentPlayer]] += scoreChange;

                // Check for a winner.
                bool flags = false;
                for (int x = 0; x < Width; x++)
                    for (int y = 0; y < Height; y++)
                        if (Grid[x, y].Type == Type.Flag || Grid[x, y].Type == Type.PlayerFlag)
                            flags = true;

                // No more flags?  We have a winner!
                if (!flags)
                {
                    Winner = Players[0];
                    int winningScore = 0;
                    foreach (String key in Scores.Keys)
                    {
                        if (Scores[key] > winningScore)
                        {
                            winningScore = Scores[key];
                            Winner = player;
                        }
                    }
                }

                // Advance the current player counter.
                else
                    CurrentPlayer = (CurrentPlayer + 1) % Players.Length;
            }

            // If any exceptions are caught, throw them unless we are overriding them.
            catch (Exception e)
            {
                if (overrideExceptions)
                    return;
                else
                    throw e;
            }
        }

        /// <summary>
        /// Process the next player as an AI player.
        /// </summary>
        public void AIPlayer()
        {
            // Make sure that the current player is actually an AI player.
            if (!Players[CurrentPlayer].StartsWith("AI", StringComparison.OrdinalIgnoreCase))
                throw new Exception("Cannot process an AI player for a non-AI player, no matter how much you might want to.");

            // Go about the whole AI thing (Isn't this what you are in the class for?  Why am I doing it?).

            // Start with no moves.
            String moves = "";

            // Find each of my players, flag carrying players, flags, and bases.
            List<int[]> players = new List<int[]>();
            List<int[]> playerFlags = new List<int[]>();
            List<int[]> bases = new List<int[]>();
            List<int[]> flags = new List<int[]>();
            List<int[]> occupied = new List<int[]>();
            for (int x = 0; x < Width; x++)
                for (int y = 0; y < Height; y++)
                    if (Grid[x, y].Type == Type.Player && Grid[x, y].Player == CurrentPlayer)
                        players.Add(new int[] { x, y });
                    else if (Grid[x, y].Type == Type.PlayerFlag && Grid[x, y].Player == CurrentPlayer)
                        playerFlags.Add(new int[] { x, y });
                    else if (Grid[x, y].Type == Type.Base && Grid[x, y].Player == CurrentPlayer)
                        bases.Add(new int[] { x, y });
                    else if (Grid[x, y].Type == Type.Flag)
                        flags.Add(new int[] { x, y });

            // Try to move each player towards the nearest flag (Manhattan distance).
            if (players.Count > 0 && flags.Count > 0)
            {
                foreach (int[] player in players)
                {
                    int[] moveTo = MoveTowards(player, flags);
                    if (moveTo != null && !occupied.Contains(moveTo) && (Grid[moveTo[0], moveTo[1]].Type == Type.Empty ||  Grid[moveTo[0], moveTo[1]].Type == Type.Flag))
                    {
                        if (!moves.Equals(""))
                            moves += ";";
                        moves += player[0] + "x" + player[1] + "-" + moveTo[0] + "x" + moveTo[1];
                        occupied.Add(moveTo);
                    }
                    else
                    {
                        occupied.Add(player);
                    }
                }
            }

            // Try to move each player already carrying a flag to the nearest base (Manhattan distance again).
            if (playerFlags.Count > 0 && bases.Count > 0)
            {
                foreach (int[] player in playerFlags)
                {
                    int[] moveTo = MoveTowards(player, bases);
                    if (moveTo != null && !occupied.Contains(moveTo) && Grid[moveTo[0], moveTo[1]].Type == Type.Empty)
                    {
                        if (!moves.Equals(""))
                            moves += ";";
                        moves += player[0] + "x" + player[1] + "-" + moveTo[0] + "x" + moveTo[1];
                        occupied.Add(moveTo);
                    }
                    else
                    {
                        occupied.Add(player);
                    }
                }
            }

            // Try to make the move.
            // If it doesn't work, just stay still.
            Move(Players[CurrentPlayer], moves, true);
        }

        /// <summary>
        /// Move the given player to the given point.
        /// </summary>
        /// <param name="moving">The player to move.</param>
        /// <param name="targets">The possible points to move towards.</param>
        /// <returns>The direction to move.</returns>
        private int[] MoveTowards(int[] moving, List<int[]> targets)
        {
            // Simple error checking.
            if (moving == null || targets == null || targets.Count == 0)
                return null;

            // Initialize to the first point.
            int[] moveTo = targets[0];
            int distance = Math.Abs(targets[0][0] - moving[0]) + Math.Abs(targets[0][1] - moving[1]);

            // Two possibilities: Move randomly or seek a flag.
            if (Random.NextDouble() > 0.7)
            {
                if (Random.NextDouble() > 0.5)
                    if (Random.NextDouble() > 0.5)
                        moveTo = new int[] { moving[0] + 1, moving[1] };
                    else
                        moveTo = new int[] { moving[0] - 1, moving[1] };
                else
                    if (Random.NextDouble() > 0.5)
                        moveTo = new int[] { moving[0], moving[1] + 1 };
                    else
                        moveTo = new int[] { moving[0], moving[1] - 1 };
                return moveTo;
            }
            

            // Loop through finding the nearest one.
            foreach (int[] target in targets)
            {
                if (Math.Abs(target[0] - moving[0]) + Math.Abs(target[1] - moving[1]) < distance)
                {
                    moveTo = target;
                    distance = (Math.Abs(target[0] - moving[0]) + Math.Abs(target[1] - moving[1]));
                }
            }

            // Calculate the actual move.
            if (Math.Abs(moveTo[0] - moving[0]) > Math.Abs(moveTo[1] - moving[1]))
            {
                moveTo[0] = moving[0] + Math.Sign(moveTo[0] - moving[0]);
                moveTo[1] = moving[1];
            }
            else
            {
                moveTo[0] = moving[0];
                moveTo[1] = moving[1] + Math.Sign(moveTo[1] - moving[1]);
            }

            // Return the result.
            return moveTo;
        }

        /// <summary>
        /// Check if a game is full.
        /// </summary>
        /// <returns>True if the game is full.</returns>
        public bool IsFull()
        {
            for (int i = 0; i < Players.Length; i++)
                if (Players[i] == null)
                    return false;
            return true;
        }
    }

    /// <summary>
    /// Different possible tile types.
    /// </summary>
    enum Type
    {
        Empty,
        Wall,
        Base, 
        Player,
        Flag,
        PlayerFlag,
    };

    /// <summary>
    /// Represents a sintle tile of the game board.
    /// </summary>
    class Tile
    {
        internal Type Type;
        internal int Player;
        public Tile(Type type, int player)
        {
            Type = type;
            Player = player;
        }
    }
}

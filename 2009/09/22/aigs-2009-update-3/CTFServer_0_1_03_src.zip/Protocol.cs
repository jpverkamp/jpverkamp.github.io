﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CaptureTheFlagServer
{
    /// <summary>
    /// Loads the protocol file.  Can be used to encode and decode packets.
    /// </summary>
    class Protocol
    {
        // Store the protocol information.
        internal List<PacketDefinition> ProtocolData;
        internal Dictionary<String, int> Constants;

        /// <summary>
        /// Load a protocol file.
        /// </summary>
        /// <param name="protocolFile">The protocol file.</param>
        public Protocol(String protocolFile)
        {
            // Load the data file.
            TextReader input = new StreamReader(protocolFile);
            
            // Read the protocol data.
            ProtocolData = new List<PacketDefinition>();
            Constants = new Dictionary<String, int>();
            String line;
            String currentPacketTitle = null;
            List<PacketData> currentPacketData = null;
            while ((line = input.ReadLine()) != null)
            {
                // Remove comments.
                line = Regex.Replace(line, "#[^\n]*$", "");

                // Ignore empty lines.
                if (line.Length == 0 || line.StartsWith("#"))
                {
                    continue;
                }

                // Constants start with 'CONST'
                else if (line.StartsWith("CONST", StringComparison.OrdinalIgnoreCase))
                {
                    line = Regex.Replace(line.Trim(), "CONST", "").Trim();
                    String[] parts = line.Split(new String[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length != 2)
                        throw new Exception("Invalid protocol format on line: " + line);
                    parts[0] = parts[0].Trim();
                    parts[1] = parts[1].Trim();
                    Constants.Add(parts[0], int.Parse(parts[1]));
                }

                // If the first character is a tab or a space, add to the previous packet.
                else if (line.StartsWith("\t") || line.StartsWith(" "))
                {
                    // Remove excess spaces.
                    line = line.Trim();

                    // If nothing else is left, just ignore the line.
                    if (line.Length == 0)
                        continue;

                    // Split into two parts.
                    String[] parts = line.Split(new String[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length != 2)
                        throw new Exception("Invalid protocol format on line: " + line);
                    parts[0] = parts[0].Trim();
                    parts[1] = parts[1].Trim();

                    // Add the data (just datatype).
                    if (parts[1].Equals("byte", StringComparison.OrdinalIgnoreCase))
                        currentPacketData.Add(new PacketData(parts[0], PacketDatatype.Byte));
                    else if (parts[1].Equals("int", StringComparison.OrdinalIgnoreCase))
                        currentPacketData.Add(new PacketData(parts[0], PacketDatatype.Int));
                    else if (parts[1].Equals("char", StringComparison.OrdinalIgnoreCase))
                        currentPacketData.Add(new PacketData(parts[0], PacketDatatype.Char));
                    else if (parts[1].Equals("string", StringComparison.OrdinalIgnoreCase))
                        currentPacketData.Add(new PacketData(parts[0], PacketDatatype.String));

                    // Add the data (constant values).
                    else
                        throw new Exception("Invalid protocol format (unknown datatype) on line: " + line);
                }

                // Otherwise, start a new packet.
                else
                {
                    // Clear spaces.
                    line = line.Trim();
                    if (line.Length == 0)
                        continue;

                    // If we already have one, add it to the list.
                    if (currentPacketTitle != null && currentPacketData != null)
                        ProtocolData.Add(new PacketDefinition(currentPacketTitle, currentPacketData.ToArray()));

                    // Start collecting data for the new packet.
                    currentPacketTitle = line;
                    currentPacketData = new List<PacketData>();
                }
            }

            // Add the last packet type.
            if (currentPacketTitle != null && currentPacketData != null)
                ProtocolData.Add(new PacketDefinition(currentPacketTitle, currentPacketData.ToArray()));
        }

        /// <summary>
        /// Encode data as a packet.
        /// </summary>
        /// <param name="packet">The packet to send.</param>
        /// <returns>An encoded byte array of requested data.</returns>
        public String Encode(Packet packet)
        {
            return packet.Encode();
        }

        /// <summary>
        /// Decode data into a packet.
        /// </summary>
        /// <param name="data">The encoded data.</param>
        /// <returns>A packet.</returns>
        public Packet Decode(String data)
        {
            return new Packet(this, data);
        }
    }

    /// <summary>
    /// An internal C# representation of a packet.
    /// </summary>
    class Packet {
        // Packet specification data.
        Protocol Protocol;
        PacketDefinition Definition;
        Dictionary<String, Object> Data = new Dictionary<String, Object>();

        // Accessor for the data.
        public Object this[String key]
        {
            get
            {
                return Data[key];
            }
        }

        /// <summary>
        /// Create a new packet of the given type (performs some minor sanity checks).
        /// Timestamp will be set to the current system time.
        /// </summary>
        /// <param name="protocol">The protocol this packet belongs to.</param>
        /// <param name="title">The type of packet.</param>
        /// <param name="data">The packet data.</param>
        public Packet(Protocol protocol, String title, Object[] data)
        {
            // Setup the protocol.
            Protocol = protocol;

            // Get the correct packet definition.
            foreach (PacketDefinition definition in protocol.ProtocolData)
                if (definition.Title.Equals(title))
                    Definition = definition;
            if (Definition == null)
                throw new Exception("Unknown packet type: " + title);

            // Set the timestamp.
            Data["Type"] = title;
            Data["Version"] = Protocol.Constants["VERSION"];
            Data["Timestamp"] = DateTime.Now.Ticks;

            // Not enough or too much data.
            if (Definition.Data.Length != data.Length)
                throw new Exception("Inproper amount of data in packet.");

            // Store the data in the dictionary.
            for (int i = 0; i < Definition.Data.Length; i++)
                Data[Definition.Data[i].Title] = data[i];
        }

        /// <summary>
        /// Create a new packet directly from a data stream.
        /// </summary>
        /// <param name="protocol">The protocol to use to create the packet.</param>
        /// <param name="data">The data that the packet should / does contain.</param>
        public Packet(Protocol protocol, String data)
        {
            // Setup the protocol.
            Protocol = protocol;

            // Check that the (required) first section exists.
            if (!data.StartsWith("CTFS"))
                throw new Exception("Invalid packet, see protocol format.");
            data = data.Substring(5);

            // Process the data.
            foreach (String pair in data.Split(new String[]{ "," }, StringSplitOptions.RemoveEmptyEntries))
            {
                String[] parts = pair.Split(new String[] { "=" }, StringSplitOptions.None);
                if (parts.Length != 2)
                    throw new Exception("Invalid packet.  Not a valid pair: '" + pair + "'");
                Data[parts[0].Trim()] = parts[1].Trim();
            }

            // Get the correct protocol data.
            Protocol = protocol;
            Definition = null;
            foreach (PacketDefinition definition in protocol.ProtocolData)
                if (definition.Title.Equals(Data["Type"]))
                    Definition = definition;
            if (Definition == null)
                throw new Exception("Unknown packet type: " + Data["Type"]);

            // Convert objects to the correct types.
            foreach (PacketData blog in Definition.Data)
                if (Data.ContainsKey(blog.Title))
                    if (blog.Datatype == PacketDatatype.Byte)
                        Data[blog.Title] = byte.Parse(Data[blog.Title] as String);
                    else if (blog.Datatype == PacketDatatype.Char)
                        Data[blog.Title] = char.Parse(Data[blog.Title] as String);
                    else if (blog.Datatype == PacketDatatype.Int)
                        Data[blog.Title] = int.Parse(Data[blog.Title] as String);
        }

        /// <summary>
        /// Encode the data into a byte array.
        /// </summary>
        /// <returns>The encoded data.</returns>
        public String Encode()
        {
            // Use a list to dynamically build the array.
            String data = "";

            // Add the protocol name, version, and the current timestamp.
            data += "CTFS,";
            
            // Start adding the data.
            foreach(String key in Data.Keys)
                data += key + "=" + Data[key] + ",";

            // Return the data.
            return data.Substring(0, data.Length - 1) + "\n";
        }
    };

    // Possible packet datatypes.
    enum PacketDatatype
    {
        Byte,
        Int,
        Char,
        String,
    };

    // Packet definitions.
    class PacketData
    {
        internal String Title;
        internal PacketDatatype Datatype;
        public PacketData(String title, PacketDatatype datatype)
        {
            Title = title;
            Datatype = datatype;
        }
    }
    class PacketDefinition
    {
        internal String Title;
        internal PacketData[] Data;
        public PacketDefinition(String title, PacketData[] data)
        {
            Title = title;
            Data = data;
        }
    };
}

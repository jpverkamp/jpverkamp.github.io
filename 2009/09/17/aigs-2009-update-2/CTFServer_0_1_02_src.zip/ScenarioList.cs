﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CaptureTheFlagServer
{
    /// <summary>
    /// Used to keep track of scenarios and generate games based on them.
    /// </summary>
    class ScenarioList
    {
        // Keep track of scenarios.
        internal Dictionary<String, ScenarioDefinition> Scenarios = new Dictionary<String, ScenarioDefinition>();

        /// <summary>
        /// Load the scenario list from the given file.
        /// </summary>
        /// <param name="scenarioFile"></param>
        public ScenarioList(String scenarioFile)
        {
            // Load the data file.
            TextReader input = new StreamReader(scenarioFile);
            String line;

            // Read the input while there's still input to read.
            ScenarioDefinition currentScenario = null;
            while ((line = input.ReadLine()) != null)
            {
                // Remove comments.
                line = Regex.Replace(line, "#[^\n]*$", "");

                // Ignore empty lines.
                if (line.Length == 0)
                {
                    continue;
                }

                // If the first character is a tab or a space, add to the previous scenario.
                else if (line.StartsWith("\t") || line.StartsWith(" "))
                {
                    // Remove excess spaces.
                    line = line.Trim();

                    // If nothing else is left, just ignore the line.
                    if (line.Length == 0)
                        continue;

                    // If there is a colon, it's a property.
                    if (line.Contains(':'))
                    {
                        // Split into two parts.
                        String[] parts = line.Split(new String[] { ":" }, StringSplitOptions.RemoveEmptyEntries);
                        if (parts.Length != 2)
                            throw new Exception("Invalid protocol format on line: " + line);
                        parts[0] = parts[0].Trim();
                        parts[1] = parts[1].Trim();

                        // Check each possible value.
                        if (parts[0].Equals("Width", StringComparison.OrdinalIgnoreCase)) currentScenario.Width = Byte.Parse(parts[1]);
                        else if (parts[0].Equals("Height", StringComparison.OrdinalIgnoreCase)) currentScenario.Height = Byte.Parse(parts[1]);
                        else if (parts[0].Equals("Teams", StringComparison.OrdinalIgnoreCase)) currentScenario.Teams = Byte.Parse(parts[1]);
                        else if (parts[0].Equals("Solvable", StringComparison.OrdinalIgnoreCase))
                        {
                            if (parts[1].Equals("true", StringComparison.OrdinalIgnoreCase))
                                currentScenario.Solvable = true;
                            else if (parts[1].Equals("false", StringComparison.OrdinalIgnoreCase))
                                currentScenario.Solvable = false;
                            else 
                                throw new Exception("Solvable must be either 'true' or 'false'");
                        }
                        else throw new Exception("Unknown property: " + parts[0]);
                    }

                    // Otherwise, it contains map data.
                    else
                    {
                        line = line.Trim();
                        currentScenario.MapData += line;
                    }
                }

                // Otherwise, start a new definition.
                else
                {
                    // Clear spaces.
                    line = line.Trim();
                    if (line.Length == 0)
                        continue;

                    // If we already have one, add it to the list.
                    if (currentScenario != null)
                        Scenarios.Add(currentScenario.Title, currentScenario);

                    // Start collecting data for the new packet.
                    currentScenario = new ScenarioDefinition(line);
                }
            }

            // Add the last one.
            if (currentScenario != null)
                Scenarios.Add(currentScenario.Title, currentScenario);
        }
    }

    /// <summary>
    /// Store the definitions of the scenarios.
    /// </summary>
    class ScenarioDefinition
    {
        internal String Title;
        internal byte Width;
        internal byte Height;
        internal byte Teams;
        internal String MapData;
        internal bool Solvable;

        /// <summary>
        /// Create a new scenario definition.
        /// </summary>
        /// <param name="title">The scenario title.</param>
        public ScenarioDefinition(String title)
        {
            Title = title;
        }
    }
}

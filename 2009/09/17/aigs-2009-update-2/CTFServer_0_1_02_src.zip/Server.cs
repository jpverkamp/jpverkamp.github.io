﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Threading;

namespace CaptureTheFlagServer
{
    /// <summary>
    /// The main server class.  Contains the code for creating and dispatching child threads.
    /// </summary>
    class Server
    {
        // Constants.
        static readonly IPAddress LocalAddress = IPAddress.Parse("127.0.0.1");
        const int DEFAULT_GAME_WIDTH = 10;
        const int DEFAULT_GAME_HEIGHT = 10;

        // Keep track of the main server thread.
        Thread MainThread;

        // Keep track of all of the spawned server threads.
        Dictionary<Socket, Thread> ServerThreads = new Dictionary<Socket, Thread>();

        // Current protocol and scenarios.
        Protocol Protocol;
        ScenarioList Scenarios;

        // Keep a list of known games.
        List<Game> Games;

        // Keep a dictionary of known players (associated with their network connections).
        Dictionary<String, StreamWriter> Players;

        /// <summary>
        /// Create the new server thread.
        /// </summary>
        public Server(int port)
        {
            // Load the protocol data.
            Protocol = new Protocol("CTFProtocol.txt");
            Scenarios = new ScenarioList("CTFScenarios.txt");
            
            // Start with an empty game array and player array.
            Games = new List<Game>();
            Players = new Dictionary<String, StreamWriter>();

            // Create the main thread.
            MainThread = new Thread(new ThreadStart(delegate { RunMainThread(port); } ));
            MainThread.Start();

            // Tell anyone watching that something happened.
            Console.Write("CaptureTheFlag Server is now running on port " + port + ".");
        }

        /// <summary>
        /// The body of the main server thread.
        /// </summary>
        void RunMainThread(int port)
        {
            // Start listening for incoming TCP chatter.
            TcpListener tcpListner = new TcpListener(LocalAddress, port);            
            tcpListner.Start();

            // Process each message as it comes in, ad infinitum.
            while(true)
            {
                // Wait until a socket is incoming.
                Socket client = tcpListner.AcceptSocket();
                
                // Create a new server thread for this client.
                if (client.Connected)
                {
                    Thread serverThread = new Thread(new ThreadStart(delegate { RunServerThread(client); } ));
                    ServerThreads[client] = serverThread;
                    serverThread.Start();
                }
            }

        }

        /// <summary>
        /// The body of the server thread that is designed to respond to respond to an individual client.
        /// </summary>
        /// <param name="client"></param>
        void RunServerThread(Socket client)
        {
            // DEBUG
            Console.WriteLine("Incoming connection established: " + client.ToString());

            // Used to interact with the client.
            StreamReader input = new StreamReader(new NetworkStream(client));
            StreamWriter output = new StreamWriter(new NetworkStream(client));
            String line;

            // Information about the player connected to this thread.
            String playerName = "Player " + ((int)DateTime.Now.Ticks).ToString();
            bool playerNameSet = false;

            // Send the first message to the server.
            // This is the private key that we will use to communicate for this session.

            // Keep on listening until the client gets tired of talking.
            while (true)
            {
                // Watch for forceful disconnect.
                try
                {
                    // We still have a client!  Yay!
                    if (client.Connected)
                    {
                        // Read the next line.
                        line = input.ReadLine();
                        if (line == null)
                            continue;

                        // Read a packet from the client.
                        Packet packet = new Packet(Protocol, line);

                        // Debug message
                        #region DEBUG
                        Console.WriteLine("Received: " + line);
                        #endregion

                        // Process the packet.
                        #region PACKET_PROCESSING

                        // Player is signing into the server or changing their username.
                        if (packet["Type"].Equals("SignIn"))
                        {
                            // Remove the old player.
                            if (playerNameSet)
                                Players.Remove(playerName);

                            // Check that the name is available.
                            // Name is not available.
                            if (Players.ContainsKey((String)packet["PlayerName"]))
                            {
                                // Tell the player that the name is in use.
                                SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "Unable to select username.  '" + (String)packet["PlayerName"] + "' is already in use." }));
                            }

                            // Name is available.  Give it to this player.
                            else
                            {
                                // Add the new player.
                                playerName = (String)packet["PlayerName"];
                                playerNameSet = true;

                                // Add to the dictionary.
                                Players.Add(playerName, output);

                                // Send confirmation to the player.
                                SendToClient(output, new Packet(Protocol, "Success", new Object[] { packet["Timestamp"] }));
                            }
                        }

                        // Create a new game on the server.
                        else if (packet["Type"].Equals("CreateGame"))
                        {
                            // Find the game the player is in.
                            Game game = FindGame(playerName);

                            // The player is not currently in a game.
                            if (game == null)
                            {
                                try {
                                    Game newGame = new Game(
                                        (byte)packet["Width"],
                                        (byte)packet["Height"],
                                        (byte)packet["Teams"],
                                        (byte)packet["Players"],
                                        (byte)packet["Flags"],
                                        (byte)packet["Seed"]
                                    );
                                    newGame.AddPlayer(playerName);
                                    Games.Add(newGame);
                                    SendToClient(output, new Packet(Protocol, "Success", new Object[] { packet["Timestamp"] }));
                                }
                                catch(Exception e)
                                {
                                    SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "Invalid game setup: " + e.Message }));
                                }   
                            }

                            // The player is already in a game, tell them this.
                            else
                                SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "Player '" + playerName + "' is already in an active game." }));
                        }

                        // Create a scenario game on the server.
                        else if (packet["Type"].Equals("CreateScenario"))
                        {
                            // If the scenario exists, create it.
                            if (Scenarios.Scenarios.ContainsKey((string)packet["Scenario"]))
                            {
                                // Find the game the player is in.
                                Game game = FindGame(playerName);

                                // The player is not currently in a game.
                                if (game == null)
                                {
                                    ScenarioDefinition definition = Scenarios.Scenarios[(string)packet["Scenario"]];
                                    try
                                    {
                                        Game newGame = new Game(
                                            definition.Width,
                                            definition.Height,
                                            definition.Teams
                                        );
                                        newGame.State = definition.MapData;
                                        newGame.Solvable = definition.Solvable;
                                        newGame.AddPlayer(playerName);
                                        Games.Add(newGame);
                                        SendToClient(output, new Packet(Protocol, "Success", new Object[] { packet["Timestamp"] }));
                                    }
                                    catch (Exception e)
                                    {
                                        SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "Invalid game setup: " + e.Message }));
                                    }
                                }

                                // The player is already in a game, tell them this.
                                else
                                    SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "Player '" + playerName + "' is already in an active game." }));   
                            }

                            // If the scenario doesn't exist, return an error.
                            else
                            {
                                SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "Scenario '" + (string)packet["Scenario"] + "' does not exist." }));
                            }

                        }

                        // Join a game on the server.
                        else if (packet["Type"].Equals("JoinGame"))
                        {
                            // Find the game the player is in.
                            Game game = FindGame(playerName);

                            // The player is not yet in a game.
                            if (game == null)
                                SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "Cannot find a game with '" + (String)packet["Opponent"] + "' included." }));

                            // The player has a game.
                            else
                            {
                                // Add the new player.
                                game.AddPlayer(playerName);
                                SendToClient(output, new Packet(Protocol, "Success", new Object[] { packet["Timestamp"] }));

                                // Notify all of the other players.
                                foreach (String player in game.Players)
                                    if (!player.Equals(playerName))
                                        SendToClient(Players[player], new Packet(Protocol, "PlayerAdded", new Object[] { player }));
                            }
                        }

                        // Request the game state.
                        else if (packet["Type"].Equals("RequestGameState"))
                        {
                            // Find the game the player is in.
                            Game game = FindGame(playerName);

                            // The player is not yet in a game.
                            if (game == null)
                                SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "You are currently not in a game." }));

                            // Found the game, send the state.
                            else
                                SendToClient(output, new Packet(Protocol, "GameState", new Object[] { game.Width, game.Height, game.State }));
                        }

                        // Return a list of known scenarios.
                        else if (packet["Type"].Equals("ListScenarios"))
                        {
                            String scenarios = "";
                            foreach (String scenario in Scenarios.Scenarios.Keys)
                                scenarios += scenario + ";";
                            scenarios = scenarios.Substring(0, scenarios.Length - 1);

                            SendToClient(output, new Packet(Protocol, "ScenarioList", new Object[] { scenarios }));
                        }

                        // Return a list of known players.
                        else if (packet["Type"].Equals("ListPlayers"))
                        {
                            String players = "";
                            foreach (String player in Players.Keys)
                                players += player + ";";
                            players = players.Substring(0, players.Length - 1);

                            SendToClient(output, new Packet(Protocol, "PlayerList", new Object[] { players }));
                        }

                        // Perform a move on the server.
                        else if (packet["Type"].Equals("MakeMove"))
                        {
                            // Find the game the player is in.
                            Game game = FindGame(playerName);

                            // If the player hasn't joined the game, ask them where they would like to make a move.
                            if (game == null)
                            {
                                SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "You are currently not in a game." }));
                            }

                            // If the player has joined the game, try the move.
                            else
                            {
                                try
                                {
                                    // Check to see if the player wants to claim that the puzzle is unsolvable.
                                    if ("unsolvable".Equals((string)packet["Move"], StringComparison.OrdinalIgnoreCase))
                                    {
                                        // Tell the client that the move was received successfully.
                                        SendToClient(output, new Packet(Protocol, "Success", new Object[] { packet["Timestamp"] }));

                                        // End the game either way.
                                        if (game.Solvable)
                                            game.Winner = "No winner";
                                        else
                                            game.Winner = playerName;

                                        // Tell all of the clients that then game is over.
                                        foreach (String key in game.Players)
                                            SendToClient(Players[key], new Packet(Protocol, "GameOver", new Object[] { game.Winner }));
                                    }

                                    // A more traditional move.
                                    else
                                    {
                                        // Try the move, if it works, tell the player and inform the next player that it is their turn.
                                        game.Move(playerName, (string)packet["Move"]);
                                        SendToClient(output, new Packet(Protocol, "Success", new Object[] { packet["Timestamp"] }));

                                        // If there is a winner, tell everyone.
                                        if (game.Winner != null)
                                            foreach (String key in game.Players)
                                                SendToClient(Players[key], new Packet(Protocol, "GameOver", new Object[] { game.Winner }));

                                        // If not, tell the next player that it's their turn.
                                        else
                                            SendToClient(Players[game.Players[game.CurrentPlayer]], new Packet(Protocol, "YourTurn", new Object[] { }));
                                    }
                                }
                                catch (Exception e)
                                {
                                    SendToClient(output, new Packet(Protocol, "Fail", new Object[] { packet["Timestamp"], "Not a valid move: " + e.Message }));
                                }
                            }
                        }

                        #endregion
                    }

                    // We've lost the connection, remove this thread from the thread pool.
                    else
                    {
                        // Close everything down.
                        input.Close();
                        output.Close();
                        client.Close();

                        // Remove the thread from the thread pool.
                        ServerThreads.Remove(client);

                        // Stop scanning for input.
                        break;
                    }
                }

                // There was an error with the connections, close everything.
                catch
                {
                    // We've had a problem, remove the player from the game information.

                    // First remove end any games they were in.
                    Game game = FindGame(playerName);
                    if (game != null)
                    {
                        foreach(String key in game.Players)
                            if (!(key.Equals(playerName)))
                                SendToClient(Players[key], new Packet(Protocol, "GameOver", new Object[]{"No winner.  '" + playerName + "' disconnected from the server."}));
                        Games.Remove(game);
                    }

                    // Now remove the reference from the player list.
                    if (Players.ContainsKey(playerName))
                        Players.Remove(playerName);
                    playerName = "Player " + ((int)DateTime.Now.Ticks).ToString();
                    playerNameSet = false;

                    // Close down connections.
                    input.Close();
                    output.Close();
                    client.Close();

                    // Remove the thread from the thread pool.
                    ServerThreads.Remove(client);
                    
                    // Tell anyone watching that we successfully closed the connection.
                    Console.WriteLine("Connection closed.");
                    break;
                }
            }
        }

        /// <summary>
        /// Submethod to send data to a client.
        /// </summary>
        /// <param name="client">The connection to use to send the message.</param>
        /// <param name="packet">The packet to send.</param>
        private void SendToClient(StreamWriter client, Packet packet)
        {
            client.WriteLine(packet.Encode() + "\n");
            client.Flush();
            
            #region DEBUG
            Console.WriteLine("    Sent: " + packet.Encode());
            #endregion
        }

        /// <summary>
        /// Find a game involving the given player.
        /// </summary>
        /// <param name="player">The player to find.</param>
        /// <returns>The game that player is in (null if none).</returns>
        private Game FindGame(String player)
        {
            // Find a game involving the requested player.
            foreach (Game game in Games)
                if (game.Winner == null && game.HasPlayer(player))
                    return game;

            // No such game exists.
            return null;
        }
    }
}

﻿using System;
using System.Net;
using System.Net.Sockets;

namespace CaptureTheFlagServer
{
    /// <summary>
    /// Run a server for a simple capture the flag game.
    /// </summary>
    class CaptureTheFlagServer
    {
        /// <summary>
        /// This is the entry point for the program.
        /// </summary>
        /// <param name="args">Command line parameters.</param>
        static void Main(String[] args)
        {
            // Create a new server.
            // 2837 is cell phone for CTFS (Capture The Flag Server).
            Server server = new Server(2837);
        }
    }
}

﻿
using System;

namespace Sandbox.Simulation
{
	/// <summary>
	/// Holds a definition of a particular type of reaction.
	/// </summary>
	public struct ReactionDefinition
	{
		// The reaction's properties.
		public readonly short Core;
		public readonly Reactant[] Reactants;
		public readonly short Product;
		public readonly double Chance;
		
		/// <summary>
		/// Create a new reaction definition.
		/// </summary>
		/// <param name="core">The core particle necessary to react.</param>
		/// <param name="reactants">The matter necessary to react.</param>
		/// <param name="product">The product that results from this reaction.</param>
		/// <param name="chance">The chance that the reaction will occur.</param>
		public ReactionDefinition(short core, Reactant[] reactants, short product, double chance)
		{
			Core = core;
			Reactants = reactants;
			Product = product;
			Chance = chance;
		}
	}
	
	/// <summary>
	/// Holds a reactant definition.
	/// </summary>
	public struct Reactant
	{
		// The reactant's properties.
		public readonly short ID;
		public readonly byte Minimum;
		public readonly byte Maximum;

		/// <summary>
		/// Create a new reactant.
		/// </summary>
		/// <param name="id">The reactant's ID.</param>
		/// <param name="concentration">The minimum concentration necessary.</param>
		/// <param name="concentration">The maximum concentration allowed.</param>
		public Reactant(short id, byte minimum, byte maximum)
		{
			ID = id;
			Minimum = minimum;
			Maximum = maximum;
		}		
	}
}
